import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:flutter_svg/flutter_svg.dart';

class Details extends StatelessWidget {
  Details({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Transform.translate(
            offset: Offset(0.0, -79.0),
            child:
                // Adobe XD layer: 'firefox_7ZAed32dTK' (shape)
                Container(
              width: 367.0,
              height: 843.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(1.0, 44.0),
            child: Container(
              width: 361.0,
              height: 806.0,
              decoration: BoxDecoration(
                color: const Color(0x42000000),
              ),
            ),
          ),
          Container(
            width: 360.0,
            height: 109.0,
            decoration: BoxDecoration(
              color: const Color(0xff1473e6),
            ),
          ),
          Transform.translate(
            offset: Offset(12.0, 0.0),
            child: Container(
              width: 375.0,
              height: 20.0,
              decoration: BoxDecoration(),
            ),
          ),
          Transform.translate(
            offset: Offset(51.22, 21.0),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Arial',
                  fontSize: 14,
                  color: const Color(0xffffffff),
                ),
                children: [
                  TextSpan(
                    text: 'FISH-INFO\n',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'MIZORAM',
                    style: TextStyle(
                      fontSize: 7,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Transform.translate(
            offset: Offset(28.66, 22.33),
            child:
                // Adobe XD layer: 'fish' (group)
                SvgPicture.string(
              _shapeSVG_63e34caae201439ca0f64a7bdcbfea55,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(26.0, 22.33),
            child:
                // Adobe XD layer: 'fish' (group)
                Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(16.64, 1.38),
                  child: Container(
                    width: 2.8,
                    height: 2.8,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(1.4, 1.4)),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(7.07, 17.34),
                  child: Container(
                    width: 2.8,
                    height: 2.8,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(1.38, 1.38)),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(0.0, 5.85),
                  child: Container(
                    width: 2.7,
                    height: 2.7,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(1.33, 1.33)),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(285.0, -9.0),
            child:
                // Adobe XD layer: 'Menu' (group)
                Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(35.0, 37.0),
                  child: Container(
                    width: 16.0,
                    height: 16.0,
                    decoration: BoxDecoration(),
                  ),
                ),
                Transform.translate(
                  offset: Offset(35.0, 38.0),
                  child: SvgPicture.string(
                    _shapeSVG_759fb75d22d14e898a29e2043d1a6f3c,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(-3.0, 288.0),
            child: Container(
              width: 367.0,
              height: 352.0,
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x29000000),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(138.02, 217.11),
            child: SvgPicture.string(
              _shapeSVG_cdfa96c13adc4542895aad2a0fe46a6d,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(138.0, 217.0),
            child: Stack(
              children: <Widget>[
                Container(
                  width: 28.0,
                  height: 44.0,
                  decoration: BoxDecoration(
                    color: const Color(0xff1473e6),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(25.0, 468.0),
            child: SizedBox(
              width: 204.0,
              height: 32.0,
              child: SingleChildScrollView(
                  child: Text(
                'Ch. Thuama\n',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 20,
                  color: const Color(0xff1e1e1e),
                  fontWeight: FontWeight.w500,
                  height: 1.5,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(49.0, 511.0),
            child: SizedBox(
              width: 277.0,
              height: 28.0,
              child: SingleChildScrollView(
                  child: Text(
                'Kawipui lui kam bul, Tuidam',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff626364),
                  height: 2.142857142857143,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(49.0, 544.0),
            child: SizedBox(
              width: 277.0,
              height: 28.0,
              child: SingleChildScrollView(
                  child: Text(
                '+91 789-852-9565',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff626364),
                  height: 2.142857142857143,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(25.0, 514.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 14,
                  color: const Color(0xffc2c2c2),
                  height: 2.142857142857143,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(25.0, 546.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 14,
                  color: const Color(0xffc2c2c2),
                  height: 2.142857142857143,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(0.0, 288.0),
            child:
                // Adobe XD layer: 'Pond' (shape)
                Container(
              width: 360.0,
              height: 169.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
                border: Border.all(width: 1.0, color: const Color(0xff707070)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 55.0),
            child: Container(
              width: 315.0,
              height: 44.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x29000000),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(36.78, 66.0),
            child: Stack(
              children: <Widget>[
                Transform(
                  transform: Matrix4(
                      0.87462,
                      0.48481,
                      0.0,
                      0.0,
                      -0.48481,
                      0.87462,
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      1.0,
                      0.0,
                      6.42,
                      0.0,
                      0.0,
                      1.0),
                  child: Container(
                    width: 13.2,
                    height: 13.2,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(6.62, 6.62)),
                      color: const Color(0xffffffff),
                      border: Border.all(
                          width: 2.0, color: const Color(0xff707070)),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(12.47, 13.25),
                  child: SvgPicture.string(
                    _shapeSVG_b76803a023ee4dc69d2dfd992d6c9752,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(66.76, 60.0),
            child: SizedBox(
              width: 222.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Search for fish ponds',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffb8b8b8),
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
        ],
      ),
    );
  }
}

const String _shapeSVG_63e34caae201439ca0f64a7bdcbfea55 =
    '<svg viewBox="28.7 22.3 18.4 20.7" ><g transform="translate(26.0, 22.33)"><path transform="translate(-305.3, -101.84)" d="M 322.37060546875 109.8415603637695 C 322.83056640625 109.6799392700195 323.0709228515625 109.1743621826172 322.9093017578125 108.7143783569336 C 322.8761596679688 108.6231994628906 322.83056640625 108.5403137207031 322.7725830078125 108.4657211303711 C 321.6743774414063 107.0567321777344 319.78466796875 106.3398056030273 318.5 105.9999923706055 C 319.1630859375 107.2390823364258 319.6561889648438 108.7931060791016 319.8261108398438 110.7408294677734 L 322.37060546875 109.8415603637695 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-61.45, -225.78)" d="M 64.69912719726563 235.2999877929688 C 64.25984954833984 236.54736328125 63.84544372558594 238.3624877929688 64.32615661621094 239.9620971679688 C 64.46705627441406 240.4303588867188 64.960205078125 240.6955871582031 65.42848205566406 240.5546875 C 65.51966094970703 240.5256958007813 65.60668182373047 240.4842529296875 65.6812744140625 240.4303588867188 L 67.32647705078125 239.274169921875 C 66.36919403076172 238.3707580566406 65.59010314941406 237.2933044433594 65.03065490722656 236.0998229980469 C 64.90218353271484 235.8387145996094 64.79444122314453 235.5735168457031 64.69912719726563 235.2999877929688 L 64.69912719726563 235.2999877929688 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-81.87, -5.5)" d="M 102.8992233276367 21.0418701171875 C 102.8080520629883 20.90925598144531 102.6505737304688 20.83880805969238 102.4889602661133 20.85538291931152 C 102.4558029174805 20.85952758789063 98.95819091796875 21.19519805908203 96.96488952636719 19.39666557312012 C 96.04076385498047 18.5637035369873 95.57248687744141 17.38263893127441 95.57248687744141 15.88248062133789 C 95.57248687744141 10.65678691864014 93.26837158203125 8.108174324035645 91.33308410644531 6.889813899993896 C 90.04841613769531 6.081717491149902 88.58969116210938 5.601003646850586 87.07710266113281 5.497401237487793 C 86.89061737060547 5.493257522583008 86.724853515625 5.605147838592529 86.65441131591797 5.775055408477783 C 85.15010833740234 9.537884712219238 85.00920867919922 12.79513645172119 86.244140625 15.45563888549805 C 87.65727996826172 18.50154304504395 90.80677795410156 20.80150985717773 95.875 22.49229621887207 C 97.59065246582031 23.06417846679688 99.43890380859375 24.3198356628418 99.43890380859375 25.72053718566895 C 99.43890380859375 25.96503639221191 99.63782501220703 26.16395568847656 99.88233184814453 26.16395568847656 C 100.0480880737305 26.16395568847656 100.2014236450195 26.06864166259766 100.2760162353516 25.91945457458496 C 100.4666442871094 25.5423412322998 100.3837661743164 25.01189804077148 100.2967376708984 24.44830322265625 C 100.2387161254883 24.13335227966309 100.2097091674805 23.81425857543945 100.2097091674805 23.49102210998535 C 102.0040969848633 23.2962474822998 102.8867874145508 21.57230949401855 102.9240875244141 21.49771499633789 C 103.0028305053711 21.3485279083252 102.9945373535156 21.17447662353516 102.8992233276367 21.0418701171875 L 102.8992233276367 21.0418701171875 Z M 88.94608306884766 10.57390689849854 C 88.45709228515625 10.57390689849854 88.06340026855469 10.17607402801514 88.06340026855469 9.691216468811035 C 88.06340026855469 9.206357955932617 88.46122741699219 8.808526039123535 88.94608306884766 8.808526039123535 C 89.43508911132813 8.808526039123535 89.82877349853516 9.206357955932617 89.82877349853516 9.691216468811035 C 89.82877349853516 10.17607402801514 89.43093872070313 10.57390689849854 88.94608306884766 10.57390689849854 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></g></svg>';
const String _shapeSVG_759fb75d22d14e898a29e2043d1a6f3c =
    '<svg viewBox="35.0 38.0 16.0 14.0" ><path transform="translate(35.0, 38.0)" d="M 0 14.00040054321289 L 0 11.99970054626465 L 8.000100135803223 11.99970054626465 L 8.000100135803223 14.00040054321289 L 0 14.00040054321289 Z M 0 8.000100135803223 L 0 6.00029993057251 L 16.00020027160645 6.00029993057251 L 16.00020027160645 8.000100135803223 L 0 8.000100135803223 Z M 0 1.999800086021423 L 0 0 L 16.00020027160645 0 L 16.00020027160645 1.999800086021423 L 0 1.999800086021423 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_cdfa96c13adc4542895aad2a0fe46a6d =
    '<svg viewBox="138.0 217.1 28.6 43.3" ><g transform="translate(138.0, 217.0)"><path transform="translate(-13.34, -1.96)" d="M 27.65659141540527 2.064624309539795 C 19.76754379272461 2.064624309539795 13.36106967926025 8.460272789001465 13.36106967926025 16.36014556884766 C 13.36106967926025 24.24919319152832 24.12870407104492 44.55078506469727 27.65659332275391 45.34077453613281 C 30.97886657714844 46.08747100830078 41.9412956237793 24.26001739501953 41.9412956237793 16.36014556884766 C 41.9412956237793 8.460272789001465 35.5456428527832 2.064624309539795 27.65659141540527 2.064624309539795 Z M 27.65659141540527 23.15619850158691 C 23.90144729614258 23.15619850158691 20.86053657531738 20.11528968811035 20.86053657531738 16.36014366149902 C 20.86053657531738 12.60499954223633 23.90144729614258 9.564089775085449 27.65659141540527 9.564089775085449 C 31.4117374420166 9.564089775085449 34.4526481628418 12.60499858856201 34.4526481628418 16.36014366149902 C 34.4526481628418 20.11528968811035 31.4117374420166 23.15619850158691 27.65659141540527 23.15619850158691 Z" fill="#1473e6" stroke="none" stroke-width="0.14747318625450134" stroke-miterlimit="4" stroke-linecap="butt" /></g></svg>';
const String _shapeSVG_b76803a023ee4dc69d2dfd992d6c9752 =
    '<svg viewBox="12.5 13.3 3.2 3.5" ><path transform="translate(12.47, 13.25)" d="M 0 0 L 3.248742818832397 3.466055393218994" fill="none" stroke="#707070" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
