import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:flutter_svg/flutter_svg.dart';

class Listoffarmer extends StatelessWidget {
  Listoffarmer({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Container(
            width: 360.0,
            height: 109.0,
            decoration: BoxDecoration(
              color: const Color(0xff1473e6),
            ),
          ),
          Transform.translate(
            offset: Offset(12.0, 0.0),
            child: Container(
              width: 375.0,
              height: 20.0,
              decoration: BoxDecoration(),
            ),
          ),
          Transform.translate(
            offset: Offset(285.0, -9.0),
            child:
                // Adobe XD layer: 'Menu' (group)
                Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(35.0, 37.0),
                  child: Container(
                    width: 16.0,
                    height: 16.0,
                    decoration: BoxDecoration(),
                  ),
                ),
                Transform.translate(
                  offset: Offset(35.0, 38.0),
                  child: SvgPicture.string(
                    _shapeSVG_5e70fbefbdcb48b4a286cceb6c64ba84,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 55.0),
            child: Container(
              width: 315.0,
              height: 44.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x29000000),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 147.0),
            child: Container(
              width: 315.0,
              height: 117.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(25.0, 275.0),
            child: Container(
              width: 315.0,
              height: 117.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(36.78, 66.0),
            child: Stack(
              children: <Widget>[
                Transform(
                  transform: Matrix4(
                      0.87462,
                      0.48481,
                      0.0,
                      0.0,
                      -0.48481,
                      0.87462,
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      1.0,
                      0.0,
                      6.42,
                      0.0,
                      0.0,
                      1.0),
                  child: Container(
                    width: 13.2,
                    height: 13.2,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(6.62, 6.62)),
                      color: const Color(0xffffffff),
                      border: Border.all(
                          width: 2.0, color: const Color(0xff707070)),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(12.47, 13.25),
                  child: SvgPicture.string(
                    _shapeSVG_068202d8d6fb49a288a23e7a408d7919,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(66.76, 60.0),
            child: SizedBox(
              width: 222.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Search for farmer\'s name',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffb8b8b8),
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(46.0, 154.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Zaliana',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(48.0, 282.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Lianluta',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(80.0, 17.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'LIST OF FARMER',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffffffff),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(58.0, 176.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Khawdai Peng, Serchhip',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(42.0, 231.0),
            child: SizedBox(
              width: 50.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Status :',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(48.0, 106.0),
            child: SizedBox(
              width: 63.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Approve',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xff6a707b),
                  height: 2.4,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(133.0, 106.0),
            child: SizedBox(
              width: 63.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Reject',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xff6a707b),
                  height: 2.4,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(45.0, 359.0),
            child: SizedBox(
              width: 50.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Status :',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(60.0, 304.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Thinglianpui Khua, lawngtlai',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(57.0, 195.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '+91 8756-698-523',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(59.0, 323.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '+91 9526-698-333',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(23.5, 231.5),
            child: SvgPicture.string(
              _shapeSVG_fcf4afbef584463fbeb8fcd698f782b0,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 28.0),
            child:
                // Adobe XD layer: 'Backward arrow' (component)
                Container(),
          ),
          Transform.translate(
            offset: Offset(46.0, 172.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(48.0, 300.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(44.0, 191.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(46.0, 319.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(262.0, 231.0),
            child: SizedBox(
              width: 46.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Reject',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff1473e6),
                  height: 2,
                ),
                textAlign: TextAlign.right,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(265.0, 359.0),
            child: SizedBox(
              width: 51.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Approve',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff1473e6),
                  height: 2,
                ),
                textAlign: TextAlign.right,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(93.0, 360.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Accept',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xffffffff),
                  height: 2,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(91.0, 241.0),
            child: Container(
              width: 13.0,
              height: 13.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(6.5, 6.5)),
                color: const Color(0xff30d694),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(26.0, 118.0),
            child: Container(
              width: 13.0,
              height: 13.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(6.5, 6.5)),
                color: const Color(0xff30d694),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(111.0, 118.0),
            child: Container(
              width: 13.0,
              height: 13.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(6.5, 6.5)),
                color: const Color(0xffe5387f),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(94.0, 369.0),
            child: Container(
              width: 13.0,
              height: 13.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(6.5, 6.5)),
                color: const Color(0xffe5387f),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _shapeSVG_5e70fbefbdcb48b4a286cceb6c64ba84 =
    '<svg viewBox="35.0 38.0 16.0 14.0" ><path transform="translate(35.0, 38.0)" d="M 0 14.00040054321289 L 0 11.99970054626465 L 8.000100135803223 11.99970054626465 L 8.000100135803223 14.00040054321289 L 0 14.00040054321289 Z M 0 8.000100135803223 L 0 6.00029993057251 L 16.00020027160645 6.00029993057251 L 16.00020027160645 8.000100135803223 L 0 8.000100135803223 Z M 0 1.999800086021423 L 0 0 L 16.00020027160645 0 L 16.00020027160645 1.999800086021423 L 0 1.999800086021423 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_068202d8d6fb49a288a23e7a408d7919 =
    '<svg viewBox="12.5 13.3 3.2 3.5" ><path transform="translate(12.47, 13.25)" d="M 0 0 L 3.248742818832397 3.466055393218994" fill="none" stroke="#707070" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _shapeSVG_fcf4afbef584463fbeb8fcd698f782b0 =
    '<svg viewBox="23.5 231.5 316.0 128.0" ><path transform="translate(23.5, 231.5)" d="M 0 0 L 314 0" fill="none" stroke="#e9e9e9" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(25.5, 359.5)" d="M 0 0 L 314 0" fill="none" stroke="#e9e9e9" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
