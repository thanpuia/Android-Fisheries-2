import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:flutter_svg/flutter_svg.dart';

class SMS extends StatelessWidget {
  SMS({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Container(
            width: 360.0,
            height: 61.0,
            decoration: BoxDecoration(
              color: const Color(0xff1473e6),
            ),
          ),
          Transform.translate(
            offset: Offset(12.0, 0.0),
            child: Container(
              width: 375.0,
              height: 20.0,
              decoration: BoxDecoration(),
            ),
          ),
          Transform.translate(
            offset: Offset(285.0, -9.0),
            child:
                // Adobe XD layer: 'Menu' (group)
                Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(35.0, 37.0),
                  child: Container(
                    width: 16.0,
                    height: 16.0,
                    decoration: BoxDecoration(),
                  ),
                ),
                Transform.translate(
                  offset: Offset(35.0, 38.0),
                  child: SvgPicture.string(
                    _shapeSVG_82e45c73dbe7466d94cdb19d33a84ba3,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(80.0, 17.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'SEND SMS',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffffffff),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 28.0),
            child:
                // Adobe XD layer: 'Backward arrow' (component)
                Container(),
          ),
          Transform.translate(
            offset: Offset(-1.0, 62.0),
            child: SvgPicture.string(
              _shapeSVG_b575a33ae5e6449ca24548e84d57e2a2,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(23.76, 203.0),
            child: SizedBox(
              width: 222.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Type your text here',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb8b8b8),
                  height: 2.4,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(26.76, 71.0),
            child: SizedBox(
              width: 222.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'District',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb8b8b8),
                  height: 2.4,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(26.76, 120.0),
            child: SizedBox(
              width: 222.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb8b8b8),
                  height: 2.4,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(303.67, 87.3),
            child: SvgPicture.string(
              _shapeSVG_3148fe4e52b84509abf9fd06e538113d,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(-3.0, 579.0),
            child: Container(
              width: 367.0,
              height: 62.0,
              decoration: BoxDecoration(
                color: const Color(0xff1473e6),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x29000000),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(92.0, 594.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'SEND',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffffffff),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(142.0, 593.0),
            child: SizedBox(
              width: 31.0,
              height: 15.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 14,
                  color: const Color(0xffffffff),
                  height: 2.142857142857143,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(23.5, 119.5),
            child: SvgPicture.string(
              _shapeSVG_b651d3039d3f4f2ea951f65159fb544b,
              allowDrawingOutsideViewBox: true,
            ),
          ),
        ],
      ),
    );
  }
}

const String _shapeSVG_82e45c73dbe7466d94cdb19d33a84ba3 =
    '<svg viewBox="35.0 38.0 16.0 14.0" ><path transform="translate(35.0, 38.0)" d="M 0 14.00040054321289 L 0 11.99970054626465 L 8.000100135803223 11.99970054626465 L 8.000100135803223 14.00040054321289 L 0 14.00040054321289 Z M 0 8.000100135803223 L 0 6.00029993057251 L 16.00020027160645 6.00029993057251 L 16.00020027160645 8.000100135803223 L 0 8.000100135803223 Z M 0 1.999800086021423 L 0 0 L 16.00020027160645 0 L 16.00020027160645 1.999800086021423 L 0 1.999800086021423 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_b575a33ae5e6449ca24548e84d57e2a2 =
    '<svg viewBox="-1.0 62.0 360.0 548.0" ><path transform="translate(-1.0, 62.0)" d="M 360 0 L 360 548 L 0 548 L 360 0 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_3148fe4e52b84509abf9fd06e538113d =
    '<svg viewBox="303.7 87.3 14.7 64.4" ><path transform="matrix(0.5, 0.866025, -0.866025, 0.5, 312.33, 87.3)" d="M 6 0 L 12 10 L 0 10 Z" fill="#ffffff" stroke="#707070" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="matrix(0.5, 0.866025, -0.866025, 0.5, 312.33, 136.3)" d="M 6 0 L 12 10 L 0 10 Z" fill="#ffffff" stroke="#707070" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_b651d3039d3f4f2ea951f65159fb544b =
    '<svg viewBox="23.5 119.5 314.0 138.0" ><path transform="translate(23.5, 119.5)" d="M 0 0 L 314 0" fill="none" stroke="#bcbcbc" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(23.5, 164.5)" d="M 0 0 L 314 0" fill="none" stroke="#bcbcbc" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(23.5, 257.5)" d="M 0 0 L 314 0" fill="none" stroke="#bcbcbc" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
