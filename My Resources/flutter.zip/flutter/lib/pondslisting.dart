import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:flutter_svg/flutter_svg.dart';

class pondslisting extends StatelessWidget {
  pondslisting({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Container(
            width: 360.0,
            height: 109.0,
            decoration: BoxDecoration(
              color: const Color(0xff1473e6),
            ),
          ),
          Transform.translate(
            offset: Offset(12.0, 0.0),
            child: Container(
              width: 375.0,
              height: 20.0,
              decoration: BoxDecoration(),
            ),
          ),
          Transform.translate(
            offset: Offset(285.0, -9.0),
            child:
                // Adobe XD layer: 'Menu' (group)
                Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(35.0, 37.0),
                  child: Container(
                    width: 16.0,
                    height: 16.0,
                    decoration: BoxDecoration(),
                  ),
                ),
                Transform.translate(
                  offset: Offset(35.0, 38.0),
                  child: SvgPicture.string(
                    _shapeSVG_90d7463f081a46379307e9ac2f5febaf,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 55.0),
            child: Container(
              width: 315.0,
              height: 44.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x29000000),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 120.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(26.0, 350.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 237.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(26.0, 467.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(36.78, 66.0),
            child: Stack(
              children: <Widget>[
                Transform(
                  transform: Matrix4(
                      0.87462,
                      0.48481,
                      0.0,
                      0.0,
                      -0.48481,
                      0.87462,
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      1.0,
                      0.0,
                      6.42,
                      0.0,
                      0.0,
                      1.0),
                  child: Container(
                    width: 13.2,
                    height: 13.2,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(6.62, 6.62)),
                      color: const Color(0xffffffff),
                      border: Border.all(
                          width: 2.0, color: const Color(0xff707070)),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(12.47, 13.25),
                  child: SvgPicture.string(
                    _shapeSVG_ea9cb02fc5aa4d978f2a5ba2e466206f,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(66.76, 60.0),
            child: SizedBox(
              width: 222.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Search for fish ponds',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffb8b8b8),
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(111.0, 126.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Zaliana',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(80.0, 17.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'LIST OF POND',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffffffff),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(114.0, 356.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Dilmawii',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(111.0, 243.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Ch. Thuama',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(114.0, 473.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Palaka',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(36.0, 142.0),
            child:
                // Adobe XD layer: 'Low-Hills-Angling-C…' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(39.0, 372.0),
            child:
                // Adobe XD layer: 'pond-lake-category-…' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(36.0, 259.0),
            child:
                // Adobe XD layer: 'Pond' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(39.0, 489.0),
            child:
                // Adobe XD layer: 'the-pond' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(113.0, 144.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Khawdai Peng, Serchhip',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(114.0, 374.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Lungdai',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(113.0, 261.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Kolasib',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(114.0, 491.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tuirini',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(113.5, 180.5),
            child: SvgPicture.string(
              _shapeSVG_4d44551a0e45400885b6de587e93a552,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(132.0, 187.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 1',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(135.0, 417.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 8',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(132.0, 304.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 6',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(135.0, 534.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 12',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(116.0, 176.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(119.0, 406.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(116.0, 293.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(119.0, 523.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(261.0, 179.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '12 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(264.0, 409.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '08 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(261.0, 296.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '10 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(264.0, 526.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '05 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(245.0, 176.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(248.0, 406.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(245.0, 293.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(248.0, 523.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(0.0, 580.0),
            child: Container(
              width: 367.0,
              height: 62.0,
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x29000000),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(24.0, 603.0),
            child: SizedBox(
              width: 74.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Sort',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xffacacac),
                  height: 2,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(139.0, 603.0),
            child: SizedBox(
              width: 80.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Filters',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xffacacac),
                  height: 2,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(258.0, 603.0),
            child: SizedBox(
              width: 80.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Download',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xffacacac),
                  height: 2,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 28.0),
            child:
                // Adobe XD layer: 'Backward arrow' (component)
                Container(),
          ),
          Transform.translate(
            offset: Offset(56.69, 592.0),
            child: SvgPicture.string(
              _shapeSVG_745914b465984cad966862d1504aa444,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(-48.0, 0.0),
            child: Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(103.0, 593.0),
                  child: Container(
                    width: 16.0,
                    height: 16.0,
                    decoration: BoxDecoration(
                      color: const Color(0xffacacac),
                      border: Border.all(
                          width: 1.0, color: const Color(0xff707070)),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Stack(
            children: <Widget>[
              Transform.translate(
                offset: Offset(170.0, 592.0),
                child: Container(
                  width: 16.0,
                  height: 16.0,
                  decoration: BoxDecoration(
                    color: const Color(0xffacacac),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ),
            ],
          ),
          Stack(
            children: <Widget>[
              Transform.translate(
                offset: Offset(291.0, 592.0),
                child: Container(
                  width: 16.0,
                  height: 16.0,
                  decoration: BoxDecoration(
                    color: const Color(0xffacacac),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

const String _shapeSVG_90d7463f081a46379307e9ac2f5febaf =
    '<svg viewBox="35.0 38.0 16.0 14.0" ><path transform="translate(35.0, 38.0)" d="M 0 14.00040054321289 L 0 11.99970054626465 L 8.000100135803223 11.99970054626465 L 8.000100135803223 14.00040054321289 L 0 14.00040054321289 Z M 0 8.000100135803223 L 0 6.00029993057251 L 16.00020027160645 6.00029993057251 L 16.00020027160645 8.000100135803223 L 0 8.000100135803223 Z M 0 1.999800086021423 L 0 0 L 16.00020027160645 0 L 16.00020027160645 1.999800086021423 L 0 1.999800086021423 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_ea9cb02fc5aa4d978f2a5ba2e466206f =
    '<svg viewBox="12.5 13.3 3.2 3.5" ><path transform="translate(12.47, 13.25)" d="M 0 0 L 3.248742818832397 3.466055393218994" fill="none" stroke="#707070" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _shapeSVG_4d44551a0e45400885b6de587e93a552 =
    '<svg viewBox="113.5 180.5 218.0 373.0" ><path transform="translate(113.5, 180.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(116.5, 410.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(113.5, 297.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(116.5, 527.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(220.5, 184.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(223.5, 414.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(220.5, 301.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(223.5, 531.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_745914b465984cad966862d1504aa444 =
    '<svg viewBox="56.7 592.0 250.3 17.0" ><g transform="translate(-48.0, 0.0)"><g transform="translate(101.02, 591.02)"><path  d="M 8.774495124816895 4.529979705810547 L 7.066393852233887 4.529979705810547 L 7.066393852233887 17.98420524597168 L 5.381690502166748 17.98420524597168 L 5.381690502166748 4.529979705810547 L 3.673588752746582 4.529979705810547 L 6.224041938781738 1.984205961227417 L 8.774495124816895 4.529979705810547 Z" fill="#acacac" stroke="none" stroke-width="0.04679730907082558" stroke-miterlimit="4" stroke-linecap="butt" /><path  d="M 11.19859600067139 15.43843173980713 L 12.90669727325439 15.43843173980713 L 12.90669727325439 1.984205961227417 L 14.59140014648438 1.984205961227417 L 14.59140014648438 15.43843173980713 L 16.29482269287109 15.43843173980713 L 13.74904918670654 17.98420524597168 L 11.19859600067139 15.43843173980713 Z" fill="#acacac" stroke="none" stroke-width="0.04679730907082558" stroke-miterlimit="4" stroke-linecap="butt" /></g></g><g transform=""><path transform="translate(167.62, 589.19)" d="M 2.433333396911621 2.809523820877075 L 7.952381134033203 10.74761867523193 L 7.952381134033203 18.80952453613281 L 12.8095235824585 18.80952453613281 L 12.8095235824585 10.74761867523193 L 18.32857131958008 2.809523820877075 L 2.433333396911621 2.809523820877075 Z M 11.69999980926514 10.01428604125977 L 11.69999980926514 17.90476226806641 L 9.066666603088379 17.90476226806641 L 9.066666603088379 10.01428604125977 L 7.952381134033203 8.414285659790039 L 4.890476226806641 4.014285564422607 L 15.86666774749756 4.014285564422607 L 12.8095235824585 8.414285659790039 L 11.69999980926514 10.01428604125977 Z" fill="#acacac" stroke="none" stroke-width="0.0476190485060215" stroke-miterlimit="4" stroke-linecap="butt" /></g><g transform=""><g transform="translate(289.76, 591.47)"><path  d="M 6.942653656005859 10.51228809356689 L 8.537410736083984 10.51228809356689 L 8.537410736083984 1.315128326416016 L 10.11032199859619 1.315128326416016 L 10.11032199859619 10.51228809356689 L 11.70070934295654 10.51228809356689 L 9.32386589050293 12.88476181030273 L 6.942653656005859 10.51228809356689 Z" fill="#acacac" stroke="none" stroke-width="0.0436919704079628" stroke-miterlimit="4" stroke-linecap="butt" /><path  d="M 17.24085235595703 10.38558101654053 L 17.24085235595703 15.73784828186035 L 1.240851998329163 15.73784828186035 L 1.240851998329163 10.38558101654053 L 2.953577041625977 10.38558101654053 L 2.953577041625977 14.02949237823486 L 15.52812576293945 14.02949237823486 L 15.52812576293945 10.38558101654053 L 17.24085235595703 10.38558101654053 Z" fill="#acacac" stroke="none" stroke-width="0.0436919704079628" stroke-miterlimit="4" stroke-linecap="butt" /></g></g></svg>';
