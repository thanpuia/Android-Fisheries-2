import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:flutter_svg/flutter_svg.dart';

class Detailsofponds extends StatelessWidget {
  Detailsofponds({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Transform.translate(
            offset: Offset(-5.0, 275.0),
            child: SvgPicture.string(
              _shapeSVG_8e9864f3f46b488f9c59d73b31dc597a,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Container(
            width: 360.0,
            height: 109.0,
            decoration: BoxDecoration(
              color: const Color(0xff1473e6),
            ),
          ),
          Transform.translate(
            offset: Offset(12.0, 0.0),
            child: Container(
              width: 375.0,
              height: 20.0,
              decoration: BoxDecoration(),
            ),
          ),
          Transform.translate(
            offset: Offset(285.0, -9.0),
            child:
                // Adobe XD layer: 'Menu' (group)
                Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(35.0, 37.0),
                  child: Container(
                    width: 16.0,
                    height: 16.0,
                    decoration: BoxDecoration(),
                  ),
                ),
                Transform.translate(
                  offset: Offset(35.0, 38.0),
                  child: SvgPicture.string(
                    _shapeSVG_235697cc91844fdea9d87ba80a6d24d5,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 55.0),
            child: Container(
              width: 315.0,
              height: 44.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x29000000),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(36.78, 66.0),
            child: Stack(
              children: <Widget>[
                Transform(
                  transform: Matrix4(
                      0.87462,
                      0.48481,
                      0.0,
                      0.0,
                      -0.48481,
                      0.87462,
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      1.0,
                      0.0,
                      6.42,
                      0.0,
                      0.0,
                      1.0),
                  child: Container(
                    width: 13.2,
                    height: 13.2,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(6.62, 6.62)),
                      color: const Color(0xffffffff),
                      border: Border.all(
                          width: 2.0, color: const Color(0xff707070)),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(12.47, 13.25),
                  child: SvgPicture.string(
                    _shapeSVG_5f1559a7a19d493b8653fe0ac1091099,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(66.76, 60.0),
            child: SizedBox(
              width: 222.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Search for fish ponds',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffb8b8b8),
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(80.0, 17.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'DETAIL OF POND',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffffffff),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 28.0),
            child:
                // Adobe XD layer: 'Backward arrow' (component)
                Container(),
          ),
          Transform.translate(
            offset: Offset(0.0, 108.0),
            child:
                // Adobe XD layer: 'Pond' (shape)
                Container(
              width: 360.0,
              height: 169.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
                border: Border.all(width: 1.0, color: const Color(0xff707070)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(90.0, 291.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Ch. Thuama',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 16,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.5,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(92.0, 319.5),
            child: SizedBox(
              width: 173.0,
              height: 35.0,
              child: SingleChildScrollView(
                  child: Text(
                'Diakkawng\nKolasib',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(20.0, 374.33),
            child: SizedBox(
              width: 104.0,
              height: 83.0,
              child: SingleChildScrollView(
                  child: Text(
                'Father\'s Name\nEPIC/AadhaarContact No.\nName of Scheme',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb7b7b7),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(22.0, 481.33),
            child: SizedBox(
              width: 104.0,
              height: 83.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil\nArea (Ha.)',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb7b7b7),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(127.0, 375.33),
            child: SizedBox(
              width: 220.0,
              height: 84.0,
              child: SingleChildScrollView(
                  child: Text(
                ': Kunga\n: AP10323NP\n: +91 7895-568-785\n:',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.6666666666666667,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(127.0, 483.33),
            child: SizedBox(
              width: 220.0,
              height: 38.0,
              child: SingleChildScrollView(
                  child: Text(
                ': Tehsil 1\n: 12 Ha.',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.6666666666666667,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(19.0, 292.0),
            child:
                // Adobe XD layer: 'asian-farmers-hold-…' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(133.0, 440.0),
            child: Container(
              width: 46.0,
              height: 20.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xfff8f4f4),
                border: Border.all(width: 1.0, color: const Color(0xffe2e2e2)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(133.0, 464.0),
            child: Container(
              width: 46.0,
              height: 20.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xfff8f4f4),
                border: Border.all(width: 1.0, color: const Color(0xffe2e2e2)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(135.0, 436.33),
            child: SizedBox(
              width: 39.0,
              height: 13.0,
              child: SingleChildScrollView(
                  child: Text(
                'NLUP',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(135.0, 460.33),
            child: SizedBox(
              width: 39.0,
              height: 13.0,
              child: SingleChildScrollView(
                  child: Text(
                'RKVY',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(187.0, 434.33),
            child: SizedBox(
              width: 152.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'New Pond ',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb7b7b7),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(187.0, 459.33),
            child: SizedBox(
              width: 152.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Rearing',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb7b7b7),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
        ],
      ),
    );
  }
}

const String _shapeSVG_8e9864f3f46b488f9c59d73b31dc597a =
    '<svg viewBox="-5.0 275.0 371.0 90.0" ><path transform="translate(-5.0, 256.0)" d="M 0 19 L 362 19 L 371 109 L 0 109 L 0 19 Z" fill="#f1f1f1" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_235697cc91844fdea9d87ba80a6d24d5 =
    '<svg viewBox="35.0 38.0 16.0 14.0" ><path transform="translate(35.0, 38.0)" d="M 0 14.00040054321289 L 0 11.99970054626465 L 8.000100135803223 11.99970054626465 L 8.000100135803223 14.00040054321289 L 0 14.00040054321289 Z M 0 8.000100135803223 L 0 6.00029993057251 L 16.00020027160645 6.00029993057251 L 16.00020027160645 8.000100135803223 L 0 8.000100135803223 Z M 0 1.999800086021423 L 0 0 L 16.00020027160645 0 L 16.00020027160645 1.999800086021423 L 0 1.999800086021423 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_5f1559a7a19d493b8653fe0ac1091099 =
    '<svg viewBox="12.5 13.3 3.2 3.5" ><path transform="translate(12.47, 13.25)" d="M 0 0 L 3.248742818832397 3.466055393218994" fill="none" stroke="#707070" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
