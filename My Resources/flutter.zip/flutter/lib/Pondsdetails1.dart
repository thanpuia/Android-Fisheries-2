import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:flutter_svg/flutter_svg.dart';

class Pondsdetails1 extends StatelessWidget {
  Pondsdetails1({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Transform.translate(
            offset: Offset(538.0, 100.0),
            child: Container(
              width: 1242.0,
              height: 980.0,
              decoration: BoxDecoration(
                color: const Color(0xfff1f1f1),
              ),
            ),
          ),
          Container(
            width: 1920.0,
            height: 100.0,
            decoration: BoxDecoration(
              color: const Color(0xff1473e6),
            ),
          ),
          Transform.translate(
            offset: Offset(187.56, 29.0),
            child: Text.rich(
              TextSpan(
                style: TextStyle(
                  fontFamily: 'Arial',
                  fontSize: 24,
                  color: const Color(0xffffffff),
                ),
                children: [
                  TextSpan(
                    text: 'FISH-INFO\n',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: 'MIZORAM',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Transform.translate(
            offset: Offset(145.01, 31.52),
            child:
                // Adobe XD layer: 'fish' (group)
                SvgPicture.string(
              _shapeSVG_66873201e36e4cd691908aff2bb3e585,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(140.0, 31.52),
            child:
                // Adobe XD layer: 'fish' (group)
                Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(31.38, 2.61),
                  child: Container(
                    width: 5.3,
                    height: 5.3,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(2.65, 2.65)),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(13.34, 32.7),
                  child: Container(
                    width: 5.2,
                    height: 5.2,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(2.61, 2.61)),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(0.0, 11.04),
                  child: Container(
                    width: 5.0,
                    height: 5.0,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(2.5, 2.5)),
                      color: const Color(0xffffffff),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(699.79, 34.0),
            child: Stack(
              children: <Widget>[
                Transform(
                  transform: Matrix4(
                      0.87462,
                      0.48481,
                      0.0,
                      0.0,
                      -0.48481,
                      0.87462,
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      1.0,
                      0.0,
                      6.42,
                      0.0,
                      0.0,
                      1.0),
                  child: Container(
                    width: 13.2,
                    height: 13.2,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.elliptical(6.62, 6.62)),
                      border: Border.all(
                          width: 2.0, color: const Color(0xffbed4ef)),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(12.47, 13.25),
                  child: SvgPicture.string(
                    _shapeSVG_ce57c56769464e07ad15dd594ac71984,
                    allowDrawingOutsideViewBox: true,
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(733.76, 28.0),
            child: SizedBox(
              width: 222.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Search for fish ponds',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xffbed4ef),
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(1359.0, 40.0),
            child: SizedBox(
              width: 421.0,
              height: 44.0,
              child: SingleChildScrollView(
                  child: Text(
                'Home        Ponds        Farmers         About ',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 16,
                  color: const Color(0xffffffff),
                  height: 1.125,
                ),
                textAlign: TextAlign.right,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(692.5, 60.5),
            child: SvgPicture.string(
              _shapeSVG_6050801848e84a5fad36270f87a45ec3,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(142.0, 100.0),
            child: Container(
              width: 396.0,
              height: 980.0,
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(465.53, 144.93),
            child: SvgPicture.string(
              _shapeSVG_0fed42e6004f4a4aa8987089a6209ae0,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(176.0, 1025.0),
            child: SizedBox(
              width: 320.0,
              height: 44.0,
              child: SingleChildScrollView(
                  child: Text(
                'Directorate of Fisheries, Government of Mizoram',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff1e1e1e),
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(180.0, 937.0),
            child: SizedBox(
              width: 320.0,
              height: 44.0,
              child: SingleChildScrollView(
                  child: Text(
                '1  2  3  4  5 ….. 10',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff1e1e1e),
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(157.0, 525.96),
            child: Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(166.98, 467.87),
                  child:
                      // Adobe XD layer: 'Emblem_of_India' (group)
                      Stack(
                    children: <Widget>[
                      Transform.translate(
                        offset: Offset(8.5, 21.48),
                        child:
                            // Adobe XD layer: 'circle9' (shape)
                            Container(
                          width: 0.4,
                          height: 0.4,
                          decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.elliptical(0.22, 0.22)),
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(6.48, 1.89),
                        child:
                            // Adobe XD layer: 'path11' (shape)
                            SvgPicture.string(
                          _shapeSVG_198d38e6dac64b7c99fa16be377ccdd2,
                          allowDrawingOutsideViewBox: true,
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.16, 23.08),
                        child:
                            // Adobe XD layer: 'rect23' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.09, 23.35),
                        child:
                            // Adobe XD layer: 'rect25' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.07, 23.61),
                        child:
                            // Adobe XD layer: 'rect27' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(12.97, 20.2),
                        child:
                            // Adobe XD layer: 'rect29' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.16, 20.2),
                        child:
                            // Adobe XD layer: 'rect31' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.19, 20.51),
                        child:
                            // Adobe XD layer: 'rect33' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(12.78, 19.93),
                        child:
                            // Adobe XD layer: 'rect35' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.41, 20.53),
                        child:
                            // Adobe XD layer: 'rect37' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.73, 21.28),
                        child:
                            // Adobe XD layer: 'rect39' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.96, 20.8),
                        child:
                            // Adobe XD layer: 'rect41' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.73, 21.06),
                        child:
                            // Adobe XD layer: 'rect43' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.96, 20.57),
                        child:
                            // Adobe XD layer: 'rect45' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.69, 20.55),
                        child:
                            // Adobe XD layer: 'rect47' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.41, 20.24),
                        child:
                            // Adobe XD layer: 'rect49' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(13.73, 20.83),
                        child:
                            // Adobe XD layer: 'rect51' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(10.69, 23.57),
                        child:
                            // Adobe XD layer: 'rect53' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(10.72, 23.83),
                        child:
                            // Adobe XD layer: 'rect55' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(10.95, 23.58),
                        child:
                            // Adobe XD layer: 'rect57' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(10.47, 23.85),
                        child:
                            // Adobe XD layer: 'rect59' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(10.94, 23.83),
                        child:
                            // Adobe XD layer: 'rect61' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.2, 23.83),
                        child:
                            // Adobe XD layer: 'rect63' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.37, 23.53),
                        child:
                            // Adobe XD layer: 'rect65' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.2, 22.95),
                        child:
                            // Adobe XD layer: 'rect67' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(10.95, 23.22),
                        child:
                            // Adobe XD layer: 'rect69' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.2, 23.22),
                        child:
                            // Adobe XD layer: 'rect71' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.17, 23.53),
                        child:
                            // Adobe XD layer: 'rect73' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.49, 22.37),
                        child:
                            // Adobe XD layer: 'rect75' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.68, 22.95),
                        child:
                            // Adobe XD layer: 'rect77' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.41, 23.22),
                        child:
                            // Adobe XD layer: 'rect79' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.44, 22.95),
                        child:
                            // Adobe XD layer: 'rect81' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.45, 22.69),
                        child:
                            // Adobe XD layer: 'rect83' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.25, 20.14),
                        child:
                            // Adobe XD layer: 'rect85' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.32, 20.7),
                        child:
                            // Adobe XD layer: 'rect87' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.25, 19.87),
                        child:
                            // Adobe XD layer: 'rect89' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.03, 19.87),
                        child:
                            // Adobe XD layer: 'rect91' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(11.28, 20.39),
                        child:
                            // Adobe XD layer: 'rect93' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.13, 21.31),
                        child:
                            // Adobe XD layer: 'rect95' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.13, 21.12),
                        child:
                            // Adobe XD layer: 'rect97' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.35, 20.45),
                        child:
                            // Adobe XD layer: 'rect99' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.32, 20.13),
                        child:
                            // Adobe XD layer: 'rect101' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.93, 20.45),
                        child:
                            // Adobe XD layer: 'rect103' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.32, 19.87),
                        child:
                            // Adobe XD layer: 'rect105' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.71, 19.87),
                        child:
                            // Adobe XD layer: 'rect107' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.93, 20.84),
                        child:
                            // Adobe XD layer: 'rect109' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.38, 21.33),
                        child:
                            // Adobe XD layer: 'rect111' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.13, 19.87),
                        child:
                            // Adobe XD layer: 'rect113' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.98, 19.85),
                        child:
                            // Adobe XD layer: 'rect115' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.5, 19.87),
                        child:
                            // Adobe XD layer: 'rect117' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.5, 20.13),
                        child:
                            // Adobe XD layer: 'rect119' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.93, 21.11),
                        child:
                            // Adobe XD layer: 'rect121' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.23, 20.48),
                        child:
                            // Adobe XD layer: 'rect123' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.26, 21.12),
                        child:
                            // Adobe XD layer: 'rect125' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.13, 20.13),
                        child:
                            // Adobe XD layer: 'rect127' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.44, 20.16),
                        child:
                            // Adobe XD layer: 'rect129' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.44, 20.84),
                        child:
                            // Adobe XD layer: 'rect131' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.44, 20.48),
                        child:
                            // Adobe XD layer: 'rect133' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.21, 19.94),
                        child:
                            // Adobe XD layer: 'rect135' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.98, 20.48),
                        child:
                            // Adobe XD layer: 'rect137' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.98, 20.16),
                        child:
                            // Adobe XD layer: 'rect139' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.98, 19.94),
                        child:
                            // Adobe XD layer: 'rect141' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.2, 20.84),
                        child:
                            // Adobe XD layer: 'rect143' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.23, 20.16),
                        child:
                            // Adobe XD layer: 'rect145' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.93, 19.88),
                        child:
                            // Adobe XD layer: 'rect147' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.92, 20.16),
                        child:
                            // Adobe XD layer: 'rect149' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.94, 21.33),
                        child:
                            // Adobe XD layer: 'rect151' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.13, 20.46),
                        child:
                            // Adobe XD layer: 'rect153' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.13, 20.84),
                        child:
                            // Adobe XD layer: 'rect155' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.66, 21.12),
                        child:
                            // Adobe XD layer: 'rect157' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.48, 21.12),
                        child:
                            // Adobe XD layer: 'rect159' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.64, 19.89),
                        child:
                            // Adobe XD layer: 'rect161' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.66, 20.84),
                        child:
                            // Adobe XD layer: 'rect163' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.44, 19.94),
                        child:
                            // Adobe XD layer: 'rect165' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.66, 20.46),
                        child:
                            // Adobe XD layer: 'rect167' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.66, 20.16),
                        child:
                            // Adobe XD layer: 'rect169' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.58, 22.94),
                        child:
                            // Adobe XD layer: 'rect171' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.8, 23.21),
                        child:
                            // Adobe XD layer: 'rect173' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.13, 23.45),
                        child:
                            // Adobe XD layer: 'rect175' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.13, 23.19),
                        child:
                            // Adobe XD layer: 'rect177' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(2.89, 23.17),
                        child:
                            // Adobe XD layer: 'rect179' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.13, 23.73),
                        child:
                            // Adobe XD layer: 'rect181' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.88, 23.78),
                        child:
                            // Adobe XD layer: 'rect183' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.45, 23.78),
                        child:
                            // Adobe XD layer: 'rect185' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.64, 23.77),
                        child:
                            // Adobe XD layer: 'rect187' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.64, 23.22),
                        child:
                            // Adobe XD layer: 'rect189' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.45, 23.52),
                        child:
                            // Adobe XD layer: 'rect191' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.43, 23.24),
                        child:
                            // Adobe XD layer: 'rect193' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.23, 23.51),
                        child:
                            // Adobe XD layer: 'rect195' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.64, 23.5),
                        child:
                            // Adobe XD layer: 'rect197' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.34, 22.94),
                        child:
                            // Adobe XD layer: 'rect199' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.13, 23.77),
                        child:
                            // Adobe XD layer: 'rect201' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.23, 23.78),
                        child:
                            // Adobe XD layer: 'rect203' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.88, 23.52),
                        child:
                            // Adobe XD layer: 'rect205' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.13, 23.52),
                        child:
                            // Adobe XD layer: 'rect207' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.6, 23.19),
                        child:
                            // Adobe XD layer: 'rect209' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.6, 23.77),
                        child:
                            // Adobe XD layer: 'rect211' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.41, 23.77),
                        child:
                            // Adobe XD layer: 'rect213' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.58, 23.5),
                        child:
                            // Adobe XD layer: 'rect215' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.34, 23.19),
                        child:
                            // Adobe XD layer: 'rect217' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.38, 23.46),
                        child:
                            // Adobe XD layer: 'rect219' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.82, 23.77),
                        child:
                            // Adobe XD layer: 'rect221' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.03, 23.5),
                        child:
                            // Adobe XD layer: 'rect223' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(3.8, 23.51),
                        child:
                            // Adobe XD layer: 'rect225' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.03, 23.21),
                        child:
                            // Adobe XD layer: 'rect227' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.2, 23.24),
                        child:
                            // Adobe XD layer: 'rect229' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(4.03, 23.77),
                        child:
                            // Adobe XD layer: 'rect231' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(6.32, 23.21),
                        child:
                            // Adobe XD layer: 'rect233' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.75, 22.31),
                        child:
                            // Adobe XD layer: 'rect235' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.51, 22.1),
                        child:
                            // Adobe XD layer: 'rect237' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.54, 22.36),
                        child:
                            // Adobe XD layer: 'rect239' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.79, 22.63),
                        child:
                            // Adobe XD layer: 'rect241' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.98, 22.31),
                        child:
                            // Adobe XD layer: 'rect243' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(5.75, 22.1),
                        child:
                            // Adobe XD layer: 'rect245' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      Transform.translate(
                        offset: Offset(6.04, 22.58),
                        child:
                            // Adobe XD layer: 'rect247' (shape)
                            Container(
                          width: 0.1,
                          height: 0.1,
                          decoration: BoxDecoration(
                            color: const Color(0xff1e1e1e),
                          ),
                        ),
                      ),
                      // Adobe XD layer: 'path249' (shape)
                      SvgPicture.string(
                        _shapeSVG_2db2929bb665472888304736e5c3dcb9,
                        allowDrawingOutsideViewBox: true,
                      ),
                    ],
                  ),
                ),
                Transform.translate(
                  offset: Offset(166.0, 468.04),
                  child: Container(
                    width: 19.0,
                    height: 29.0,
                    decoration: BoxDecoration(
                      color: const Color(0xff1e1e1e),
                      border: Border.all(
                          width: 1.0, color: const Color(0xff707070)),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(174.0, 122.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(177.0, 352.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(179.0, 695.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(174.0, 239.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(176.0, 582.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(177.0, 469.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(179.0, 812.0),
            child: Container(
              width: 315.0,
              height: 106.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.0),
                color: const Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0x297b7b7b),
                      offset: Offset(0, 3),
                      blurRadius: 6)
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(262.0, 128.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Zaliana',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(265.0, 358.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Dilmawii',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(267.0, 701.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Dilmawii',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(262.0, 245.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Ch. Thuama',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(264.0, 588.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Ch. Thuama',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(265.0, 475.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Palaka',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(267.0, 818.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Palaka',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 14,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.7142857142857142,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(187.0, 144.0),
            child:
                // Adobe XD layer: 'Low-Hills-Angling-C…' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(190.0, 374.0),
            child:
                // Adobe XD layer: 'pond-lake-category-…' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(192.0, 717.0),
            child:
                // Adobe XD layer: 'pond-lake-category-…' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(187.0, 261.0),
            child:
                // Adobe XD layer: 'Pond' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(189.0, 604.0),
            child:
                // Adobe XD layer: 'Pond' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(190.0, 491.0),
            child:
                // Adobe XD layer: 'the-pond' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(192.0, 834.0),
            child:
                // Adobe XD layer: 'the-pond' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(264.0, 146.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Khawdai Peng, Serchhip',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(265.0, 376.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Lungdai',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(267.0, 719.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Lungdai',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(264.0, 263.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Kolasib',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(266.0, 606.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Kolasib',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(265.0, 493.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tuirini',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(267.0, 836.0),
            child: SizedBox(
              width: 173.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tuirini',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(264.5, 182.5),
            child: SvgPicture.string(
              _shapeSVG_511b493a0156482fb2acda34c5e3ed48,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(283.0, 189.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 1',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(286.0, 419.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 8',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(288.0, 762.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 8',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(283.0, 306.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 6',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(285.0, 649.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 6',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(286.0, 536.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 12',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(288.0, 879.5),
            child: SizedBox(
              width: 81.0,
              height: 33.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil 12',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(267.0, 178.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(270.0, 408.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(272.0, 751.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(267.0, 295.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(269.0, 638.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(270.0, 525.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(272.0, 868.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(412.0, 181.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '12 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(415.0, 411.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '08 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(417.0, 754.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '08 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(412.0, 298.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '10 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(414.0, 641.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '10 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(415.0, 528.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '05 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(417.0, 871.0),
            child: SizedBox(
              width: 69.0,
              height: 17.0,
              child: SingleChildScrollView(
                  child: Text(
                '05 ha',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(396.0, 178.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(399.0, 408.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(401.0, 751.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(396.0, 295.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(398.0, 638.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(399.0, 525.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(401.0, 868.0),
            child: SizedBox(
              width: 13.0,
              height: 14.0,
              child: SingleChildScrollView(
                  child: Text(
                '',
                style: TextStyle(
                  fontFamily: 'Font Awesome 5 Free',
                  fontSize: 9,
                  color: const Color(0xff1473e6),
                  height: 3.3333333333333335,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(592.0, 122.0),
            child:
                // Adobe XD layer: 'Pond' (shape)
                Container(
              width: 485.0,
              height: 315.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
                border: Border.all(width: 1.0, color: const Color(0xff707070)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(592.0, 437.0),
            child: Container(
              width: 485.0,
              height: 302.0,
              decoration: BoxDecoration(
                color: const Color(0xffffffff),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(704.0, 457.0),
            child: SizedBox(
              width: 184.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Ch. Thuama',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 16,
                  color: const Color(0xff1d1d1d),
                  fontWeight: FontWeight.w500,
                  height: 1.5,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(706.0, 485.5),
            child: SizedBox(
              width: 173.0,
              height: 35.0,
              child: SingleChildScrollView(
                  child: Text(
                'Diakkawng\nKolasib',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.25,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(633.0, 458.0),
            child:
                // Adobe XD layer: 'asian-farmers-hold-…' (shape)
                Container(
              width: 61.0,
              height: 61.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.elliptical(30.5, 30.5)),
                image: DecorationImage(
                  image: const AssetImage(''),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(633.0, 542.33),
            child: SizedBox(
              width: 104.0,
              height: 83.0,
              child: SingleChildScrollView(
                  child: Text(
                'Father\'s Name\nEPIC/AadhaarContact No.\nName of Scheme',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb7b7b7),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(635.0, 649.33),
            child: SizedBox(
              width: 104.0,
              height: 83.0,
              child: SingleChildScrollView(
                  child: Text(
                'Tehsil\nArea (Ha.)',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb7b7b7),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(740.0, 543.33),
            child: SizedBox(
              width: 220.0,
              height: 84.0,
              child: SingleChildScrollView(
                  child: Text(
                ': Kunga\n: AP10323NP\n: +91 7895-568-785\n:',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.6666666666666667,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(740.0, 651.33),
            child: SizedBox(
              width: 220.0,
              height: 38.0,
              child: SingleChildScrollView(
                  child: Text(
                ': Tehsil 1\n: 12 Ha.',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  color: const Color(0xff6a707b),
                  height: 1.6666666666666667,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(746.0, 608.0),
            child: Container(
              width: 46.0,
              height: 20.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xfff8f4f4),
                border: Border.all(width: 1.0, color: const Color(0xffe2e2e2)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(746.0, 632.0),
            child: Container(
              width: 46.0,
              height: 20.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: const Color(0xfff8f4f4),
                border: Border.all(width: 1.0, color: const Color(0xffe2e2e2)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(748.0, 604.33),
            child: SizedBox(
              width: 39.0,
              height: 13.0,
              child: SingleChildScrollView(
                  child: Text(
                'NLUP',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(748.0, 628.33),
            child: SizedBox(
              width: 39.0,
              height: 13.0,
              child: SingleChildScrollView(
                  child: Text(
                'RKVY',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xff6a707b),
                  height: 2,
                ),
                textAlign: TextAlign.center,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(800.0, 602.33),
            child: SizedBox(
              width: 152.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'New Pond ',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb7b7b7),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(800.0, 627.33),
            child: SizedBox(
              width: 152.0,
              height: 21.0,
              child: SingleChildScrollView(
                  child: Text(
                'Rearing',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  color: const Color(0xffb7b7b7),
                  height: 2,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(592.5, 533.5),
            child: SvgPicture.string(
              _shapeSVG_298da0ee66424685800a647fdc639a63,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(1313.0, 1016.0),
            child: Container(
              width: 467.0,
              height: 65.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20.0),
                  topRight: Radius.circular(20.0),
                ),
                color: const Color(0xff1473e6),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(1352.24, 1036.5),
            child: SvgPicture.string(
              _shapeSVG_2a380d272e1b4698ad9d156d36996992,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(1352.37, 1030.35),
            child: Stack(
              children: <Widget>[
                Transform.translate(
                  offset: Offset(-0.37, -0.35),
                  child: Container(
                    width: 37.0,
                    height: 41.0,
                    decoration: BoxDecoration(
                      color: const Color(0xffffffff),
                      border: Border.all(
                          width: 1.0, color: const Color(0xff707070)),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Transform.translate(
            offset: Offset(1399.0, 1037.0),
            child: SizedBox(
              width: 217.0,
              height: 46.0,
              child: SingleChildScrollView(
                  child: Text(
                'Send SMS',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 18,
                  color: const Color(0xffffffff),
                  height: 1.3333333333333333,
                ),
                textAlign: TextAlign.left,
              )),
            ),
          ),
          Transform.translate(
            offset: Offset(1721.0, 1046.0),
            child: SvgPicture.string(
              _shapeSVG_26d44933b5c045d4a766aa7c633f1915,
              allowDrawingOutsideViewBox: true,
            ),
          ),
        ],
      ),
    );
  }
}

const String _shapeSVG_66873201e36e4cd691908aff2bb3e585 =
    '<svg viewBox="145.0 31.5 34.8 39.0" ><g transform="translate(140.0, 31.52)"><path transform="translate(-293.61, -98.14)" d="M 325.8002014160156 113.2454147338867 C 326.6676940917969 112.9405899047852 327.1210632324219 111.9870529174805 326.8161926269531 111.1194839477539 C 326.7536926269531 110.9475173950195 326.6676940917969 110.7911911010742 326.5583801269531 110.650505065918 C 324.4870910644531 107.9930648803711 320.9229431152344 106.6409072875977 318.5000305175781 105.9999923706055 C 319.7506408691406 108.3369979858398 320.6806335449219 111.2679672241211 321.0011291503906 114.9415054321289 L 325.8002014160156 113.2454147338867 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-59.1, -217.34)" d="M 65.22013092041016 235.2999877929688 C 64.39162445068359 237.6526184082031 63.61003112792969 241.0760498046875 64.51668548583984 244.093017578125 C 64.78243255615234 244.9761657714844 65.71253967285156 245.4764099121094 66.59574127197266 245.2106628417969 C 66.76770782470703 245.1559753417969 66.93183135986328 245.0778198242188 67.07251739501953 244.9761657714844 L 70.17547607421875 242.7955322265625 C 68.36997985839844 241.0916442871094 66.90056610107422 239.0595092773438 65.84541320800781 236.8085327148438 C 65.60311126708984 236.3160400390625 65.39990234375 235.8158874511719 65.22013092041016 235.2999877929688 L 65.22013092041016 235.2999877929688 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-78.74, -5.5)" d="M 118.3942565917969 34.8153076171875 C 118.2223052978516 34.56518936157227 117.92529296875 34.43231964111328 117.6204681396484 34.46358108520508 C 117.5579376220703 34.47140121459961 110.9612274169922 35.10449600219727 107.2017364501953 31.71235275268555 C 105.4587860107422 30.14133453369141 104.5755920410156 27.91377639770508 104.5755920410156 25.08438873291016 C 104.5755920410156 15.22841358184814 100.2298889160156 10.42157554626465 96.57981872558594 8.123674392700195 C 94.1568603515625 6.599555015563965 91.40560913085938 5.692899703979492 88.55278015136719 5.497499465942383 C 88.2010498046875 5.489684104919434 87.88841247558594 5.700716018676758 87.75555419921875 6.021171569824219 C 84.91835021972656 13.11809635162354 84.65260314941406 19.26147079467773 86.98176574707031 24.27933883666992 C 89.64701843261719 30.02409744262695 95.58717346191406 34.36197280883789 105.1461486816406 37.55089950561523 C 108.3819732666016 38.6295051574707 111.8678741455078 40.99774932861328 111.8678741455078 43.63955688476563 C 111.8678741455078 44.1006965637207 112.2430572509766 44.47587203979492 112.7042083740234 44.47587203979492 C 113.016845703125 44.47587203979492 113.3060455322266 44.29610443115234 113.4467315673828 44.01472854614258 C 113.8062591552734 43.30347061157227 113.6499481201172 42.30302047729492 113.4858093261719 41.24004745483398 C 113.3763732910156 40.64603042602539 113.3216705322266 40.0442008972168 113.3216705322266 39.4345588684082 C 116.7059936523438 39.06719970703125 118.3708038330078 35.81575012207031 118.4411468505859 35.6750602722168 C 118.5896606445313 35.39368438720703 118.5740203857422 35.06541061401367 118.3942565917969 34.8153076171875 L 118.3942565917969 34.8153076171875 Z M 92.07778930664063 15.072096824646 C 91.155517578125 15.072096824646 90.41299438476563 14.32175922393799 90.41299438476563 13.40728855133057 C 90.41299438476563 12.49281597137451 91.16331481933594 11.74248218536377 92.07778930664063 11.74248218536377 C 93.00007629394531 11.74248218536377 93.74259948730469 12.49281597137451 93.74259948730469 13.40728855133057 C 93.74259948730469 14.32175922393799 92.99224853515625 15.072096824646 92.07778930664063 15.072096824646 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></g></svg>';
const String _shapeSVG_ce57c56769464e07ad15dd594ac71984 =
    '<svg viewBox="12.5 13.3 3.2 3.5" ><path transform="translate(12.47, 13.25)" d="M 0 0 L 3.248742818832397 3.466055393218994" fill="none" stroke="#bed4ef" stroke-width="2" stroke-miterlimit="4" stroke-linecap="round" /></svg>';
const String _shapeSVG_6050801848e84a5fad36270f87a45ec3 =
    '<svg viewBox="692.5 60.5 595.0 1.0" ><path transform="translate(692.5, 60.5)" d="M 595 0 L 0 0" fill="none" stroke="#ffffff" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_0fed42e6004f4a4aa8987089a6209ae0 =
    '<svg viewBox="465.5 144.9 46.0 43.9" ><path transform="matrix(0.838671, -0.544639, 0.544639, 0.838671, 465.53, 164.53)" d="M 18 0 L 36 29 L 0 29 Z" fill="#1473e6" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_198d38e6dac64b7c99fa16be377ccdd2 =
    '<svg viewBox="6.5 1.9 4.5 22.0" ><path transform="translate(-6.41, -19.23)" d="M 15.09622097015381 38.69207382202148 C 13.86215400695801 38.70796966552734 12.87471199035645 39.72122573852539 12.89065837860107 40.95513916015625 C 12.9066047668457 42.18925857543945 13.91981029510498 43.17675018310547 15.15377426147461 43.16090774536133 C 16.38779067993164 43.14485931396484 17.37533569335938 42.13159942626953 17.35939025878906 40.8975830078125 C 17.34344482421875 39.66372299194336 16.33018684387207 38.67612838745117 15.09622192382813 38.69207382202148 Z M 17.0760383605957 40.18746948242188 C 17.01614761352539 40.21312713623047 16.98835945129395 40.30195236206055 17.01438331604004 40.39456558227539 C 17.04019927978516 40.48655700683594 17.11001205444336 40.54774856567383 17.17421340942383 40.5390739440918 C 17.17836761474609 40.5604248046875 17.181640625 40.58213424682617 17.18501663208008 40.60379409790039 C 17.07520866394043 40.60078048706055 16.74495315551758 40.63610458374023 16.35636520385742 40.69422912597656 C 16.00315093994141 40.74705505371094 15.70162010192871 40.80351638793945 15.5713996887207 40.83966827392578 C 15.56615257263184 40.81255340576172 15.5584135055542 40.78647994995117 15.54864692687988 40.76128768920898 C 15.67824459075928 40.722900390625 15.96398448944092 40.611328125 16.29159164428711 40.4691047668457 C 16.65337562561035 40.31218338012695 16.95277786254883 40.1670036315918 17.04347038269043 40.10674667358398 C 17.05484771728516 40.13334274291992 17.0658073425293 40.16019821166992 17.0760383605957 40.18746948242188 Z M 16.8176212310791 39.70813369750977 C 16.76697540283203 39.74870681762695 16.76334190368652 39.84126663208008 16.81221961975098 39.92359924316406 C 16.86099433898926 40.00592803955078 16.94457244873047 40.04696273803711 17.00435829162598 40.02156066894531 C 17.01412391662598 40.04166412353516 17.02316093444824 40.06202697753906 17.03225135803223 40.08254623413086 C 16.92602920532227 40.10752868652344 16.61561584472656 40.22710037231445 16.25445365905762 40.38407516479492 C 15.92674160003662 40.52634811401367 15.65014553070068 40.65885543823242 15.53374004364014 40.72731781005859 C 15.52174091339111 40.70264053344727 15.50761222839355 40.67931747436523 15.49151134490967 40.6573486328125 C 15.6068229675293 40.58681106567383 15.85402202606201 40.40526962280273 16.13363265991211 40.18331527709961 C 16.43988990783691 39.94042587280273 16.69025802612305 39.72418975830078 16.76463890075684 39.64097595214844 C 16.78229904174805 39.66336059570313 16.80099868774414 39.68502044677734 16.8176212310791 39.70813369750977 Z M 16.44461631774902 39.31144714355469 C 16.40607452392578 39.36370086669922 16.42664337158203 39.45413589477539 16.49520874023438 39.52093505859375 C 16.56356811523438 39.58778381347656 16.6546745300293 39.60591125488281 16.7059440612793 39.56602096557617 C 16.72064399719238 39.58316040039063 16.7336311340332 39.60165405273438 16.74786186218262 39.61920928955078 C 16.64989852905273 39.67271041870117 16.38228607177734 39.86754989624023 16.07608032226563 40.11064529418945 C 15.79636573791504 40.33259963989258 15.56350421905518 40.53200912475586 15.46865558624268 40.62831115722656 C 15.45073509216309 40.60768890380859 15.43125629425049 40.58857727050781 15.41011524200439 40.57158660888672 C 15.5033016204834 40.47320556640625 15.69502353668213 40.23442459106445 15.90762805938721 39.94795989990234 C 16.14069747924805 39.63411712646484 16.32670593261719 39.36053085327148 16.37709045410156 39.26090240478516 C 16.39963531494141 39.27788925170898 16.42280197143555 39.29362869262695 16.44461822509766 39.31144332885742 Z M 15.46133136749268 40.92210388183594 C 15.46366882324219 41.10795593261719 15.31516170501709 41.26035690307617 15.12930965423584 41.26290130615234 C 14.94350910186768 41.26523971557617 14.79105567932129 41.11663055419922 14.78866672515869 40.93082809448242 C 14.78622436523438 40.74502944946289 14.93483352661133 40.59262847900391 15.12058353424072 40.59018325805664 C 15.30643653869629 40.58779525756836 15.45888996124268 40.73640441894531 15.46133136749268 40.92210388183594 Z M 15.98159408569336 39.02450942993164 C 15.95770168304443 39.08502578735352 16.00107383728027 39.16740798950195 16.08465003967285 39.21415710449219 C 16.16796875 39.26090240478516 16.26053047180176 39.25498199462891 16.29974746704102 39.20335006713867 C 16.31875991821289 39.21623229980469 16.33636856079102 39.23088073730469 16.3549633026123 39.24448776245117 C 16.27408599853516 39.32141494750977 16.06600189208984 39.57879638671875 15.83303833007813 39.8926887512207 C 15.62017345428467 40.17931365966797 15.44668292999268 40.43217086791992 15.37988471984863 40.54966735839844 C 15.35739421844482 40.53445053100586 15.33344745635986 40.52135848999023 15.30835819244385 40.5102424621582 C 15.37307929992676 40.39155578613281 15.49665451049805 40.11090469360352 15.62827777862549 39.77893447875977 C 15.77366638183594 39.41237258911133 15.88316249847412 39.09811401367188 15.90471935272217 38.9915771484375 C 15.93058681488037 39.00217437744141 15.95624732971191 39.01303100585938 15.98159408569336 39.02450942993164 Z M 15.46013641357422 38.86790084838867 C 15.45291614532471 38.93246459960938 15.51582050323486 39.00066757202148 15.60864162445068 39.02419662475586 C 15.70172500610352 39.04788589477539 15.78992462158203 39.01770401000977 15.81407833099365 38.9571418762207 C 15.8363094329834 38.96482467651367 15.85807418823242 38.9734001159668 15.8799934387207 38.98202133178711 C 15.82254409790039 39.07453155517578 15.68702507019043 39.37855529785156 15.54205131530762 39.74496459960938 C 15.41037559509277 40.0770378112793 15.30794239044189 40.36615371704102 15.27386856079102 40.49678802490234 C 15.24841594696045 40.48811721801758 15.22187328338623 40.48141479492188 15.194655418396 40.47726058959961 C 15.22639179229736 40.345947265625 15.27350616455078 40.04280471801758 15.31480026245117 39.68803405761719 C 15.36056137084961 39.29726409912109 15.38513088226318 38.96591567993164 15.37863826751709 38.85647201538086 C 15.40590763092041 38.85984802246094 15.43307590484619 38.86348724365234 15.46013736724854 38.86790084838867 Z M 14.9158239364624 38.85143661499023 C 14.92558860778809 38.9156379699707 15.00402164459229 38.965087890625 15.09970188140869 38.96384048461914 C 15.19538116455078 38.96259689331055 15.27241230010986 38.91117095947266 15.28056812286377 38.84686279296875 C 15.30446243286133 38.84852600097656 15.32814788818359 38.85112380981445 15.35183334350586 38.85371780395508 C 15.32025146484375 38.95880126953125 15.26799869537354 39.28692626953125 15.22254753112793 39.67728042602539 C 15.18109607696533 40.03205490112305 15.15694236755371 40.33774185180664 15.15772151947021 40.47279357910156 C 15.14504814147949 40.47196197509766 15.13221836090088 40.47128677368164 15.11917972564697 40.47144317626953 C 15.10463523864746 40.47159576416016 15.09024715423584 40.47263717651367 15.07617092132568 40.47419357299805 C 15.07294940948486 40.33893585205078 15.04001808166504 40.03413391113281 14.98833560943604 39.68096923828125 C 14.93150806427002 39.29165267944336 14.86979961395264 38.96529388427734 14.8352575302124 38.86130523681641 C 14.86195755004883 38.85756683349609 14.88875865936279 38.85424041748047 14.91582107543945 38.85143661499023 Z M 14.38729953765869 38.974853515625 C 14.41301155090332 39.03469085693359 14.50183486938477 39.06263732910156 14.59444999694824 39.03681945800781 C 14.68644142150879 39.01100540161133 14.74757862091064 38.94129943847656 14.73890495300293 38.87688827514648 C 14.7619686126709 38.87262725830078 14.78534317016602 38.86899185180664 14.80861282348633 38.86530303955078 C 14.80528831481934 38.97500610351563 14.83957004547119 39.30557250976563 14.8965015411377 39.69452667236328 C 14.94813251495361 40.04794692993164 15.00371074676514 40.34947967529297 15.03944873809814 40.47980499267578 C 15.01238632202148 40.48494720458984 14.9862060546875 40.49258422851563 14.96101474761963 40.50234985351563 C 14.9229907989502 40.37264633178711 14.81240463256836 40.08669662475586 14.67117023468018 39.75862503051758 C 14.51534175872803 39.39632034301758 14.37109470367432 39.09645462036133 14.31110000610352 39.00580978393555 C 14.33634376525879 38.99495315551758 14.36158847808838 38.98461532592773 14.38729953765869 38.974853515625 Z M 13.90775966644287 39.23301315307617 C 13.94837951660156 39.28360366821289 14.04094219207764 39.2873420715332 14.12337684631348 39.23851776123047 C 14.20570659637451 39.1895866394043 14.24674224853516 39.10642623901367 14.22144603729248 39.04642868041992 C 14.24300193786621 39.03593826293945 14.26492214202881 39.02617263793945 14.28684234619141 39.01646041870117 C 14.31167125701904 39.12273406982422 14.43025779724121 39.43356704711914 14.58603477478027 39.79529571533203 C 14.72726821899414 40.12337112426758 14.85889339447021 40.40043640136719 14.92704296112061 40.5171012878418 C 14.90231895446777 40.52909851074219 14.87894344329834 40.54312515258789 14.85697174072266 40.5590705871582 C 14.78669261932373 40.44349670410156 14.6061372756958 40.19588470458984 14.38491058349609 39.91554260253906 C 14.14290714263916 39.60835266113281 13.92739582061768 39.35741424560547 13.84449291229248 39.28271865844727 C 13.86568641662598 39.26625442504883 13.88599586486816 39.24869918823242 13.90775966644287 39.23300933837891 Z M 13.51091384887695 39.60570526123047 C 13.5631685256958 39.64408874511719 13.65360164642334 39.623779296875 13.72055625915527 39.55531692504883 C 13.78735542297363 39.48685836791992 13.80548286437988 39.39611434936523 13.7656946182251 39.34453201293945 C 13.78408336639404 39.32879257202148 13.80387306213379 39.31476974487305 13.82283306121826 39.29970550537109 C 13.87596988677979 39.39777374267578 14.06997871398926 39.66590118408203 14.312087059021 39.9728889465332 C 14.53310489654541 40.253173828125 14.73178958892822 40.48666000366211 14.82788467407227 40.58202743530273 C 14.8072624206543 40.59979248046875 14.78809642791748 40.6193733215332 14.7710075378418 40.64046478271484 C 14.67309284210205 40.54696655273438 14.43472576141357 40.35446166992188 14.14883041381836 40.14092254638672 C 13.83576774597168 39.90686798095703 13.56280612945557 39.72002792358398 13.46338653564453 39.66933059692383 C 13.47933387756348 39.64818954467773 13.49413681030273 39.62621688842773 13.51091480255127 39.60569763183594 Z M 13.22371864318848 40.06851959228516 C 13.28418064117432 40.09225845336914 13.36645889282227 40.0491943359375 13.41346836090088 39.96561813354492 C 13.46021556854248 39.88235473632813 13.45424365997314 39.79000091552734 13.4027156829834 39.75046920776367 C 13.41663551330566 39.73011016845703 13.43227100372314 39.71115112304688 13.44686794281006 39.69136047363281 C 13.52363967895508 39.77244186401367 13.78029155731201 39.98135757446289 14.09335327148438 40.21530914306641 C 14.3794059753418 40.42900848388672 14.63164234161377 40.60327529907227 14.74903392791748 40.67049026489258 C 14.73371028900146 40.69282531738281 14.7205171585083 40.71682357788086 14.70934772491455 40.74180603027344 C 14.59081363677979 40.67672348022461 14.31052780151367 40.55231857299805 13.97902584075928 40.41970825195313 C 13.61313724517822 40.27333450317383 13.29929637908936 40.16269302368164 13.19260501861572 40.14072036743164 C 13.20268154144287 40.11651611328125 13.21291542053223 40.09230804443359 13.22371864318848 40.06851959228516 Z M 13.06679916381836 40.5899772644043 C 13.13120746612549 40.59699249267578 13.19940853118896 40.53418731689453 13.22314643859863 40.4414176940918 C 13.24688625335693 40.34849166870117 13.21686267852783 40.26044845581055 13.1561918258667 40.23603439331055 C 13.16455554962158 40.21229934692383 13.17359352111816 40.18892288208008 13.18283939361572 40.16555023193359 C 13.27524662017822 40.22320556640625 13.57880210876465 40.35971450805664 13.94474315643311 40.50593566894531 C 14.27640056610107 40.63870239257813 14.56515407562256 40.74191284179688 14.69589519500732 40.77645492553711 C 14.68696117401123 40.80190658569336 14.68020725250244 40.82829284667969 14.67594814300537 40.85556793212891 C 14.54463672637939 40.82330703735352 14.24175453186035 40.77536392211914 13.88713836669922 40.73297882080078 C 13.49668025970459 40.68618011474609 13.16543769836426 40.66046905517578 13.05599403381348 40.66654586791992 C 13.05921459197998 40.64093780517578 13.06264305114746 40.61532974243164 13.06679725646973 40.58998107910156 Z M 13.04991722106934 41.13418579101563 C 13.11391067504883 41.12426376342773 13.16346549987793 41.04588317871094 13.16227054595947 40.95025634765625 C 13.16117858886719 40.85473251342773 13.10985946655273 40.77780532836914 13.04544925689697 40.769287109375 C 13.04732036590576 40.74383163452148 13.05002117156982 40.71853637695313 13.05282497406006 40.69329071044922 C 13.1578540802002 40.72523498535156 13.48582458496094 40.77837371826172 13.87607479095459 40.82506942749023 C 14.23063945770264 40.86756134033203 14.53627395629883 40.8927001953125 14.67148303985596 40.89233779907227 C 14.67049503326416 40.90553283691406 14.66982078552246 40.91877746582031 14.66997528076172 40.93233108520508 C 14.6701831817627 40.9464111328125 14.67116928100586 40.96022796630859 14.67262363433838 40.97394180297852 C 14.53736305236816 40.97679901123047 14.23245716094971 41.00873947143555 13.8791389465332 41.05933380126953 C 13.49003124237061 41.11501693725586 13.16346454620361 41.17574310302734 13.05921459197998 41.20986938476563 C 13.05568218231201 41.18472671508789 13.05246162414551 41.15958786010742 13.04991626739502 41.13418579101563 Z M 13.17359352111816 41.66463088989258 C 13.23343181610107 41.63891983032227 13.26127433776855 41.55014801025391 13.23540592193604 41.45753479003906 C 13.20959186553955 41.36553955078125 13.13993453979492 41.30445861816406 13.07552433013916 41.31302642822266 C 13.07079792022705 41.28767776489258 13.06669521331787 41.26212310791016 13.06290340423584 41.2364616394043 C 13.17250347137451 41.24009704589844 13.50307083129883 41.2069091796875 13.89217758178711 41.15117263793945 C 14.24585914611816 41.10057830810547 14.54764938354492 41.04582977294922 14.67813014984131 41.01055908203125 C 14.68322086334229 41.03767776489258 14.69075298309326 41.06390762329102 14.70041465759277 41.0890998840332 C 14.57050323486328 41.12675857543945 14.28408908843994 41.23641204833984 13.95565128326416 41.37655258178711 C 13.59324264526367 41.53129196166992 13.29301071166992 41.67449951171875 13.20185089111328 41.73428344726563 C 13.19213771820068 41.71122360229492 13.18247604370117 41.68805313110352 13.17359352111816 41.66463088989258 Z M 13.47725391387939 42.20182800292969 C 13.46224212646484 42.1825065612793 13.44614028930664 42.16401290893555 13.43180274963379 42.14411926269531 C 13.48244857788086 42.10355377197266 13.486083984375 42.01099014282227 13.43720626831055 41.92865753173828 C 13.38843154907227 41.84627532958984 13.30521774291992 41.80529403686523 13.24522304534912 41.83048629760742 C 13.23379611968994 41.80690383911133 13.22288799285889 41.78280258178711 13.21229076385498 41.75880432128906 C 13.31851577758789 41.73428726196289 13.62981128692627 41.61673736572266 13.99211597442627 41.46194839477539 C 14.32060527801514 41.32185745239258 14.5980339050293 41.19095993041992 14.71495819091797 41.12322616577148 C 14.7268533706665 41.14790344238281 14.74077415466309 41.17137908935547 14.75672149658203 41.19345474243164 C 14.64093971252441 41.2633171081543 14.39264965057373 41.44319915771484 14.11163711547852 41.66348648071289 C 13.80382061004639 41.90445327758789 13.55205249786377 42.11918640136719 13.47725391387939 42.20182800292969 Z M 13.80470371246338 42.54096603393555 C 13.84303855895996 42.48850250244141 13.82278060913086 42.39822769165039 13.75411128997803 42.33132171630859 C 13.68580627441406 42.26457595825195 13.59495735168457 42.24629211425781 13.54337692260742 42.28618621826172 C 13.52613162994385 42.2659797668457 13.51070499420166 42.24421310424805 13.49429035186768 42.22348785400391 C 13.59246349334717 42.17066192626953 13.8612699508667 41.97758865356445 14.16882514953613 41.73652267456055 C 14.44989013671875 41.51633453369141 14.68394660949707 41.31837844848633 14.77952289581299 41.22259140014648 C 14.79728698730469 41.24326705932617 14.81681728363037 41.26243209838867 14.83795928955078 41.27952575683594 C 14.74409675598145 41.37712478637695 14.55081558227539 41.61492156982422 14.33634185791016 41.90003967285156 C 14.10135078430176 42.21252822875977 13.91357612609863 42.48517990112305 13.86262130737305 42.58423614501953 C 13.8434534072876 42.56974411010742 13.82335090637207 42.55624008178711 13.80470371246338 42.54096603393555 Z M 14.26751804351807 42.82810974121094 C 14.29130840301514 42.76744079589844 14.24819660186768 42.68531799316406 14.16456699371338 42.63830947875977 C 14.08125019073486 42.5915641784668 13.98884391784668 42.59737777709961 13.94931411743164 42.64900970458984 C 13.92713451385498 42.63384246826172 13.90635871887207 42.61669921875 13.88474941253662 42.60075378417969 C 13.96593761444092 42.52418899536133 14.17578792572021 42.26831817626953 14.41062259674072 41.95582962036133 C 14.62530517578125 41.6703987121582 14.80035305023193 41.41873550415039 14.86793041229248 41.30155181884766 C 14.89021587371826 41.31692504882813 14.91416072845459 41.33022308349609 14.93909358978271 41.34149551391602 C 14.87364482879639 41.459716796875 14.74830532073975 41.73969268798828 14.61465549468994 42.07077789306641 C 14.46718788146973 42.43614959716797 14.3557710647583 42.7495231628418 14.33333015441895 42.85626602172852 C 14.31125450134277 42.84717559814453 14.28917980194092 42.83792877197266 14.26751804351807 42.82810974121094 Z M 14.78897762298584 42.98492813110352 C 14.79604244232178 42.92036056518555 14.73324298858643 42.8521614074707 14.64041996002197 42.82857513427734 C 14.54738998413086 42.80484008789063 14.45929431915283 42.83486175537109 14.43503665924072 42.89553070068359 C 14.40901184082031 42.88639068603516 14.38340473175049 42.87657165527344 14.35795211791992 42.86634063720703 C 14.41581726074219 42.77424240112305 14.55331230163574 42.47115707397461 14.70077991485596 42.10547637939453 C 14.83453178405762 41.77417755126953 14.93862628936768 41.48563385009766 14.97358512878418 41.35515213012695 C 14.99903774261475 41.36419296264648 15.02542400360107 41.37099456787109 15.05258941650391 41.37541198730469 C 15.02002239227295 41.50656509399414 14.97119522094727 41.80939865112305 14.92761516571045 42.16386032104492 C 14.87967014312744 42.55410766601563 14.85292053222656 42.88529586791992 14.85868549346924 42.99474334716797 C 14.83531093597412 42.99172973632813 14.81198883056641 42.98866653442383 14.78897762298584 42.98492813110352 Z M 15.33323860168457 43.00154876708984 C 15.32326602935791 42.93755722045898 15.24498653411865 42.88794708251953 15.14925575256348 42.88914489746094 C 15.05367946624756 42.89023208618164 14.97664833068848 42.94171142578125 14.968337059021 43.00606918334961 C 14.94044303894043 43.00399017333984 14.91280937194824 43.00133895874023 14.88522720336914 42.99817276000977 C 14.91743183135986 42.89345550537109 14.97171211242676 42.56553649902344 15.01970863342285 42.17507934570313 C 15.06334018707275 41.82067108154297 15.08941650390625 41.51519393920898 15.08946800231934 41.37998580932617 C 15.10318183898926 41.3809700012207 15.11689472198486 41.38164520263672 15.13086700439453 41.38148880004883 C 15.14442443847656 41.38133239746094 15.15777397155762 41.38034439086914 15.17096710205078 41.37899398803711 C 15.17330455780029 41.51420593261719 15.20447063446045 41.81921768188477 15.25392150878906 42.17268753051758 C 15.30835819244385 42.56216049194336 15.36804008483887 42.88898849487305 15.40195941925049 42.99313354492188 C 15.37900066375732 42.99625015258789 15.35635375976563 42.99931716918945 15.33323860168457 43.00154495239258 Z M 15.86363220214844 42.87771606445313 C 15.83792018890381 42.81782531738281 15.74909687042236 42.78993225097656 15.65653419494629 42.81600952148438 C 15.56438541412354 42.84182357788086 15.50335311889648 42.91152954101563 15.51202869415283 42.97594451904297 C 15.48434257507324 42.9811897277832 15.45650005340576 42.9857063293457 15.42855548858643 42.98981094360352 C 15.4325532913208 42.88051986694336 15.40040111541748 42.54959106445313 15.34586238861084 42.15996551513672 C 15.29641246795654 41.80617904663086 15.24265098571777 41.50418090820313 15.20769214630127 41.37359619140625 C 15.2349100112915 41.36855697631836 15.26114177703857 41.36128616333008 15.28638744354248 41.35162353515625 C 15.32357788085938 41.48147964477539 15.43250370025635 41.768310546875 15.57155513763428 42.09716415405273 C 15.72499561309814 42.45998764038086 15.86742496490479 42.76084136962891 15.92689895629883 42.8521614074707 C 15.90581035614014 42.86088562011719 15.88492965698242 42.86971664428711 15.86363220214844 42.87771606445313 Z M 16.343017578125 42.61945724487305 C 16.30239677429199 42.56886291503906 16.2098331451416 42.56506729125977 16.12750244140625 42.61405181884766 C 16.04517364501953 42.66282653808594 16.00419235229492 42.74629974365234 16.02948760986328 42.80624389648438 C 16.00377655029297 42.81860733032227 15.97759532928467 42.83055114746094 15.9513635635376 42.84197998046875 C 15.92736721038818 42.73601531982422 15.81059741973877 42.42409515380859 15.65700149536133 42.06111907958984 C 15.51784610748291 41.73215866088867 15.38783073425293 41.45442199707031 15.32046127319336 41.33718490600586 C 15.34518623352051 41.32534027099609 15.36871528625488 41.31157684326172 15.39079284667969 41.29562759399414 C 15.4603443145752 41.41161727905273 15.63949680328369 41.66053009033203 15.85874938964844 41.94216537475586 C 16.09888458251953 42.25070953369141 16.31299209594727 42.50336074829102 16.39532470703125 42.57826614379883 C 16.3778190612793 42.59177017211914 16.36104011535645 42.60641479492188 16.343017578125 42.61945724487305 Z M 16.73970603942871 42.24645233154297 C 16.68740081787109 42.20806121826172 16.59701919555664 42.22853088378906 16.53021812438965 42.29704284667969 C 16.46342086791992 42.36539840698242 16.44524002075195 42.45640563964844 16.48508071899414 42.50777816772461 C 16.46316146850586 42.52658081054688 16.43962860107422 42.54346084594727 16.41693115234375 42.561279296875 C 16.36436462402344 42.46289825439453 16.17212295532227 42.19351959228516 15.9318323135376 41.8851318359375 C 15.71273612976074 41.60354995727539 15.51550579071045 41.36886978149414 15.42008686065674 41.27297973632813 C 15.44070816040039 41.25526809692383 15.45987510681152 41.23568725585938 15.4771728515625 41.214599609375 C 15.57440948486328 41.30876922607422 15.81158351898193 41.5026741027832 16.09623336791992 41.7180290222168 C 16.40784072875977 41.95416641235352 16.67986679077148 42.14277267456055 16.77892303466797 42.19403839111328 C 16.76562690734863 42.21128463745117 16.75357437133789 42.22956848144531 16.73970603942871 42.24645233154297 Z M 17.02679634094238 41.7835807800293 C 16.96617889404297 41.75979232788086 16.8838996887207 41.80290603637695 16.83710098266602 41.88653564453125 C 16.79024887084961 41.96979904174805 16.79627227783203 42.06236267089844 16.84790420532227 42.10178756713867 C 16.83133316040039 42.12588882446289 16.81289672851563 42.14848709106445 16.79544067382813 42.17201232910156 C 16.71913719177246 42.09041213989258 16.46388816833496 41.87994003295898 16.15227890014648 41.64416885375977 C 15.86757850646973 41.42860412597656 15.61627674102783 41.25272369384766 15.49940490722656 41.18483352661133 C 15.51581859588623 41.16099166870117 15.52999877929688 41.13554000854492 15.54179000854492 41.1085319519043 C 15.66073989868164 41.17288970947266 15.94175243377686 41.29562759399414 16.27413940429688 41.42621612548828 C 16.64117050170898 41.57051467895508 16.95579147338867 41.67912673950195 17.06242752075195 41.70026779174805 C 17.05100250244141 41.72836685180664 17.03915786743164 41.75605392456055 17.02679634094238 41.78358459472656 Z M 17.18340682983398 41.26202011108398 C 17.11894607543945 41.25500869750977 17.05074310302734 41.31781005859375 17.02716064453125 41.41068267822266 C 17.00347518920898 41.50371170043945 17.03355026245117 41.59175872802734 17.09416770935059 41.61606597900391 C 17.08715438842773 41.63606643676758 17.0793628692627 41.6556510925293 17.07178115844727 41.67538452148438 C 16.97880172729492 41.61825180053711 16.67451858520508 41.48382186889648 16.30790328979492 41.33988571166992 C 15.97546577453613 41.20914459228516 15.68583011627197 41.10764694213867 15.55508804321289 41.07393264770508 C 15.56381511688232 41.04843139648438 15.5703592300415 41.02204513549805 15.57441139221191 40.99472045898438 C 15.7058277130127 41.02609634399414 16.00917625427246 41.07211685180664 16.36410522460938 41.11237335205078 C 16.75513458251953 41.15683746337891 17.08653259277344 41.18057632446289 17.19587326049805 41.17372131347656 C 17.19223594665527 41.20322418212891 17.18823623657227 41.23272705078125 17.18340682983398 41.26202392578125 Z M 16.37454605102539 41.02007293701172 C 16.01956558227539 40.97986602783203 15.71377468109131 40.95669937133789 15.57877349853516 40.95794677734375 C 15.57955265045166 40.94552993774414 15.58017635345459 40.93317031860352 15.5800199508667 40.92070388793945 C 15.57981300354004 40.9056396484375 15.57887744903564 40.89088439941406 15.57732009887695 40.87639617919922 C 15.71252727508545 40.87260437011719 16.01712417602539 40.83857727050781 16.36997222900391 40.78596115112305 C 16.75918579101563 40.72799301147461 17.08559608459473 40.66519546508789 17.18927383422852 40.63028717041016 C 17.19337844848633 40.65937423706055 17.19701385498047 40.68841171264648 17.19987106323242 40.71786499023438 C 17.13582420349121 40.72783660888672 17.08647918701172 40.80606460571289 17.08767318725586 40.90184783935547 C 17.08881759643555 40.99726867675781 17.14023971557617 41.07429885864258 17.20454597473145 41.08266067504883 C 17.20303916931152 41.1041145324707 17.20070266723633 41.12546157836914 17.19841766357422 41.1468620300293 C 17.09302520751953 41.11569595336914 16.76494979858398 41.06442642211914 16.37454605102539 41.02006912231445 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-9.26, -1.93)" d="M 19.50376129150391 4.155491352081299 C 19.42387199401855 4.10588550567627 19.31344223022461 3.885905742645264 19.06998252868652 3.8890221118927 C 18.82647323608398 3.89219069480896 18.68887519836426 4.194085121154785 18.64056777954102 4.251326560974121 C 18.59246826171875 4.308568000793457 18.67407035827637 4.366588592529297 18.73453330993652 4.339369773864746 C 18.88023376464844 4.273714065551758 18.85987281799316 4.067291259765625 19.09699440002441 4.05295467376709 C 19.28154754638672 4.041787147521973 19.34055519104004 4.230964660644531 19.47093391418457 4.246287822723389 C 19.60146713256836 4.261559009552002 19.58375358581543 4.205148696899414 19.50376319885254 4.155490875244141 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-6.86, -1.87)" d="M 14.00282859802246 4.217930793762207 C 14.08744239807129 4.19445276260376 14.22078132629395 3.999665260314941 14.36746978759766 3.946839094161987 C 14.51395034790039 3.893960952758789 14.635498046875 3.994262933731079 14.70323181152344 4.082047462463379 C 14.74530601501465 4.136536121368408 14.79865074157715 4.204373836517334 14.85355567932129 4.211542129516602 C 14.94211769104004 4.222970008850098 14.93224906921387 4.136951446533203 14.91344451904297 4.134354114532471 C 14.83906173706055 4.123965263366699 14.84836006164551 3.918010711669922 14.71123123168945 3.823473930358887 C 14.62448501586914 3.763739109039307 14.50065231323242 3.741247653961182 14.3484058380127 3.788568019866943 C 14.19610786437988 3.835784435272217 14.07887268066406 3.961902856826782 13.97223281860352 4.042518615722656 C 13.86574935913086 4.123134613037109 13.80975532531738 4.174870014190674 13.80975532531738 4.174870014190674 C 13.80975532531738 4.174870014190674 13.91815948486328 4.241409301757813 14.00282669067383 4.217930793762207 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-8.25, -4.61)" d="M 16.87438583374023 9.282295227050781 C 16.78733062744141 9.28338623046875 16.85630989074707 9.442176818847656 16.75471115112305 9.460409164428711 C 16.67856216430664 9.474174499511719 16.68489837646484 9.296995162963867 16.63934326171875 9.313461303710938 C 16.55602645874023 9.343640327453613 16.64178466796875 9.496613502502441 16.67056083679199 9.525753021240234 C 16.72006416320801 9.576138496398926 16.81491088867188 9.659662246704102 16.87438583374023 9.548452377319336 C 16.91292953491211 9.476354598999023 16.92326736450195 9.281671524047852 16.87438583374023 9.282294273376465 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-7.74, -5.02)" d="M 15.63190269470215 10.10970687866211 C 15.59808731079102 10.1226921081543 15.53071784973145 10.31851959228516 15.61252784729004 10.42889785766602 C 15.68109321594238 10.52130508422852 15.76181221008301 10.5426025390625 15.77625274658203 10.51559162139893 C 15.79692649841309 10.47704982757568 15.70670127868652 10.39139556884766 15.65688705444336 10.35752868652344 C 15.60910034179688 10.32490825653076 15.63190269470215 10.10970687866211 15.63190269470215 10.10970687866211 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-9.29, -4.9)" d="M 18.76055335998535 10.41638374328613 C 18.83862495422363 10.40038585662842 18.94988632202148 10.26377487182617 18.96723556518555 10.14451313018799 C 18.98666191101074 10.00998020172119 18.95373153686523 9.855708122253418 18.93035697937012 9.850202560424805 C 18.87145042419434 9.836281776428223 18.92775726318359 10.04831409454346 18.83955764770508 10.16726493835449 C 18.76055335998535 10.27374839782715 18.60835838317871 10.44754981994629 18.76055335998535 10.41638374328613 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_2db2929bb665472888304736e5c3dcb9 =
    '<svg viewBox="0.0 0.0 17.2 29.2" ><path transform="translate(-3.27, -20.57)" d="M 6.606411933898926 41.69354629516602 C 6.622306823730469 41.64331817626953 6.660277366638184 41.6307487487793 6.72520637512207 41.55828857421875 C 6.791122436523438 41.4846305847168 6.7546067237854 41.36869430541992 6.742815017700195 41.38568115234375 C 6.683495998382568 41.47055435180664 6.635448455810547 41.46775054931641 6.592958927154541 41.55745697021484 C 6.568337917327881 41.60950469970703 6.584492206573486 41.76294326782227 6.606411933898926 41.69354629516602 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.6, -21.18)" d="M 7.349625587463379 42.92063903808594 C 7.329574584960938 42.8644905090332 7.34510612487793 42.61074829101563 7.311394691467285 42.61557769775391 C 7.243192672729492 42.62533950805664 7.237791061401367 42.84641647338867 7.245582580566406 42.91289901733398 C 7.258309364318848 43.02109909057617 7.372272491455078 42.98416900634766 7.349625587463379 42.92063903808594 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-9.0, -1.11)" d="M 18.11648559570313 2.224533557891846 L 18.10656547546387 2.223390817642212 C 18.11004638671875 2.22385835647583 18.11373329162598 2.224273920059204 18.11716079711914 2.224689483642578 C 18.11705780029297 2.224637508392334 18.11648559570313 2.224533557891846 18.11648559570313 2.224533557891846 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-8.53, -1.07)" d="M 17.16509628295898 2.158949613571167 C 17.16509628295898 2.158949613571167 17.16493988037109 2.15910530090332 17.16452407836914 2.159417152404785 C 17.17366409301758 2.159313201904297 17.18265151977539 2.15910530090332 17.19184684753418 2.15910530090332 L 17.16509628295898 2.158949613571167 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.05, -20.15)" d="M 6.131697177886963 40.79074096679688 C 6.140007972717285 40.85691833496094 6.179121017456055 40.90283966064453 6.210235118865967 40.88232040405273 C 6.22955846786499 40.86964416503906 6.170602798461914 40.81624603271484 6.244569778442383 40.71854400634766 C 6.295629978179932 40.65091323852539 6.24197244644165 40.50437927246094 6.221610546112061 40.55710601806641 C 6.184782981872559 40.65205383300781 6.116893291473389 40.67179107666016 6.131697177886963 40.79074096679688 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-2.93, -19.96)" d="M 5.91898775100708 40.34559631347656 C 5.947244644165039 40.36559295654297 5.989734172821045 40.34559631347656 5.964853763580322 40.27204513549805 C 5.952075958251953 40.23423004150391 6.004486083984375 40.20207977294922 6.03575611114502 40.18431091308594 C 6.076323986053467 40.16130065917969 5.993629932403564 40.13829040527344 5.933999538421631 40.18223571777344 C 5.854733467102051 40.24061584472656 5.889172077178955 40.32450866699219 5.91898775100708 40.34559631347656 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-6.96, -3.4)" d="M 14.00677299499512 6.849946975708008 C 14.00521659851074 6.850570201873779 14.00355339050293 6.851453304290771 14.0019416809082 6.851453304290771 C 14.00235748291016 6.851453304290771 14.00298118591309 6.851869106292725 14.00334548950195 6.851712703704834 C 14.00443458557129 6.851453304290771 14.00568199157715 6.850466251373291 14.00677299499512 6.849946975708008 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.16, -20.37)" d="M 6.415309906005859 41.2482795715332 C 6.422945499420166 41.15410995483398 6.497380256652832 41.13779830932617 6.513846397399902 41.08684158325195 C 6.530519962310791 41.03520965576172 6.507301330566406 40.93464660644531 6.487978935241699 40.99261856079102 C 6.470006465911865 41.04658889770508 6.373288154602051 41.08902359008789 6.361028671264648 41.15696716308594 C 6.343317031860352 41.25524139404297 6.411050796508789 41.30157470703125 6.415309906005859 41.2482795715332 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-2.8, -19.85)" d="M 5.715320587158203 39.9339599609375 C 5.684726238250732 39.90336990356445 5.596422672271729 40.00252532958984 5.632003784179688 40.08361053466797 C 5.665350914001465 40.15954971313477 5.714385509490967 40.17155075073242 5.689349174499512 40.04278182983398 C 5.679843425750732 39.99369430541992 5.737293243408203 39.95577621459961 5.715320587158203 39.9339599609375 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.32, -20.77)" d="M 6.752651214599609 41.92728042602539 C 6.667672157287598 41.99589920043945 6.664711952209473 42.08586502075195 6.683099746704102 42.12799072265625 C 6.718524932861328 42.20917892456055 6.741016387939453 42.22517395019531 6.760079383850098 42.11905288696289 C 6.766676902770996 42.08217620849609 6.790310859680176 42.03625869750977 6.84033203125 41.99589920043945 C 6.925312042236328 41.92728042602539 6.883132934570313 41.79794311523438 6.867082595825195 41.79794311523438 C 6.845993995666504 41.79799652099609 6.829319953918457 41.86531448364258 6.752651214599609 41.92728042602539 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.43, -21.03)" d="M 6.922545433044434 42.44697570800781 C 6.877250671386719 42.55449676513672 6.946127891540527 42.65126800537109 6.981344699859619 42.65126800537109 C 7.030171871185303 42.65126800537109 7.027885913848877 42.53143310546875 7.032976627349854 42.48946380615234 C 7.037703514099121 42.45076751708984 7.070479869842529 42.31182098388672 7.051364421844482 42.31182098388672 C 7.017341613769531 42.311767578125 6.949866771697998 42.38199615478516 6.922544479370117 42.44697570800781 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-2.69, -19.77)" d="M 5.492360591888428 39.77196502685547 C 5.435275077819824 39.77180862426758 5.394083976745605 39.89979553222656 5.422496795654297 39.93704223632813 C 5.477141380310059 40.00882720947266 5.467428207397461 39.92488098144531 5.467428207397461 39.88520050048828 C 5.467479705810547 39.83139038085938 5.546329975128174 39.77207183837891 5.492360591888428 39.77196502685547 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.84, -21.4)" d="M 7.802702903747559 43.17191314697266 C 7.857606887817383 43.19731521606445 7.866488933563232 43.16500473022461 7.84514045715332 43.11763000488281 C 7.818441390991211 43.05820846557617 7.725410938262939 43.03129959106445 7.721930980682373 43.05602645874023 C 7.716892242431641 43.0925407409668 7.768524169921875 43.15596389770508 7.802702903747559 43.17190933227539 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-6.97, -3.33)" d="M 14.08237648010254 6.707742691040039 C 14.06523513793945 6.722754001617432 14.04861259460449 6.740207195281982 14.03396415710449 6.763737678527832 C 14.0305347442627 6.769399642944336 14.0272102355957 6.772983551025391 14.02393913269043 6.77589225769043 C 14.04705429077148 6.75968599319458 14.07723426818848 6.715378284454346 14.08237648010254 6.707742691040039 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-12.75, -20.96)" d="M 25.74002647399902 42.17230224609375 C 25.69338035583496 42.16804504394531 25.64278602600098 42.23120880126953 25.64881324768066 42.26575088500977 C 25.65722846984863 42.31447601318359 25.74002647399902 42.29701995849609 25.76563262939453 42.26575088500977 C 25.79373550415039 42.23100280761719 25.76542472839355 42.17464447021484 25.74002647399902 42.17230224609375 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-11.74, -20.16)" d="M 23.96382522583008 41.02995300292969 C 24.07695770263672 40.98013687133789 24.11420249938965 40.88960266113281 24.11347579956055 40.83859252929688 C 24.11264419555664 40.77070236206055 24.03415679931641 40.85251235961914 23.99275779724121 40.76717376708984 C 23.96657943725586 40.71315002441406 24.0278205871582 40.66292190551758 24.08412551879883 40.6097297668457 C 24.13695335388184 40.559814453125 23.95645141601563 40.54251861572266 23.79677581787109 40.61596298217773 C 23.64702606201172 40.68499755859375 23.57783699035645 40.92305374145508 23.63969993591309 40.89443206787109 C 23.65720558166504 40.88638305664063 23.73849487304688 40.81760787963867 23.75890922546387 40.83209991455078 C 23.76581764221191 40.8370361328125 23.73257446289063 40.86347198486328 23.72883415222168 40.89064025878906 C 23.7230167388916 40.93120956420898 23.75890922546387 40.9813346862793 23.80519104003906 40.98476409912109 C 23.83443641662598 40.98694229125977 23.82742309570313 40.9461669921875 23.83531951904297 40.91141891479492 C 23.84295654296875 40.87802124023438 23.86643218994141 40.84576416015625 23.91177940368652 40.86186218261719 C 23.97977447509766 40.88591766357422 23.94013977050781 40.95666122436523 23.85568046569824 40.99021530151367 C 23.79391860961914 41.01457595825195 23.83536911010742 41.0864143371582 23.96382522583008 41.02995300292969 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.99, -5.33)" d="M 8.033737182617188 10.72018623352051 C 8.03560733795166 10.72060203552246 8.037010192871094 10.72158813476563 8.038826942443848 10.72216033935547 C 8.03726863861084 10.72096538543701 8.03560733795166 10.72018623352051 8.033737182617188 10.72018623352051 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(0.0, 0.0)" d="M 16.88423919677734 4.658821582794189 C 16.76877021789551 4.497122287750244 16.67199897766113 4.451671600341797 16.57414054870605 4.309243202209473 C 16.49347114562988 4.191747188568115 16.54899787902832 4.128688812255859 16.54447746276855 3.915721416473389 C 16.53175354003906 3.308504819869995 15.9924259185791 3.201916933059692 15.64850997924805 3.134338855743408 C 15.38396263122559 3.082343816757202 15.27477741241455 3.100419759750366 15.24361133575439 2.997624397277832 C 15.20288753509521 2.863610506057739 15.10570049285889 2.60238790512085 15.02846240997314 2.471906185150146 C 14.87268447875977 2.208606004714966 14.59281444549561 2.050906181335449 14.45931911468506 1.956057786941528 C 14.24707889556885 1.805214524269104 13.92856311798096 1.741532206535339 13.70354652404785 1.788177251815796 C 13.50579833984375 1.829264402389526 13.26831340789795 1.941046237945557 13.09206962585449 2.089708089828491 C 12.80456352233887 2.332127094268799 12.83489799499512 2.504630565643311 12.68862628936768 2.505877494812012 C 12.49591541290283 2.507487773895264 12.25121116638184 2.582286357879639 12.0304012298584 2.650227546691895 C 11.80948638916016 2.718221664428711 11.77561950683594 2.641709089279175 11.74170112609863 2.573819160461426 C 11.70762538909912 2.505877494812012 11.74299812316895 2.361474990844727 11.61838817596436 2.18476414680481 C 11.50006008148193 2.016571998596191 11.32116794586182 1.992002606391907 11.359450340271 1.758465528488159 C 11.39378452301025 1.548251152038574 11.40183544158936 1.287080407142639 11.30288314819336 1.088501453399658 C 11.22616291046143 0.9345934391021729 11.1527156829834 0.996094286441803 11.1527156829834 0.8357452750205994 C 11.1527156829834 0.6754483580589294 11.08404636383057 0.4793106317520142 10.98322486877441 0.3672170042991638 C 10.83290100097656 0.1999597102403641 10.51017761230469 0.1871816515922546 10.30869007110596 0.2211525440216064 C 10.10730457305908 0.25517538189888 10.075514793396 0.2445789724588394 10.03448009490967 0.1702481359243393 C 9.966538429260254 0.04709064587950706 9.784008979797363 0.0003417132829781622 9.635295867919922 0.03862389922142029 C 9.543251991271973 0.06225809082388878 9.490945816040039 0.1702481359243393 9.368463516235352 0.1532626897096634 C 9.245877265930176 0.1363291889429092 9.274446487426758 0.004653002135455608 9.079919815063477 0.04283130913972855 C 8.968449592590332 0.06480330973863602 8.928504943847656 0.2041670978069305 8.849603652954102 0.1363291889429092 C 8.770856857299805 0.06833545118570328 8.718029975891113 -0.01659179106354713 8.647750854492188 0.008860411122441292 C 8.577523231506348 0.03441650047898293 8.55233097076416 0.1405366063117981 8.475715637207031 0.1405366063117981 C 8.398942947387695 0.1405366063117981 8.27635669708252 -0.01659179106354713 8.068220138549805 0.008860411122441292 C 7.962099552154541 0.0218462273478508 7.919713973999023 0.0516616627573967 7.874627590179443 0.06833545118570328 C 7.736977577209473 0.1192917972803116 7.817593097686768 -0.07606683671474457 7.531074523925781 0.03441650047898293 C 7.457990646362305 0.06251780688762665 7.384593963623047 0.3019243478775024 7.312341690063477 0.2764721214771271 C 7.257904529571533 0.2573050558567047 7.13391637802124 0.1193437278270721 6.945725440979004 0.2042190283536911 C 6.826879978179932 0.2578764259815216 6.832437515258789 0.3220782577991486 6.658323287963867 0.3220782577991486 C 6.513505458831787 0.3220782577991486 6.355857849121094 0.2181398421525955 6.067053318023682 0.3607240915298462 C 5.77824878692627 0.5033602714538574 5.766042232513428 0.7387152910232544 5.78848123550415 0.8141368627548218 C 5.844476222991943 1.002639055252075 5.82177734375 1.316895842552185 5.872785568237305 1.401823043823242 C 5.923897743225098 1.487061977386475 5.911015510559082 1.635411858558655 5.761210918426514 1.785995483398438 C 5.646884441375732 1.900893926620483 5.558528423309326 2.21717643737793 5.473652839660645 2.325945615768433 C 5.388673782348633 2.434767007827759 5.252789974212646 2.37004566192627 5.142410755157471 2.325945615768433 C 5.031979560852051 2.281846046447754 4.862125396728516 2.149235010147095 4.632795333862305 2.140768051147461 C 4.418166160583496 2.132820606231689 4.276101112365723 2.106797218322754 4.097675800323486 1.892790794372559 C 3.919302701950073 1.678784608840942 3.716931581497192 1.647410750389099 3.581930875778198 1.621439218521118 C 3.477733135223389 1.601492881774902 3.210277080535889 1.626893162727356 3.073873996734619 1.731351375579834 C 3.008217811584473 1.781528472900391 2.89176082611084 1.947071671485901 2.789796590805054 1.919957280158997 C 2.687883615493774 1.892790913581848 2.567167282104492 1.939020395278931 2.439750671386719 1.996262073516846 C 2.312386035919189 2.053503751754761 2.178320169448853 2.187517166137695 2.050903558731079 2.35274863243103 C 1.933511853218079 2.505046367645264 1.881049036979675 2.641865015029907 1.855597138404846 2.687834739685059 C 1.830092668533325 2.733752727508545 1.711350560188293 2.896282911300659 1.651771664619446 2.935344457626343 C 1.560870885848999 2.994871377944946 1.316269993782043 3.223681449890137 1.125222563743591 3.236355781555176 C 1.056917190551758 3.240926742553711 0.9213452935218811 3.329801559448242 0.8024990558624268 3.448699712753296 C 0.6835489869117737 3.56759786605835 0.6835489869117737 3.839364767074585 0.649630069732666 4.015556335449219 C 0.6156591773033142 4.191696166992188 0.3863296210765839 4.382950782775879 0.2928836345672607 4.476345062255859 C 0.1994377225637436 4.569738864898682 -0.03404727578163147 4.949859619140625 0.004131035879254341 5.175190448760986 C 0.03166096657514572 5.337512969970703 0.06355413794517517 5.470020771026611 0.1400146186351776 5.500771045684814 C 0.2164750993251801 5.531520843505859 0.2726777493953705 5.498848915100098 0.3353732228279114 5.55286979675293 C 0.3696557879447937 5.582425594329834 0.3693441152572632 5.690830707550049 0.3438919186592102 5.724282264709473 C 0.3183877766132355 5.757681846618652 0.5562360286712646 5.9898681640625 0.6411632299423218 6.039110660552979 C 0.7206884026527405 6.085080623626709 0.8127838373184204 6.062433242797852 0.8449887037277222 6.1410231590271 C 0.8838422298431396 6.235664367675781 0.9926115274429321 6.434503078460693 1.037282586097717 6.498340606689453 C 1.108340978622437 6.600046157836914 1.074370265007019 6.616615295410156 1.190930843353271 6.7610182762146 C 1.307491540908813 6.905420303344727 1.432207465171814 6.986918926239014 1.504720211029053 7.082598209381104 C 1.597490906715393 7.205028533935547 1.637019753456116 7.30029296875 1.659770965576172 7.325797557830811 C 1.720648407936096 7.394206523895264 1.906657218933105 7.372545719146729 2.085030555725098 7.3363938331604 C 2.263403415679932 7.30029296875 2.407754182815552 7.066807746887207 2.433258056640625 6.954039096832275 C 2.458710432052612 6.841373443603516 2.526704072952271 6.761017799377441 2.526704072952271 6.857217311859131 C 2.526704072952271 6.953467845916748 2.586178779602051 7.174797534942627 2.577608346939087 7.308758735656738 C 2.569141387939453 7.44277286529541 2.476942300796509 7.429059505462646 2.416272640228271 7.542347431182861 C 2.352538108825684 7.661245822906494 2.390768527984619 7.733499050140381 2.369523525238037 7.835411548614502 C 2.344694852828979 7.954465866088867 2.02129602432251 8.153875350952148 2.008621692657471 8.51347827911377 C 2.005712985992432 8.596068382263184 2.123260736465454 8.666868209838867 2.012881278991699 8.778130531311035 C 1.90244996547699 8.889391899108887 1.930031776428223 8.998578071594238 1.923746824264526 9.358960151672363 C 1.919435501098633 9.60200309753418 2.010907411575317 9.535306930541992 1.957717537879944 9.623818397521973 C 1.817626714706421 9.856731414794922 1.923746824264526 10.13701915740967 2.051111459732056 10.27565479278564 C 2.186683654785156 10.42327690124512 2.212499141693115 10.35356903076172 2.144557476043701 10.50643825531006 C 2.076563358306885 10.6593074798584 2.263455867767334 11.04093360900879 2.373887062072754 11.18164825439453 C 2.484734058380127 11.32277774810791 2.754475355148315 11.42365074157715 2.754475355148315 11.6771879196167 C 2.754475355148315 11.98173141479492 3.142439365386963 12.14446830749512 3.179215431213379 12.17163467407227 C 3.223211288452148 12.20404624938965 3.194642543792725 12.53627586364746 3.274167776107788 12.6707067489624 C 3.353744745254517 12.80513477325439 3.644886493682861 12.83354759216309 3.565206050872803 13.02527046203613 C 3.458306550979614 13.28249263763428 3.541831254959106 13.5036678314209 3.545934677124023 13.85693359375 C 3.550194025039673 14.22001647949219 3.792301893234253 15.16912460327148 3.843206167221069 15.47476005554199 C 3.894214153289795 15.78054904937744 3.613876581192017 16.12026023864746 3.644366979598999 16.72326850891113 C 3.674857616424561 17.32627868652344 3.511963367462158 17.81890678405762 3.350575923919678 17.8418140411377 C 3.189240217208862 17.8646183013916 2.917473077774048 17.75096702575684 2.707674264907837 17.8418140411377 C 2.49792742729187 17.93255996704102 2.454866409301758 18.28520393371582 2.433362245559692 18.34540557861328 C 2.411857604980469 18.40566062927246 2.093652963638306 18.50679397583008 2.017192602157593 18.71877288818359 C 1.94073224067688 18.93075370788574 2.067369937896729 19.22418212890625 2.10211968421936 19.29227828979492 C 2.136817693710327 19.36032485961914 1.980936169624329 19.43403434753418 1.906761169433594 19.47506904602051 C 1.799342513084412 19.53454399108887 1.757320404052734 19.61765289306641 1.702935695648193 19.7497444152832 C 1.673224210739136 19.8218936920166 1.588504791259766 19.79301261901855 1.516251564025879 19.79784393310547 C 1.452413439750671 19.80204963684082 1.318711400032043 19.92515563964844 1.299544453620911 20.03137969970703 C 1.281675934791565 20.13033103942871 1.279909729957581 20.23795890808105 1.282558917999268 20.2951488494873 C 1.286818385124207 20.38661956787109 1.214617133140564 20.41061782836914 1.19763171672821 20.46874618530273 C 1.180646181106567 20.52692031860352 1.229109406471252 20.80429649353027 1.155141949653625 20.90522384643555 C 1.129689812660217 20.93997192382813 1.132442831993103 21.46969032287598 1.132442831993103 21.46969032287598 C 1.132442831993103 21.46969032287598 1.014999151229858 21.5569019317627 0.9385904669761658 21.67055511474609 C 0.8621818423271179 21.78410339355469 0.8876340389251709 22.10194206237793 0.9385904669761658 22.18858528137207 C 0.9968708157539368 22.28774452209473 1.219863295555115 22.26426696777344 1.206098198890686 22.35989189147949 C 1.193528056144714 22.44715690612793 1.212383508682251 23.23871994018555 1.295233011245728 23.35642623901367 C 1.378186464309692 23.47407722473145 1.533133149147034 23.87450790405273 1.584037661552429 24.01459884643555 C 1.63499391078949 24.15474128723145 1.774929046630859 24.14144325256348 1.838039994239807 24.2142162322998 C 1.915279746055603 24.30345344543457 2.038437366485596 24.32890510559082 2.140349864959717 24.32890510559082 C 2.370458364486694 24.32890510559082 2.831299066543579 24.46478843688965 3.020943880081177 24.44671249389648 C 3.12337589263916 24.4370002746582 3.23271656036377 24.42396354675293 3.206173419952393 24.44635009765625 C 2.899915933609009 24.70549774169922 3.044837713241577 25.05507278442383 3.143114328384399 25.22124290466309 C 3.241390943527222 25.38740730285645 3.580164670944214 25.50090408325195 3.744773387908936 25.53918266296387 C 3.877280712127686 25.56998825073242 8.726705551147461 25.67496681213379 8.726705551147461 25.67496681213379 C 8.726705551147461 25.67496681213379 12.75241279602051 25.64115142822266 12.99020957946777 25.62406158447266 C 13.22800540924072 25.607177734375 13.40643119812012 25.56463623046875 13.57618045806885 25.46272659301758 C 13.7589693069458 25.35312461853027 13.975417137146 25.08063316345215 13.9468469619751 24.81940841674805 C 13.9183292388916 24.55834007263184 13.89900779724121 24.4498291015625 13.9468469619751 24.44079399108887 C 13.9947395324707 24.43180465698242 14.3406286239624 24.33316802978516 14.62693977355957 24.23473358154297 C 14.91330337524414 24.1362476348877 15.28703498840332 23.84692573547363 15.32583618164063 23.73015594482422 C 15.3469762802124 23.6662654876709 15.37679195404053 23.43200302124023 15.51833724975586 23.39070892333984 C 15.63235378265381 23.35741233825684 15.5780200958252 23.18901062011719 15.61204147338867 23.13249778747559 C 15.64601230621338 23.07582664489746 15.77223682403564 23.05972480773926 15.77223682403564 22.88083076477051 C 15.77223682403564 22.70531463623047 15.82402420043945 22.27792549133301 15.86292839050293 22.17310523986816 C 15.89248466491699 22.09316444396973 16.00940895080566 22.02376747131348 16.07740211486816 21.97878456115723 C 16.17095375061035 21.91691970825195 16.1412410736084 21.47945404052734 16.10721778869629 21.43421173095703 C 16.04571723937988 21.35224533081055 15.86292839050293 21.33510398864746 15.83545112609863 21.11444854736328 C 15.82288074493408 21.0133171081543 15.86194324493408 20.86834144592285 15.85545063018799 20.74939155578613 C 15.84895706176758 20.63054656982422 15.73062896728516 20.60556030273438 15.74683666229248 20.50655937194824 C 15.75748443603516 20.44059181213379 15.72501945495605 20.2692813873291 15.65702629089355 20.21328735351563 C 15.58633232116699 20.15516471862793 15.49189949035645 20.18279457092285 15.48343276977539 20.12981414794922 C 15.47501754760742 20.07672882080078 15.453200340271 19.91679382324219 15.31726551055908 19.8421516418457 C 15.24381637573242 19.80173873901367 15.28578758239746 19.74605751037598 15.25186824798584 19.64508056640625 C 15.21789741516113 19.54404830932617 14.83684253692627 19.4452018737793 14.98607444763184 19.20408248901367 C 15.13883972167969 18.95714378356934 14.9776086807251 18.62164115905762 14.738356590271 18.53676605224609 C 14.64974117279053 18.50533866882324 14.71451377868652 18.32831573486328 14.62688636779785 18.21819877624512 C 14.53956985473633 18.10844230651855 14.31943321228027 17.89323997497559 14.04325199127197 17.91666793823242 C 13.90596580505371 17.92840766906738 13.58895587921143 17.92944717407227 13.54833698272705 17.89324188232422 C 13.45764446258545 17.81241798400879 13.33994197845459 17.57269859313965 13.34368133544922 17.33490562438965 C 13.34695243835449 17.11840438842773 13.16016578674316 16.69465065002441 13.03747463226318 16.43862342834473 C 12.96786975860596 16.29318237304688 12.90948581695557 16.14166259765625 13.07934093475342 15.82319831848145 C 13.24342918395996 15.51559066772461 13.30451488494873 14.85497379302979 13.30451488494873 14.61723041534424 C 13.30451488494873 14.40488624572754 13.23408031463623 13.36872100830078 13.32388877868652 13.3517370223999 C 13.661208152771 13.28800201416016 13.41369915008545 13.06656742095947 13.58048915863037 12.95166969299316 C 13.73330497741699 12.84638118743896 13.54220771789551 12.74062347412109 13.70364761352539 12.6329984664917 C 13.86498260498047 12.52537155151367 13.94907855987549 12.40382289886475 13.95723342895508 12.28980922698975 C 13.96518230438232 12.1757926940918 14.12828350067139 11.97586345672607 14.18770599365234 11.87270450592041 C 14.24723339080811 11.76949405670166 14.17092895507813 11.63470077514648 14.2230806350708 11.60218524932861 C 14.36618423461914 11.5130500793457 14.62828826904297 11.27836990356445 14.62828826904297 11.1433687210083 C 14.62828826904297 11.00836849212646 14.5104284286499 10.92515563964844 14.6208610534668 10.82677459716797 C 14.74853801727295 10.71301937103271 14.881667137146 10.45335578918457 14.90722370147705 10.30168056488037 C 14.94794845581055 10.06035232543945 14.69726943969727 10.19239139556885 14.91397666931152 9.943168640136719 C 15.10346698760986 9.724955558776855 15.12065982818604 9.446954727172852 15.07391166687012 9.284891128540039 C 15.02503204345703 9.115089416503906 14.9242115020752 9.140645027160645 14.99464511871338 8.994891166687012 C 15.03059005737305 8.920613288879395 15.04331684112549 8.792261123657227 15.03292751312256 8.723176002502441 C 15.01485061645508 8.604382514953613 14.9734001159668 8.48106861114502 14.87309837341309 8.353703498840332 C 14.74531745910645 8.191484451293945 14.94363784790039 8.301553726196289 14.92665100097656 8.124425888061523 C 14.91008186340332 7.951039791107178 14.74282550811768 7.777392864227295 14.70158195495605 7.678544521331787 C 14.68350505828857 7.635172367095947 14.65825939178467 7.499496459960938 14.63488674163818 7.42615270614624 C 14.62127685546875 7.382988929748535 14.50362491607666 7.219677925109863 14.40566062927246 7.114129543304443 C 14.34868049621582 7.052836894989014 14.27673816680908 6.848335266113281 14.45105934143066 6.854672908782959 C 14.68470001220703 6.863192558288574 14.63374423980713 7.126440048217773 14.67187023162842 7.236819744110107 C 14.7207498550415 7.378105163574219 14.87309837341309 7.431970596313477 14.93834018707275 7.465941429138184 C 15.00607299804688 7.501158237457275 15.16398143768311 7.490354061126709 15.27867221832275 7.418205261230469 C 15.37320804595947 7.358678340911865 15.54669857025146 7.100935459136963 15.62918472290039 7.019851207733154 C 15.7117223739624 6.938767910003662 15.87414836883545 6.855762958526611 15.91461277008057 6.729384899139404 C 15.96224403381348 6.580255508422852 16.0396900177002 6.465513706207275 16.11984062194824 6.396065235137939 C 16.22679138183594 6.303502559661865 16.4327449798584 6.189019203186035 16.5064525604248 6.125545024871826 C 16.65054130554199 6.001192569732666 16.68794059753418 5.9653000831604 16.84933090209961 5.793159484863281 C 17.01071929931641 5.62101936340332 17.10572242736816 5.432725429534912 17.14566802978516 5.275389194488525 C 17.2027530670166 5.049746990203857 17.03710556030273 4.873035907745361 16.88423728942871 4.658822059631348 Z M 1.047333955764771 21.98893356323242 C 1.02769935131073 21.98893356323242 1.011752843856812 21.94353866577148 1.011752843856812 21.8873348236084 C 1.011752843856812 21.83108139038086 1.02769935131073 21.78562927246094 1.047333955764771 21.78562927246094 C 1.066916584968567 21.78562927246094 1.082915067672729 21.83108139038086 1.082915067672729 21.8873348236084 C 1.082915067672729 21.94353866577148 1.066916584968567 21.98893356323242 1.047333955764771 21.98893356323242 Z M 15.88066959381104 21.4340763092041 C 15.88066959381104 21.4340763092041 16.02086448669434 21.52077102661133 16.02086448669434 21.6746768951416 C 16.02086448669434 21.82858657836914 15.92980861663818 21.91434478759766 15.88918972015381 21.93797874450684 C 15.86809921264648 21.95034217834473 15.84670066833496 21.46545219421387 15.88066959381104 21.4340763092041 Z M 15.58900928497314 21.45864486694336 C 15.5859956741333 21.13078117370605 15.58449077606201 20.50917625427246 15.64157485961914 20.45556831359863 C 15.69372653961182 20.40637969970703 15.83033847808838 21.61665725708008 15.74468231201172 22.11629867553711 C 15.71237373352051 22.30495643615723 15.67191028594971 22.73722839355469 15.59186553955078 22.93741798400879 C 15.55550479888916 23.02836990356445 15.59212589263916 21.78791427612305 15.58900928497314 21.45864486694336 Z M 15.1201696395874 20.15232467651367 C 15.1615686416626 20.14827346801758 15.32332038879395 20.62911224365234 15.36430358886719 21.00378036499023 C 15.41089630126953 21.43096160888672 15.43427085876465 22.22834396362305 15.38975620269775 22.54561233520508 C 15.34352493286133 22.87576293945313 15.23678207397461 23.44506072998047 15.18967056274414 23.49030685424805 C 15.14271354675293 23.53554725646973 15.12765026092529 22.4561653137207 15.13902473449707 22.26361274719238 C 15.1501932144165 22.07116317749023 15.13035106658936 21.22090339660645 15.10494995117188 20.94612312316895 C 15.08344554901123 20.71149635314941 15.08277034759521 20.15596199035645 15.1201696395874 20.15232467651367 Z M 11.70417213439941 3.313408374786377 C 11.76120662689209 3.197574853897095 11.84540557861328 3.099401950836182 12.14091110229492 2.882019281387329 C 12.24843311309814 2.802910089492798 12.4490385055542 2.66396164894104 12.56876850128174 2.733201742172241 C 12.70937824249268 2.814440965652466 12.84063911437988 2.732422590255737 12.91486549377441 2.78535270690918 C 13.04347610473633 2.877188444137573 13.00675392150879 2.892823457717896 13.05880069732666 2.747797966003418 C 13.09832954406738 2.637314796447754 13.04332160949707 2.543193340301514 13.23031616210938 2.332511425018311 C 13.36386299133301 2.182187795639038 13.60212802886963 2.065938711166382 13.83135318756104 2.062978029251099 C 14.07486152648926 2.05970573425293 14.4150390625 2.157151222229004 14.47534561157227 2.416711807250977 C 14.50724029541016 2.553893804550171 14.26918315887451 2.739227533340454 14.31458187103271 2.739435434341431 C 14.35831832885742 2.739591121673584 14.40771579742432 2.715229749679565 14.44953060150146 2.695543050765991 C 14.47768211364746 2.682297706604004 14.52853488922119 2.648898124694824 14.54941749572754 2.616018056869507 C 14.59013938903809 2.552335500717163 14.56146812438965 2.475355625152588 14.64919853210449 2.471408128738403 C 14.71781730651855 2.468343496322632 14.69137763977051 2.586670160293579 14.68852043151855 2.612122535705566 C 14.6856632232666 2.637626647949219 14.66176795959473 2.68785572052002 14.62909603118896 2.704165697097778 C 14.57237339019775 2.732630968093872 14.55694675445557 2.754654884338379 14.65101528167725 2.741045475006104 C 14.77162742614746 2.723592519760132 14.74181175231934 2.628276586532593 14.82118225097656 2.644482612609863 C 14.90070724487305 2.660689115524292 14.86995697021484 2.908770561218262 14.84845161437988 2.99967098236084 C 14.82689476013184 3.090571880340576 14.75318717956543 3.286865234375 14.56588077545166 3.251076459884644 C 14.43186664581299 3.225468397140503 14.2106409072876 3.150929689407349 14.18970680236816 3.287073135375977 C 14.16893005371094 3.423268556594849 14.18851089477539 3.507728099822998 14.16513919830322 3.582058906555176 C 14.1190128326416 3.729681968688965 14.06764030456543 3.699190855026245 14.02899360656738 3.555308103561401 C 14.01128196716309 3.489444255828857 13.97118186950684 3.45692777633667 13.96557140350342 3.556347131729126 C 13.96115589141846 3.634781360626221 13.97767448425293 3.71643590927124 13.87311267852783 3.761211395263672 C 13.76039505004883 3.809362649917603 13.38552188873291 3.829776287078857 13.27862167358398 4.047729969024658 C 13.21961402893066 4.167978763580322 13.28916645050049 4.353520393371582 13.21042060852051 4.409618854522705 C 13.10092353820801 4.487481594085693 12.91294002532959 4.43101978302002 12.89476108551025 4.307498455047607 C 12.87621688842773 4.181743621826172 12.92639446258545 3.951791048049927 13.06965255737305 3.816842317581177 C 13.20678424835205 3.68765926361084 13.16138553619385 3.606316328048706 13.28329753875732 3.480406045913696 C 13.31685256958008 3.445656061172485 13.28121948242188 3.290137529373169 13.23654842376709 3.292682886123657 C 13.10518360137939 3.300111055374146 13.23166561126709 3.534530639648438 13.11806583404541 3.501962661743164 C 13.00430965423584 3.469498157501221 12.88577461242676 3.294501066207886 12.95340538024902 3.251492261886597 C 13.0840425491333 3.168330907821655 12.95080757141113 2.943520307540894 12.8814115524292 2.940144300460815 C 12.79549789428711 2.936040878295898 12.85325908660889 3.13804817199707 12.86468601226807 3.284372329711914 C 12.87471103668213 3.415840625762939 12.78474521636963 3.67623233795166 12.65400409698486 3.749939918518066 C 12.43049240112305 3.876006126403809 12.28785610198975 3.780170917510986 12.17513942718506 3.828322410583496 C 12.09426307678223 3.86286473274231 12.03982734680176 3.872577905654907 12.05198097229004 3.940311908721924 C 12.06423950195313 4.008097648620605 12.07104587554932 4.098634243011475 12.00876426696777 4.130683898925781 C 11.9096565246582 4.18174409866333 11.58360958099365 3.921508550643921 11.7128438949585 3.766302108764648 C 11.74489307403564 3.727968215942383 11.83750820159912 3.781677007675171 11.90461826324463 3.731500148773193 C 12.01063537597656 3.652027130126953 11.98144245147705 3.510845184326172 12.13950538635254 3.486172199249268 C 12.29782867431641 3.461447477340698 12.53006649017334 3.423632621765137 12.61603260040283 3.327121734619141 C 12.73607444763184 3.192485094070435 12.73358154296875 2.997126340866089 12.69644165039063 2.974998712539673 C 12.62559032440186 2.932768583297729 12.70309066772461 3.124803066253662 12.59063339233398 3.18292760848999 C 12.47807216644287 3.240999937057495 12.41605281829834 3.191030263900757 12.26957130432129 3.249518871307373 C 12.12309074401855 3.308007001876831 11.85537624359131 3.618835210800171 11.73606300354004 3.590474367141724 C 11.67840671539307 3.576709747314453 11.62433242797852 3.475783824920654 11.70417022705078 3.313408851623535 Z M 13.8218469619751 4.787038803100586 C 13.93762874603271 4.812283039093018 13.79483795166016 4.709331512451172 13.92292976379395 4.565604209899902 C 13.9648494720459 4.51864767074585 14.09096527099609 4.409826755523682 14.1989049911499 4.430915355682373 C 14.2231616973877 4.435694217681885 14.28320693969727 4.515427112579346 14.20191764831543 4.668503761291504 C 14.1601037979126 4.747198104858398 14.18472480773926 4.947906494140625 14.13169097900391 5.059792041778564 C 14.07122898101807 5.18788480758667 13.84210681915283 5.311769485473633 13.63864612579346 5.340493679046631 C 13.43528652191162 5.369218826293945 13.29810523986816 5.441782474517822 13.272705078125 5.510036945343018 C 13.24730491638184 5.578290939331055 13.44152069091797 5.637609481811523 13.50972175598145 5.66732120513916 C 13.57813167572021 5.696980476379395 13.51153945922852 5.80138635635376 13.37295532226563 5.820137977600098 C 13.26013469696045 5.835409641265869 13.05501079559326 5.736405849456787 13.02992248535156 5.558396339416504 C 13.00483417510986 5.380334377288818 13.12767887115479 5.024938583374023 13.21738529205322 4.955750465393066 C 13.30703926086426 4.886613368988037 13.38557624816895 5.044209480285645 13.45944023132324 5.071531772613525 C 13.53340721130371 5.098854064941406 13.7742166519165 5.095788955688477 13.88911437988281 5.017874717712402 C 13.94168186187744 4.982345581054688 13.95710849761963 4.904690265655518 13.91025733947754 4.89580774307251 C 13.79380035400391 4.87388801574707 13.67531585693359 4.907702922821045 13.5840539932251 4.846305847167969 C 13.49263286590576 4.784856796264648 13.39274501800537 4.515011787414551 13.36926651000977 4.441564083099365 C 13.3456335067749 4.368012428283691 13.31862163543701 4.241789817810059 13.4201192855835 4.218831062316895 C 13.52177238464355 4.195923805236816 13.77515125274658 4.085077285766602 13.84262561798096 4.038899421691895 C 13.90999698638916 3.99267053604126 14.00962352752686 3.810037851333618 14.11667919158936 3.780534267425537 C 14.18150329589844 3.762717723846436 14.24622535705566 3.814193725585938 14.25438022613525 3.925975561141968 C 14.26201629638672 4.027783870697021 14.2152156829834 4.178419589996338 14.12436676025391 4.162681102752686 C 14.09455108642578 4.157486438751221 14.06104946136475 4.15966796875 13.97066688537598 4.247036457061768 C 13.82392501831055 4.389049530029297 13.73879241943359 4.470860004425049 13.71079540252686 4.58570671081543 C 13.68425273895264 4.695358753204346 13.72772693634033 4.766572952270508 13.82184982299805 4.787038803100586 Z M 13.58555698394775 8.69119930267334 C 13.74128341674805 8.687771797180176 13.72985553741455 8.607466697692871 13.73744010925293 8.530694961547852 C 13.75250339508057 8.377461433410645 13.99019432067871 8.171091079711914 14.10831546783447 8.173428535461426 C 14.24004364013672 8.175923347473145 14.33998203277588 8.309260368347168 14.29001235961914 8.430132865905762 C 14.21594142913818 8.609439849853516 14.09849739074707 8.57661247253418 13.93752384185791 8.757426261901855 C 13.80361461639404 8.907802581787109 13.84906482696533 8.978029251098633 13.81675624847412 9.061918258666992 C 13.80361461639404 9.09645938873291 13.70346832275391 9.155312538146973 13.70544052124023 8.943227767944336 C 13.70611667633057 8.866455078125 13.48790264129639 8.925826072692871 13.42982959747314 8.90837287902832 C 13.28054523468018 8.863597869873047 13.26220893859863 8.571521759033203 13.1303243637085 8.381357192993164 C 13.01724433898926 8.218515396118164 12.8630256652832 8.308377265930176 12.78557872772217 8.024818420410156 C 12.73482799530029 7.838809490203857 12.824951171875 7.840211868286133 12.71051979064941 7.660540580749512 C 12.59603786468506 7.480816841125488 12.55765151977539 7.442950248718262 12.52596569061279 7.330025196075439 C 12.50674724578857 7.261823654174805 12.43387126922607 7.087865352630615 12.70044326782227 6.883469581604004 C 12.94255065917969 6.697772026062012 13.07147312164307 6.764103412628174 13.11006736755371 6.814540386199951 C 13.14866065979004 6.86497688293457 13.1969690322876 6.94081449508667 13.1977481842041 7.010002613067627 C 13.19935894012451 7.133575916290283 12.95626354217529 7.10526704788208 12.83752059936523 7.261356353759766 C 12.77067089080811 7.349296092987061 12.70563793182373 7.435158729553223 12.78848648071289 7.478375434875488 C 12.88307476043701 7.527773857116699 12.98504066467285 7.336466789245605 13.06160449981689 7.36721658706665 C 13.13832473754883 7.397967338562012 13.28163719177246 7.356049060821533 13.43829727172852 7.260473728179932 C 13.55200004577637 7.191025257110596 13.58934783935547 7.212062358856201 13.57932281494141 7.334440231323242 C 13.56472587585449 7.513644695281982 13.45013904571533 7.591455936431885 13.28641414642334 7.678617000579834 C 13.07183647155762 7.792892456054688 12.99802589416504 8.055673599243164 13.04591655731201 8.156234741210938 C 13.0986385345459 8.267029762268066 13.16689205169678 8.287444114685059 13.21031665802002 8.181791305541992 C 13.26771354675293 8.041908264160156 13.23327541351318 7.921243667602539 13.46182537078857 7.888675689697266 C 13.65837955474854 7.860626220703125 13.62238216400146 7.703912734985352 13.7267894744873 7.704069137573242 C 13.86729526519775 7.704172611236572 13.867919921875 7.862185001373291 13.81265258789063 7.964824199676514 C 13.75727939605713 8.067516326904297 13.41268825531006 8.240435600280762 13.41565036773682 8.466856002807617 C 13.41855812072754 8.693327903747559 13.49912261962891 8.693120956420898 13.58555603027344 8.691198348999023 Z M 13.26636600494385 10.06561756134033 C 13.27083206176758 10.0911226272583 13.21224117279053 10.15127277374268 13.29659652709961 10.4346752166748 C 13.33919048309326 10.57777786254883 13.3266716003418 10.69200134277344 13.29446697235107 10.59611415863037 C 13.25436592102051 10.47721576690674 13.21556568145752 10.4102611541748 13.18465900421143 10.23656272888184 C 13.16731071472168 10.1388053894043 13.00353336334229 10.10099124908447 13.04415130615234 9.961316108703613 C 13.08487510681152 9.821588516235352 13.17686748504639 9.710014343261719 13.22616195678711 9.581974983215332 C 13.27540397644043 9.453934669494629 13.33877468109131 9.338464736938477 13.42100048065186 9.20574951171875 C 13.45621871948242 9.149027824401855 13.57776641845703 9.178219795227051 13.63059234619141 9.330465316772461 C 13.68347072601318 9.482658386230469 13.60176372528076 9.648358345031738 13.53236770629883 9.773386001586914 C 13.43066310882568 9.956331253051758 13.25223827362061 9.985158920288086 13.26636695861816 10.06561946868896 Z M 13.0624885559082 11.92835426330566 C 12.94343376159668 11.85251808166504 12.79877281188965 11.68541717529297 12.82458877563477 11.37931346893311 C 12.83596420288086 11.24400329589844 12.99049377441406 11.08521175384521 13.11609268188477 11.01742649078369 C 13.21000671386719 10.96667766571045 13.15915298461914 10.82362461090088 13.21244812011719 10.82648181915283 C 13.31015491485596 10.8317813873291 13.3186206817627 10.96724891662598 13.28641510009766 11.08884716033936 C 13.25140571594238 11.22093963623047 13.15707588195801 11.25563812255859 13.07604503631592 11.44351673126221 C 12.9950647354126 11.63144683837891 13.21774482727051 12.02730655670166 13.06248664855957 11.92835426330566 Z M 12.78220367431641 11.32898044586182 C 12.82458877563477 11.37936592102051 12.60720539093018 11.41614246368408 12.50820255279541 11.20229339599609 C 12.44046783447266 11.05607128143311 12.51692867279053 11.00963497161865 12.46259593963623 10.83188438415527 C 12.41080856323242 10.66260051727295 12.76973533630371 10.35525417327881 12.8306131362915 10.30346488952637 C 12.86094951629639 10.27775478363037 12.97470474243164 10.50547218322754 12.97023677825928 10.59045124053955 C 12.96561431884766 10.67543029785156 12.68008232116699 10.91691589355469 12.65920066833496 11.06443405151367 C 12.63842391967773 11.21190166473389 12.7398681640625 11.27849197387695 12.78220367431641 11.32898044586182 Z M 12.23513603210449 11.86986637115479 C 12.19732093811035 11.98653125762939 12.3259334564209 12.00834655761719 12.33211517333984 12.04823970794678 C 12.33891773223877 12.09197616577148 12.33341217041016 12.15015316009521 12.12106895446777 11.95666408538818 C 12.05468559265137 11.89620208740234 12.02897357940674 11.79543209075928 12.08886432647705 11.6292667388916 C 12.15041732788086 11.45863246917725 12.19337272644043 11.39770221710205 12.25445938110352 11.29054355621338 C 12.32577800750732 11.16499614715576 12.34925556182861 11.18172264099121 12.34925556182861 11.18172264099121 C 12.34925556182861 11.18172264099121 12.4661808013916 11.46330738067627 12.30307769775391 11.55041694641113 C 12.21300888061523 11.59841251373291 12.28261089324951 11.7231273651123 12.23513603210449 11.86986827850342 Z M 11.94451332092285 11.40087032318115 C 11.92378807067871 11.5528039932251 11.89823150634766 11.7707052230835 11.82405757904053 11.72899627685547 C 11.74977779388428 11.68728637695313 11.66261768341064 11.94357395172119 11.57748317718506 11.93334197998047 C 11.49245166778564 11.92310810089111 11.47364807128906 11.78182220458984 11.49873638153076 11.69086933135986 C 11.52372169494629 11.5999174118042 11.76842594146729 11.37593746185303 11.79595565795898 11.33033180236816 C 11.82332897186279 11.2846736907959 11.76536083221436 11.12687015533447 11.74733638763428 11.05347442626953 C 11.72936344146729 10.98013019561768 11.94721508026123 10.73952865600586 11.98674297332764 10.73895835876465 C 12.04336071014404 10.73817920684814 12.14922046661377 11.03695583343506 12.09353923797607 11.1169490814209 C 12.03811359405518 11.19694137573242 11.96503067016602 11.24888515472412 11.94451332092285 11.40087127685547 Z M 11.93251419067383 12.18287658691406 C 11.85283374786377 12.20017337799072 11.75601100921631 12.10044193267822 11.74853134155273 12.02335929870605 C 11.74250602722168 11.9614953994751 11.77798366546631 11.89817523956299 11.83719825744629 11.87646293640137 C 11.92228031158447 11.84524631500244 11.93381214141846 12.00491905212402 11.98643112182617 12.03005981445313 C 12.05863189697266 12.06449794769287 11.98809337615967 12.17077445983887 11.93251419067383 12.18287658691406 Z M 11.39557647705078 11.00147819519043 C 11.37246227264404 10.9621057510376 11.26400375366211 10.89556694030762 11.30265045166016 10.82710647583008 C 11.35651588439941 10.73230934143066 11.4610767364502 10.82419586181641 11.5186824798584 10.88663196563721 C 11.59623336791992 10.97062397003174 11.6271390914917 11.17122936248779 11.52335739135742 11.24332714080811 C 11.45240116119385 11.29262161254883 11.37687587738037 11.30591869354248 11.40944480895996 11.1930456161499 C 11.44196319580078 11.08006858825684 11.41879558563232 11.04080104827881 11.39557647705078 11.00147819519043 Z M 11.56060028076172 16.6949291229248 C 11.60018157958984 16.67794418334961 11.73019504547119 17.11488914489746 11.76728248596191 17.23565864562988 C 11.77980136871338 17.27648735046387 11.83574485778809 17.57375717163086 11.83818531036377 17.61931037902832 C 11.84197616577148 17.69125366210938 11.6086483001709 17.49963569641113 11.62854290008545 17.40836906433105 C 11.70095157623291 17.07515335083008 11.4758825302124 16.73123550415039 11.56060028076172 16.6949291229248 Z M 11.62708854675293 17.7169132232666 C 11.67149925231934 17.68948554992676 11.94575881958008 17.6573314666748 11.92435932159424 17.7169132232666 C 11.89844036102295 17.78849029541016 11.64402103424072 17.9122200012207 11.52086353302002 17.86552238464355 C 11.48185443878174 17.85076904296875 11.57083320617676 17.75166320800781 11.62708854675293 17.7169132232666 Z M 13.71344089508057 19.38325309753418 C 13.8071460723877 19.41919708251953 13.92978477478027 19.6029224395752 13.89586448669434 19.69865226745605 C 13.87254238128662 19.76467132568359 13.7924976348877 19.85349464416504 13.73484039306641 19.79105949401855 C 13.66622257232666 19.7166748046875 13.71785545349121 19.57845687866211 13.62726593017578 19.54240798950195 C 13.57475185394287 19.52152442932129 13.45735836029053 19.48521614074707 13.43372440338135 19.38252449035645 C 13.42603492736816 19.34928321838379 13.6210298538208 19.34746360778809 13.71343898773193 19.38325309753418 Z M 13.52426338195801 19.12675666809082 C 13.56400012969971 19.10826683044434 13.62160396575928 19.16555976867676 13.61012554168701 19.21412658691406 C 13.59885406494141 19.26269340515137 13.57423210144043 19.30783271789551 13.52426338195801 19.27116012573242 C 13.47434520721436 19.23433303833008 13.46951580047607 19.1522102355957 13.52426338195801 19.12675666809082 Z M 14.30102348327637 23.90268325805664 C 14.27255725860596 23.90876007080078 14.09148406982422 23.93229103088379 14.06333160400391 23.93904304504395 C 14.06239604949951 23.93940734863281 14.06218814849854 23.94086074829102 14.06083679199219 23.94080924987793 C 14.05824089050293 23.94054985046387 14.05943489074707 23.93992614746094 14.06333160400391 23.93904304504395 C 14.08821201324463 23.93067932128906 14.03346252441406 23.78757667541504 14.10691165924072 23.75261878967285 C 14.23640632629395 23.69096183776855 14.21604442596436 23.51482200622559 14.22160243988037 23.49160385131836 C 14.22731494903564 23.46854019165039 14.12825965881348 23.40963935852051 14.12306594848633 23.34398078918457 C 14.11968898773193 23.30102348327637 14.22160243988037 23.09595108032227 14.22160243988037 23.09595108032227 C 14.22160243988037 23.09595108032227 14.39156055450439 23.2828426361084 14.42272663116455 23.31104850769043 C 14.4538402557373 23.33935737609863 14.49627876281738 23.49508285522461 14.44532203674316 23.49165534973145 C 14.39431381225586 23.48833084106445 14.35530471801758 23.74789237976074 14.32933330535889 23.76409721374512 C 14.28959655761719 23.78898048400879 14.35343456268311 23.89140892028809 14.30102348327637 23.90268325805664 Z M 14.4464635848999 19.59165191650391 C 14.41088199615479 19.57539176940918 14.37649726867676 19.52448844909668 14.42724418640137 19.51248931884766 C 14.45591735839844 19.50568580627441 14.50406837463379 19.51602172851563 14.53102684020996 19.53113746643066 C 14.62691402435303 19.58463859558105 14.74118900299072 19.82882308959961 14.56333541870117 19.81220436096191 C 14.51274299621582 19.80752944946289 14.56333541870117 19.64494514465332 14.4464635848999 19.59165191650391 Z M 14.43228244781494 19.22020530700684 C 14.37026214599609 19.35187911987305 14.40163612365723 19.16498947143555 14.3986759185791 19.10847473144531 C 14.3954029083252 19.0472354888916 14.35525131225586 18.92667198181152 14.22591304779053 18.83800506591797 C 14.16867256164551 18.79873657226563 14.18555164337158 18.88002586364746 14.16430759429932 18.90968704223633 C 14.14311504364014 18.93939971923828 14.10067653656006 18.80195617675781 14.10067653656006 18.77650451660156 C 14.10067653656006 18.75100135803223 14.11101341247559 18.72939300537109 14.17490291595459 18.75313186645508 C 14.22804164886475 18.77292060852051 14.31509876251221 18.85504341125488 14.34912014007568 18.89332580566406 C 14.38298797607422 18.93140029907227 14.49404335021973 19.08852767944336 14.43228244781494 19.22020530700684 Z M 14.3250207901001 19.12826538085938 C 14.32361698150635 19.17220878601074 14.27697277069092 19.28814697265625 14.25001430511475 19.29385948181152 C 14.22300338745117 19.29947090148926 14.22009563446045 19.1351203918457 14.22461318969727 19.08016586303711 C 14.22928714752197 19.02261161804199 14.23759937286377 18.97113418579102 14.27556800842285 18.97684860229492 C 14.29837036132813 18.980224609375 14.32641983032227 19.08432006835938 14.32501792907715 19.12826347351074 Z M 14.1570348739624 19.45519638061523 C 14.25858211517334 19.50121688842773 14.32839584350586 19.72208213806152 14.28092098236084 19.77231216430664 C 14.22419738769531 19.83214950561523 14.11548042297363 19.84020042419434 14.1238431930542 19.6744499206543 C 14.12903881072998 19.56848526000977 14.05133056640625 19.53866767883301 13.98681735992432 19.50116729736328 C 13.96385955810547 19.48781776428223 13.90521335601807 19.4014892578125 13.96302700042725 19.39229393005371 C 14.0129976272583 19.38445091247559 14.09849452972412 19.42875671386719 14.1570348739624 19.45519638061523 Z M 14.10072708129883 20.45188522338867 L 14.07797718048096 21.05520439147949 L 13.95513153076172 21.05520439147949 L 13.95513153076172 21.17124557495117 L 14.073561668396 21.17124557495117 L 14.06816005706787 21.31471252441406 L 13.95513153076172 21.31471252441406 L 13.95513153076172 21.43096160888672 L 14.06384754180908 21.43096160888672 L 14.05943298339844 21.54513359069824 C 14.05943298339844 21.54513359069824 13.47813510894775 21.57131195068359 13.48494148254395 21.48493194580078 C 13.48639583587646 21.46628379821777 13.48758983612061 21.44862174987793 13.48883724212646 21.43096160888672 L 13.56254577636719 21.43096160888672 L 13.56254577636719 21.31471252441406 L 13.49486351013184 21.31471252441406 C 13.49668121337891 21.2620964050293 13.49709606170654 21.21414947509766 13.49595355987549 21.17124557495117 L 13.56249237060547 21.17124557495117 L 13.56249237060547 21.05520439147949 L 13.48784923553467 21.05520439147949 C 13.48296737670898 21.01328659057617 13.47621440887451 20.97744369506836 13.46759128570557 20.94679832458496 L 13.56243896484375 20.94679832458496 L 13.56243896484375 20.8307056427002 L 13.43684005737305 20.8307056427002 L 13.43684005737305 20.86800193786621 C 13.36910724639893 20.74359893798828 13.2524938583374 20.75154304504395 13.13442611694336 20.68967819213867 C 13.09188461303711 20.66734313964844 13.04970741271973 20.64635848999023 13.01033306121826 20.62729454040527 L 13.0603551864624 20.62729454040527 L 13.0603551864624 20.51120185852051 L 12.9347562789917 20.51120185852051 L 12.9347562789917 20.59160995483398 C 12.8552303314209 20.55483436584473 12.79939270019531 20.53120231628418 12.79939270019531 20.53120231628418 C 12.79939270019531 20.53120231628418 12.77466678619385 20.42404174804688 12.75575923919678 20.31833839416504 L 12.844895362854 20.31833839416504 L 12.844895362854 20.20224571228027 L 12.73794269561768 20.20224571228027 C 12.73690414428711 20.19248008728027 12.73586654663086 20.18313026428223 12.73524188995361 20.174560546875 C 12.72677612304688 20.05924797058105 12.65878200531006 19.88315963745117 12.65878200531006 19.88315963745117 C 12.76739597320557 19.84041023254395 12.91231632232666 19.85495376586914 13.06840705871582 19.90071868896484 L 12.96654605865479 19.90071868896484 L 12.96654605865479 20.01680946350098 L 13.09219646453857 20.01680946350098 L 13.09219646453857 19.90814208984375 C 13.13879013061523 19.92263412475586 13.18642139434814 19.93962097167969 13.23420906066895 19.9587345123291 L 13.18642139434814 19.9587345123291 L 13.18642139434814 20.0749340057373 L 13.31186389923096 20.0749340057373 L 13.31186389923096 19.99135589599609 C 13.47922420501709 20.06485557556152 13.64482021331787 20.15768051147461 13.78091144561768 20.2408390045166 L 13.69156837463379 20.2408390045166 L 13.69156837463379 20.35698509216309 L 13.81716728210449 20.35698509216309 L 13.81716728210449 20.26317596435547 C 13.98587989807129 20.36789321899414 14.10072708129883 20.45188522338867 14.10072708129883 20.45188522338867 Z M 13.49054908752441 19.77786636352539 C 13.38936424255371 19.79188919067383 13.28178882598877 19.81547355651855 13.22963809967041 19.72036552429199 C 13.20376968383789 19.67346000671387 13.09983253479004 19.48355674743652 13.06440734863281 19.43576812744141 C 12.95205402374268 19.28414535522461 13.01890468597412 19.31811714172363 13.0837287902832 19.31868743896484 C 13.23587131500244 19.31988334655762 13.2509880065918 19.38631820678711 13.29664421081543 19.43270301818848 C 13.34801769256592 19.4852180480957 13.54612922668457 19.77023315429688 13.49054908752441 19.77786636352539 Z M 12.98088264465332 19.72124862670898 C 12.89870834350586 19.72659873962402 12.75518894195557 19.77215385437012 12.74963092803955 19.60983085632324 C 12.74526691436768 19.48610305786133 12.5870475769043 19.39431953430176 12.5870475769043 19.30840492248535 C 12.5870475769043 19.26908302307129 12.72875022888184 19.2608757019043 12.81611824035645 19.28409576416016 C 12.92062664031982 19.31198883056641 13.07931518554688 19.71480751037598 12.98088264465332 19.72124862670898 Z M 12.59380149841309 19.55331611633301 C 12.59992980957031 19.58681869506836 12.63146018981934 19.71948432922363 12.5870475769043 19.71948432922363 C 12.53167629241943 19.71948432922363 12.47303199768066 19.72208023071289 12.42612743377686 19.72088623046875 C 12.36608123779297 19.71948432922363 12.39059829711914 19.54448890686035 12.26047992706299 19.44610595703125 C 12.14038848876953 19.35530853271484 12.06460285186768 19.25032997131348 12.10693645477295 19.25069427490234 C 12.10693645477295 19.25069427490234 12.22765350341797 19.2528247833252 12.32987785339355 19.24986457824707 C 12.35273170471191 19.24918937683105 12.56720542907715 19.40652465820313 12.59380054473877 19.55331802368164 Z M 12.26084518432617 19.99260139465332 C 12.24666404724121 20.0462589263916 12.19955158233643 20.09243583679199 12.14204978942871 20.09321594238281 C 12.0667839050293 20.0942554473877 12.0175952911377 20.00460052490234 12.01691913604736 19.94902038574219 C 12.01562118530273 19.85988426208496 12.0661096572876 19.82352638244629 12.13659572601318 19.8243579864502 C 12.24022197723389 19.82544898986816 12.28073883056641 19.91733551025391 12.26084518432617 19.99260330200195 Z M 12.27964878082275 19.0234432220459 C 12.26546859741211 19.08432197570801 12.11836433410645 19.10967063903809 12.07722568511963 19.04993438720703 C 12.05400562286377 19.01606750488281 12.13249206542969 18.91587066650391 12.09514427185059 18.79250526428223 C 12.05426692962646 18.6574535369873 11.98554611206055 18.52530670166016 12.02065944671631 18.51663398742676 C 12.07789993286133 18.50271224975586 12.31616401672363 18.86725044250488 12.27964687347412 19.0234432220459 Z M 12.09743118286133 19.5663013458252 C 12.09743118286133 19.64058113098145 12.03219032287598 19.63772392272949 11.96248245239258 19.63907432556152 C 11.87573623657227 19.64094543457031 11.79408264160156 19.65398025512695 11.79262733459473 19.54926490783691 C 11.7911205291748 19.43587112426758 11.60828113555908 19.34206199645996 11.60698127746582 19.23724365234375 C 11.60646343231201 19.20404815673828 11.69710350036621 19.21449089050293 11.77564144134521 19.22010040283203 C 11.85843849182129 19.22597312927246 11.87215232849121 19.28409576416016 11.89059162139893 19.30819892883301 C 11.97551822662354 19.4192008972168 12.0974292755127 19.51659393310547 12.0974292755127 19.56630325317383 Z M 11.60641098022461 20.2407341003418 C 11.59664630889893 20.27953720092773 11.58916568756104 20.33360862731934 11.58303737640381 20.39375877380371 L 11.51156234741211 20.39375877380371 L 11.51156234741211 20.50995635986328 L 11.57327175140381 20.50995635986328 C 11.56049346923828 20.69363021850586 11.55690956115723 20.88576507568359 11.54948234558105 20.88862419128418 C 11.53784656524658 20.8932991027832 11.40388584136963 21.02071380615234 11.34342384338379 21.02071380615234 C 11.28311729431152 21.02071380615234 11.26950740814209 20.73804092407227 11.17003631591797 20.53109931945801 C 11.16686820983887 20.52445030212402 11.16338729858398 20.51702308654785 11.16001129150391 20.50995635986328 L 11.19258117675781 20.50995635986328 L 11.19258117675781 20.39375877380371 L 11.10386180877686 20.39375877380371 C 11.08308410644531 20.35137367248535 11.0605936050415 20.30618286132813 11.03690719604492 20.2602653503418 L 11.09139442443848 20.2602653503418 L 11.09139442443848 20.14411926269531 L 10.97499084472656 20.14411926269531 C 10.94533157348633 20.09051513671875 10.91447734832764 20.03805351257324 10.88315391540527 19.98953628540039 L 10.88471221923828 19.98953628540039 L 10.88471221923828 19.87344360351563 L 10.80009651184082 19.87344360351563 C 10.77391815185547 19.84087371826172 10.74784183502197 19.81256675720215 10.72239017486572 19.79106140136719 L 11.54948234558105 19.80165863037109 C 11.54948234558105 19.80165863037109 11.56023502349854 19.82986450195313 11.57306480407715 19.87344360351563 L 11.51156330108643 19.87344360351563 L 11.51156330108643 19.98953628540039 L 11.6016321182251 19.98953628540039 C 11.61009979248047 20.03264808654785 11.61612510681152 20.07918930053711 11.61742401123047 20.12469291687012 L 11.51156330108643 20.12469291687012 L 11.51156330108643 20.2407341003418 L 11.60641098022461 20.2407341003418 Z M 11.58443927764893 21.78537178039551 C 11.58667182922363 21.82495307922363 11.58651638031006 21.86681747436523 11.58288097381592 21.91190338134766 C 11.58246517181396 21.9159049987793 11.58246517181396 21.91990280151367 11.58225727081299 21.92385292053223 L 11.48678684234619 21.92385292053223 L 11.48678684234619 22.00877952575684 L 11.57966136932373 22.00877952575684 C 11.57986831665039 22.05739974975586 11.58288097381592 22.10539436340332 11.58874988555908 22.15235137939453 L 11.48678684234619 22.15235137939453 L 11.48678684234619 22.23722648620605 L 11.60210037231445 22.23722648620605 C 11.63700675964355 22.41949653625488 11.70697402954102 22.57755851745605 11.77694129943848 22.67640686035156 L 11.7379322052002 22.67640686035156 L 11.7379322052002 22.76128196716309 L 11.84290790557861 22.76128196716309 C 11.92830467224121 22.87945365905762 11.93064022064209 22.97715950012207 11.93064022064209 22.97715950012207 C 11.93064022064209 22.97715950012207 11.86597156524658 23.12758636474609 11.80072975158691 23.29079055786133 L 11.80072975158691 23.26346778869629 L 11.67507934570313 23.26346778869629 L 11.67507934570313 23.34839820861816 L 11.77787494659424 23.34839820861816 C 11.75289058685303 23.41181945800781 11.72910022735596 23.4746208190918 11.70987987518311 23.52910995483398 L 11.61222839355469 23.52910995483398 L 11.61222839355469 23.61393165588379 L 11.68183040618896 23.61393165588379 C 11.67300128936768 23.64353942871094 11.66733837127686 23.66712188720703 11.66650867462158 23.6811466217041 C 11.66069030761719 23.78425407409668 11.4158821105957 23.70363807678223 11.4046106338501 23.81022453308105 C 11.39344310760498 23.91696739196777 11.45764350891113 24.01498413085938 11.3746395111084 24.01264762878418 C 11.29142570495605 24.01036262512207 9.910462379455566 24.04308700561523 9.910462379455566 24.04308700561523 C 9.910462379455566 24.04308700561523 10.08841896057129 23.98865127563477 10.25069046020508 23.87998390197754 L 10.25069046020508 23.93031692504883 L 10.37634181976318 23.93031692504883 L 10.37634181976318 23.84538841247559 L 10.29936218261719 23.84538841247559 C 10.32252883911133 23.82767677307129 10.34512519836426 23.80902862548828 10.36610984802246 23.78903007507324 C 10.51466751098633 23.64774322509766 10.85723304748535 23.30330848693848 11.04111289978027 23.03855514526367 L 11.10417175292969 23.03855514526367 L 11.10417175292969 22.95368003845215 L 11.09617328643799 22.95368003845215 C 11.10879325866699 22.93227958679199 11.12042903900146 22.9114990234375 11.12972640991211 22.89191818237305 C 11.15081596374512 22.84807968139648 11.17294311523438 22.79426574707031 11.19527912139893 22.73338890075684 L 11.19527912139893 22.7766056060791 L 11.32082653045654 22.7766056060791 L 11.32082653045654 22.69172859191895 L 11.21018695831299 22.69172859191895 C 11.23117256164551 22.63142395019531 11.25210666656494 22.56472778320313 11.2724142074585 22.49294090270996 L 11.35443305969238 22.49294090270996 L 11.35443305969238 22.40806770324707 L 11.29537391662598 22.40806770324707 C 11.36975765228271 22.12346839904785 11.43078994750977 21.7746696472168 11.44211387634277 21.43412971496582 C 11.44351482391357 21.39294052124023 11.54200077056885 21.49641036987305 11.57508850097656 21.7005500793457 L 11.48678398132324 21.7005500793457 L 11.48678398132324 21.78542137145996 L 11.58443832397461 21.78542137145996 Z M 11.07503128051758 24.34575653076172 C 11.01134872436523 24.2778148651123 10.90055370330811 24.1967830657959 10.95686054229736 24.1801643371582 C 11.04646301269531 24.15377616882324 11.03586578369141 24.15471267700195 11.12977886199951 24.20992851257324 C 11.22374534606934 24.2651424407959 11.36243438720703 24.35578536987305 11.33833122253418 24.43915176391602 C 11.31443786621094 24.52220916748047 11.3341236114502 24.57513999938965 11.23641872406006 24.57077789306641 C 11.13876438140869 24.56661987304688 11.00708961486816 24.57077789306641 11.05804538726807 24.51140403747559 C 11.10900115966797 24.45192909240723 11.13871288299561 24.41370010375977 11.07502937316895 24.34575653076172 Z M 10.64182472229004 24.33303260803223 C 10.59943866729736 24.28207588195801 10.49783802032471 24.20837020874023 10.55268955230713 24.1928882598877 C 10.61299514770508 24.17595481872559 10.71407699584961 24.17595481872559 10.77350044250488 24.1928882598877 C 10.83302783966064 24.20992851257324 10.94319915771484 24.31298446655273 10.95270442962646 24.37578201293945 C 10.95654964447021 24.4011287689209 10.92933082580566 24.56246376037598 10.84139060974121 24.57082939147949 C 10.73158359527588 24.58142471313477 10.59221839904785 24.58225631713867 10.62494277954102 24.50720024108887 C 10.65740776062012 24.43234634399414 10.68436527252197 24.38398742675781 10.64182472229004 24.33303260803223 Z M 10.75859355926514 24.74556541442871 C 10.77142238616943 24.69923210144043 10.85951805114746 24.71268463134766 10.92423915863037 24.7129955291748 C 10.98911666870117 24.71335792541504 10.96745586395264 24.77008056640625 10.97213077545166 24.79594993591309 C 10.98444175720215 24.86508369445801 10.90663051605225 24.86586380004883 10.84139060974121 24.86627960205078 C 10.75718879699707 24.86700630187988 10.74913883209229 24.78010559082031 10.75859355926514 24.74556541442871 Z M 11.33656597137451 24.74785041809082 C 11.34975910186768 24.71736145019531 11.43260765075684 24.73169708251953 11.49743366241455 24.73200798034668 C 11.56225967407227 24.73226928710938 11.54600048065186 24.77065467834473 11.5514030456543 24.79475593566895 C 11.565842628479 24.8590087890625 11.47992897033691 24.86150360107422 11.41479206085205 24.86186790466309 C 11.33069515228271 24.86248970031738 11.32316303253174 24.77828979492188 11.33656597137451 24.74785041809082 Z M 11.46995544433594 24.49862670898438 C 11.47899436950684 24.4562931060791 11.4970178604126 24.41131019592285 11.46995544433594 24.36715698242188 C 11.42606353759766 24.29573440551758 11.33537006378174 24.18478584289551 11.39349460601807 24.18011093139648 C 11.45224285125732 24.1754322052002 11.48262977600098 24.19283485412598 11.52927589416504 24.23958396911621 C 11.57597160339355 24.28633117675781 11.6874942779541 24.43842124938965 11.67653465270996 24.51566123962402 C 11.67092323303223 24.55534934997559 11.64396667480469 24.57975959777832 11.56475353240967 24.57975959777832 C 11.52345752716064 24.57981300354004 11.45156860351563 24.58495712280273 11.46995639801025 24.49862480163574 Z M 9.873270988464355 24.32035636901855 C 9.818055152893066 24.26794624328613 9.687885284423828 24.17211151123047 9.73619270324707 24.16328048706055 C 9.796238899230957 24.15232276916504 9.837845802307129 24.10806655883789 9.870413780212402 24.12510299682617 C 9.921369552612305 24.15169715881348 10.17043781280518 24.35895347595215 10.17043781280518 24.42881774902344 C 10.17043781280518 24.49868202209473 10.15776348114014 24.57436370849609 10.05154037475586 24.57472610473633 C 9.945367813110352 24.57508659362793 9.867244720458984 24.53374290466309 9.868959426879883 24.49872970581055 C 9.872231483459473 24.43032264709473 9.92838191986084 24.37266540527344 9.873270034790039 24.32035827636719 Z M 9.493928909301758 24.3882999420166 C 9.468893051147461 24.35116195678711 9.33664608001709 24.22893714904785 9.379240036010742 24.22124862670898 C 9.444375991821289 24.20966720581055 9.498188972473145 24.19574546813965 9.543483734130859 24.17044830322266 C 9.577195167541504 24.15143966674805 9.725025177001953 24.33926582336426 9.754322052001953 24.37110710144043 C 9.78486442565918 24.40435028076172 9.794110298156738 24.5155086517334 9.740245819091797 24.54246711730957 C 9.698016166687012 24.56355667114258 9.444428443908691 24.5920238494873 9.491073608398438 24.53680419921875 C 9.537771224975586 24.48164176940918 9.522136688232422 24.43000984191895 9.493929862976074 24.3882999420166 Z M 7.372047424316406 24.50101661682129 C 7.393239974975586 24.52413368225098 7.180947780609131 24.56958389282227 7.134199142456055 24.5554027557373 C 7.087553977966309 24.54117012023926 6.990940093994141 24.35396575927734 7.047714233398438 24.31802177429199 C 7.104487419128418 24.28207588195801 7.318546772003174 24.10744285583496 7.376255035400391 24.10744285583496 C 7.4176025390625 24.10744285583496 7.474895477294922 24.13912773132324 7.550420761108398 24.14193344116211 C 7.596286773681641 24.14369964599609 7.350802421569824 24.20945930480957 7.32540225982666 24.27548217773438 C 7.299794673919678 24.341552734375 7.350751399993896 24.47795486450195 7.372047424316406 24.50101661682129 Z M 6.921595096588135 24.53997230529785 C 6.907258987426758 24.55976486206055 6.747688770294189 24.56236267089844 6.679850578308105 24.53680419921875 C 6.566614627838135 24.49436950683594 6.498724937438965 24.32165908813477 6.546096801757813 24.29054260253906 C 6.630556583404541 24.23517036437988 7.143496990203857 23.99186897277832 7.180999279022217 24.01882934570313 C 7.221307277679443 24.04776191711426 7.261823177337646 24.05981254577637 7.289872169494629 24.0739917755127 C 7.340724468231201 24.09975624084473 6.939722537994385 24.23709487915039 6.885597705841064 24.33048629760742 C 6.831420421600342 24.42388153076172 6.946474552154541 24.50564193725586 6.92159366607666 24.53997230529785 Z M 6.422939777374268 24.40944290161133 C 6.467455387115479 24.44761848449707 6.451197147369385 24.50605583190918 6.342427730560303 24.51701736450195 C 6.187273502349854 24.5325984954834 6.057051658630371 24.25101470947266 6.130654811859131 24.19429397583008 C 6.204258918762207 24.13762092590332 6.543915271759033 24.00184440612793 6.662813663482666 23.993896484375 C 6.662813663482666 23.993896484375 6.78742504119873 24.06978416442871 6.766284465789795 24.08116149902344 C 6.745090961456299 24.0925350189209 6.479453563690186 24.23631477355957 6.435042381286621 24.26384544372559 C 6.381696224212646 24.29693031311035 6.387099266052246 24.37869071960449 6.422939777374268 24.40944290161133 Z M 6.008796215057373 24.46304702758789 C 5.952281951904297 24.50288772583008 5.841642379760742 24.51852226257324 5.782427310943604 24.47457695007324 C 5.68705940246582 24.4039363861084 5.645764827728271 24.22686004638672 5.688253879547119 24.19294357299805 C 5.730692386627197 24.1590747833252 5.912545204162598 24.04999351501465 6.017366409301758 24.04999351501465 C 6.108007907867432 24.04983711242676 6.171793937683105 24.08962631225586 6.170235633850098 24.10739135742188 C 6.168988704681396 24.12297248840332 5.974876880645752 24.19709587097168 5.93243932723999 24.25579261779785 C 5.889949798583984 24.31448936462402 6.065206527709961 24.42341232299805 6.008796215057373 24.46304512023926 Z M 2.880980491638184 23.61528205871582 C 2.866799831390381 23.59097480773926 2.852930784225464 23.56993865966797 2.839062452316284 23.55159950256348 L 2.925184488296509 23.55159950256348 L 2.925184488296509 23.44968414306641 L 2.795170307159424 23.44968414306641 L 2.795170307159424 23.50526428222656 C 2.778704166412354 23.49274635314941 2.761614799499512 23.48469734191895 2.742811441421509 23.48293113708496 C 2.674973726272583 23.47638320922852 2.742707967758179 23.21443367004395 2.747434616088867 23.15973663330078 C 2.742811441421509 23.15828323364258 2.740370512008667 23.15615463256836 2.742811441421509 23.15251922607422 C 2.747278451919556 23.14597320556641 2.748213768005371 23.14992141723633 2.747434616088867 23.15973663330078 C 2.796001672744751 23.17558097839355 3.21227502822876 23.06878471374512 3.359430074691772 22.81260299682617 C 3.41729474067688 22.71198463439941 3.680387496948242 22.82781982421875 3.860163450241089 22.94349670410156 L 3.818868160247803 22.94349670410156 L 3.818868160247803 23.04546356201172 L 3.948882102966309 23.04546356201172 L 3.948882102966309 23.00551795959473 C 3.949505567550659 23.00608825683594 3.950284719467163 23.00661087036133 3.950959920883179 23.00712776184082 C 4.114944458007813 23.13542747497559 4.72101879119873 22.96567726135254 4.855396270751953 23.15251922607422 C 4.864538192749023 23.16518974304199 4.875342845916748 23.17651748657227 4.887134075164795 23.18721580505371 L 4.856799125671387 23.18721580505371 L 4.856799125671387 23.28923225402832 L 4.98676061630249 23.28923225402832 L 4.98676061630249 23.24881935119629 C 5.171315670013428 23.33172225952148 5.446043491363525 23.3501091003418 5.493052005767822 23.57543754577637 C 5.553929328918457 23.86678695678711 5.380387306213379 23.89447402954102 5.320963859558105 23.90564346313477 C 5.261489391326904 23.9167594909668 3.325719118118286 23.92839431762695 3.278761863708496 23.90564346313477 C 3.231701374053955 23.88283920288086 3.045329093933105 23.9150447845459 2.96019434928894 23.75879859924316 C 2.952298641204834 23.74440956115723 2.944974899291992 23.73074913024902 2.937650918960571 23.71714210510254 L 2.990113496780396 23.71714210510254 L 2.990113496780396 23.61517524719238 L 2.880980491638184 23.61517524719238 Z M 5.502452850341797 23.93722724914551 C 5.524373054504395 23.88543891906738 5.637817859649658 23.78544807434082 5.665555477142334 23.73979187011719 C 5.693240642547607 23.69413185119629 5.653919696807861 23.5134220123291 5.623896598815918 23.47056770324707 C 5.591951370239258 23.4251708984375 5.476169586181641 23.22046279907227 5.408071994781494 23.20378684997559 C 5.339870929718018 23.18716430664063 5.25442361831665 23.13200187683105 5.208817958831787 23.11849594116211 C 5.100775718688965 23.08665657043457 5.213077068328857 23.06182670593262 5.213077068328857 23.06182670593262 C 5.271929264068604 23.0604248046875 5.311042308807373 23.08530616760254 5.345169067382813 23.09621238708496 C 5.379295349121094 23.10712051391602 5.60431432723999 23.21204566955566 5.64098596572876 23.26019859313965 C 5.692877769470215 23.32808876037598 5.839356899261475 23.48859405517578 5.8716139793396 23.57985687255859 C 5.915714263916016 23.7045726776123 5.812191486358643 23.76965713500977 5.803464412689209 23.86138916015625 C 5.795985221862793 23.94008445739746 5.774740219116211 23.97213172912598 5.702590942382813 23.97800254821777 C 5.621870994567871 23.98465156555176 5.480481624603271 23.9891185760498 5.502453327178955 23.93722724914551 Z M 6.044533252716064 22.92615127563477 L 6.044533252716064 22.93009948730469 C 5.994096279144287 22.88308906555176 5.92501163482666 22.8480281829834 5.830474853515625 22.8484935760498 C 5.760507583618164 22.84880638122559 5.69350004196167 22.7853832244873 5.636207103729248 22.69370269775391 L 5.67158031463623 22.69370269775391 L 5.67158031463623 22.5916862487793 L 5.5815110206604 22.5916862487793 C 5.470611572265625 22.35414886474609 5.419084548950195 22.03594398498535 5.500427722930908 22.02477836608887 C 5.500427722930908 22.02477836608887 5.974825859069824 21.95138168334961 6.05980396270752 21.99569129943848 C 6.082503318786621 22.00748062133789 6.092995643615723 22.04503631591797 6.101099491119385 22.09983825683594 L 5.979552268981934 22.09983825683594 L 5.979552268981934 22.20190238952637 L 6.109462261199951 22.20190238952637 L 6.109462261199951 22.16668701171875 C 6.127279281616211 22.32651710510254 6.150238037109375 22.57205200195313 6.306586742401123 22.80428886413574 C 6.32190990447998 22.82709312438965 6.337648391723633 22.850830078125 6.353647232055664 22.87514114379883 L 6.251682758331299 22.87514114379883 L 6.251682758331299 22.97710800170898 L 6.381644725799561 22.97710800170898 L 6.381644725799561 22.91820335388184 C 6.616843700408936 23.27988243103027 6.900454521179199 23.75989151000977 6.9770188331604 23.81011962890625 C 7.06194543838501 23.86590766906738 6.9770188331604 23.89084053039551 6.9770188331604 23.89084053039551 C 6.9770188331604 23.89084053039551 6.568485260009766 23.92434310913086 6.530721664428711 23.89084053039551 C 6.500335216522217 23.86403656005859 6.527709484100342 23.81333923339844 6.484336853027344 23.69147872924805 L 6.595651149749756 23.69147872924805 L 6.595651149749756 23.58951568603516 L 6.46574068069458 23.58951568603516 L 6.46574068069458 23.64493751525879 C 6.458001136779785 23.62758827209473 6.449846267700195 23.60977172851563 6.439042091369629 23.58972358703613 C 6.33157205581665 23.39031410217285 6.187170028686523 23.21204376220703 6.170183658599854 23.15261840820313 C 6.163742542266846 23.12991905212402 6.149095058441162 23.08062744140625 6.119851112365723 23.02811241149902 L 6.174391269683838 23.02811241149902 L 6.174391269683838 22.9261474609375 L 6.044533252716064 22.92615127563477 Z M 7.478115558624268 24.35293006896973 C 7.495153427124023 24.30332183837891 7.683394908905029 24.15045356750488 7.683394908905029 24.15045356750488 C 7.743442058563232 24.18011283874512 7.822136402130127 24.20561599731445 7.822136402130127 24.20561599731445 C 7.822136402130127 24.20561599731445 7.664332389831543 24.29485511779785 7.753882884979248 24.43074035644531 C 7.843381404876709 24.56662178039551 7.648022651672363 24.55270195007324 7.580081462860107 24.55540466308594 C 7.512139320373535 24.55815887451172 7.46113109588623 24.40253448486328 7.478116035461426 24.35293006896973 Z M 7.70464038848877 24.78613471984863 C 7.728482723236084 24.74458122253418 7.7291579246521 24.67773056030273 7.827019214630127 24.67773056030273 C 7.924828052520752 24.67773056030273 8.058895111083984 24.65388488769531 8.058895111083984 24.70681762695313 C 8.058895111083984 24.75974655151367 8.00321102142334 24.8641529083252 7.877040386199951 24.8625431060791 C 7.779179096221924 24.86129760742188 7.640646934509277 24.89760208129883 7.70464038848877 24.7861328125 Z M 7.92223072052002 24.58781433105469 C 7.86031436920166 24.57077789306641 7.792372226715088 24.40689659118652 7.805098533630371 24.35297966003418 C 7.817824363708496 24.29916572570801 7.845302581787109 24.25163841247559 7.871689319610596 24.22691345214844 C 7.871689319610596 24.22691345214844 8.052816390991211 24.27651786804199 8.133536338806152 24.27226066589355 C 8.214203834533691 24.26799964904785 8.084656715393066 24.34555244445801 8.095306396484375 24.37702751159668 C 8.108084678649902 24.41437339782715 8.136340141296387 24.49322509765625 8.157587051391602 24.55545425415039 C 8.178882598876953 24.61752700805664 7.984095573425293 24.60474967956543 7.92223072052002 24.58781242370605 Z M 8.20106315612793 24.68666648864746 C 8.278406143188477 24.65799140930176 8.556926727294922 24.67887306213379 8.559782981872559 24.68666648864746 C 8.562640190124512 24.69445610046387 8.501502990722656 24.87859725952148 8.418341636657715 24.88186645507813 C 8.335127830505371 24.8851375579834 8.098111152648926 24.89786529541016 8.098111152648926 24.86088180541992 C 8.098162651062012 24.82395172119141 8.125640869140625 24.71445465087891 8.20106315612793 24.68666648864746 Z M 8.637489318847656 24.55815887451172 C 8.650163650512695 24.61758041381836 8.344476699829102 24.59633445739746 8.297780990600586 24.55815887451172 C 8.251083374023438 24.51987648010254 8.157013893127441 24.28597640991211 8.219918251037598 24.29765892028809 C 8.379850387573242 24.32737159729004 8.511527061462402 24.34015083312988 8.596453666687012 24.34295463562012 C 8.651618003845215 24.34482574462891 8.624763488769531 24.49863052368164 8.637489318847656 24.55815887451172 Z M 8.620504379272461 24.67243194580078 C 8.639359474182129 24.66827774047852 8.95133113861084 24.67414665222168 8.953927993774414 24.67965316772461 C 8.956525802612305 24.68505477905273 8.908580780029297 24.87054443359375 8.864689826965332 24.87667274475098 C 8.820693969726563 24.88264465332031 8.526175498962402 24.8863353729248 8.530902862548828 24.86716651916504 C 8.537914276123047 24.8387565612793 8.573756217956543 24.68266487121582 8.620505332946777 24.67243194580078 Z M 8.767763137817383 24.54257392883301 C 8.734259605407715 24.50076103210449 8.733689308166504 24.32966041564941 8.763556480407715 24.32461929321289 C 8.83897876739502 24.31184005737305 8.985095024108887 24.29958343505859 9.022546768188477 24.28644371032715 C 9.046648025512695 24.27792358398438 9.128302574157715 24.51442337036133 9.050907135009766 24.55540466308594 C 8.979538917541504 24.59306526184082 8.812799453735352 24.59898376464844 8.767764091491699 24.54257392883301 Z M 8.749168395996094 24.10723876953125 C 7.417394638061523 24.12443161010742 6.323988437652588 23.0587100982666 6.306795120239258 21.72683334350586 C 6.28960132598877 20.39521789550781 7.355269432067871 19.30154991149902 8.687044143676758 19.28440856933594 C 10.0189208984375 19.26721572875977 11.11227703094482 20.33304023742676 11.12957191467285 21.66460609436035 C 11.14671421051025 22.99643135070801 10.08104515075684 24.09004402160645 8.749168395996094 24.10723876953125 Z M 5.773961067199707 20.13321304321289 L 5.773961067199707 20.2180347442627 L 5.878315448760986 20.2180347442627 C 5.761598587036133 20.30410766601563 5.637869834899902 20.39682197570801 5.62784481048584 20.4475212097168 L 5.546034336090088 20.4475212097168 L 5.546034336090088 20.53244781494141 L 5.629143238067627 20.53244781494141 C 5.625662803649902 20.60709381103516 5.598912715911865 20.70303153991699 5.492688655853271 20.81528091430664 C 5.486143589019775 20.82218933105469 5.480897426605225 20.82914924621582 5.475546836853027 20.83600425720215 L 5.354935169219971 20.83600425720215 L 5.354935169219971 20.92098426818848 L 5.43648624420166 20.92098426818848 C 5.424591064453125 20.98637962341309 5.449471473693848 21.0512580871582 5.479079246520996 21.11208152770996 L 5.399190425872803 21.11208152770996 L 5.399190425872803 21.1970100402832 L 5.521049499511719 21.1970100402832 C 5.530295848846436 21.2169017791748 5.538242816925049 21.23622703552246 5.543177604675293 21.25456237792969 C 5.575693607330322 21.37746238708496 5.599431991577148 21.55224800109863 5.434668064117432 21.55827713012695 C 5.329742431640625 21.56217384338379 5.057248592376709 21.45251846313477 4.79857063293457 21.39792823791504 L 4.79857063293457 21.32655715942383 L 4.673023700714111 21.32655715942383 L 4.673023700714111 21.3761100769043 C 4.653700828552246 21.37361907958984 4.634793281555176 21.37195587158203 4.616041660308838 21.37055397033691 L 4.616041660308838 21.32655906677246 L 4.490443229675293 21.32655906677246 L 4.490443229675293 21.37169647216797 C 4.45969295501709 21.37496948242188 4.43018913269043 21.38006210327148 4.403750419616699 21.38909721374512 C 4.390867710113525 21.39351272583008 4.379492282867432 21.39517402648926 4.367960929870605 21.39709854125977 L 4.367960929870605 21.32655715942383 L 4.242362022399902 21.32655715942383 L 4.242362022399902 21.35756492614746 C 4.131982803344727 21.23856544494629 4.135982513427734 20.90571022033691 4.018123149871826 20.76977729797363 C 3.889563322067261 20.62137413024902 3.813154935836792 20.25839424133301 3.773937463760376 20.02148056030273 L 3.878291845321655 20.02148056030273 L 3.878291845321655 19.93660545349121 L 3.760640382766724 19.93660545349121 C 3.757679462432861 19.91728210449219 3.755082368850708 19.89894676208496 3.752796649932861 19.88315582275391 C 3.736642599105835 19.76950454711914 5.946361064910889 19.66826820373535 6.075284004211426 19.7578182220459 C 6.204311370849609 19.84731674194336 6.148472309112549 19.9747314453125 6.070245742797852 20.06459426879883 C 6.041728973388672 20.09732055664063 5.973839282989502 20.14785957336426 5.899560451507568 20.20245170593262 L 5.899560451507568 20.13326454162598 L 5.773961544036865 20.13326454162598 Z M 3.703034639358521 19.34980392456055 C 3.821933031082153 19.21402359008789 3.990125179290771 19.20649337768555 4.079830646514893 19.21599769592285 C 4.152187824249268 19.22358131408691 4.130216121673584 19.28996658325195 4.034224987030029 19.30850982666016 C 3.928104639053345 19.32902908325195 3.881667613983154 19.43509674072266 3.886238574981689 19.49571418762207 C 3.891796588897705 19.56999397277832 3.93683123588562 19.65325736999512 3.838866233825684 19.65455627441406 C 3.799026012420654 19.65507698059082 3.753886699676514 19.65606307983398 3.694463968276978 19.65606307983398 C 3.611666202545166 19.65606307983398 3.612393379211426 19.45332908630371 3.703034639358521 19.34980583190918 Z M 3.633690595626831 19.26695442199707 C 3.574215650558472 19.32445526123047 3.523882627487183 19.48984336853027 3.517753124237061 19.5762767791748 C 3.511935472488403 19.65788078308105 3.399997711181641 19.64754486083984 3.337873697280884 19.65606117248535 C 3.268165588378906 19.66561889648438 3.294708728790283 19.51015281677246 3.329355001449585 19.41457748413086 C 3.364156484603882 19.3185863494873 3.399581909179688 19.25412559509277 3.475834846496582 19.23916625976563 C 3.562943696975708 19.22212600708008 3.680543422698975 19.22150421142578 3.633690595626831 19.26695442199707 Z M 4.219454288482666 19.29224967956543 C 4.294252872467041 19.20711517333984 4.330924987792969 19.18509101867676 4.475898265838623 19.1751708984375 C 4.580408096313477 19.16794967651367 4.544775009155273 19.24918937683105 4.480157852172852 19.30850982666016 C 4.410190105438232 19.3728141784668 4.327341079711914 19.4611701965332 4.329574108123779 19.62058258056641 C 4.330093383789063 19.65616416931152 4.077961444854736 19.6829662322998 4.079882621765137 19.59798812866211 C 4.081544876098633 19.52625465393066 4.121697425842285 19.40335845947266 4.219454288482666 19.29224967956543 Z M 5.762169361114502 16.98903465270996 C 5.751261234283447 16.80463600158691 5.812294960021973 16.63659858703613 5.852394580841064 16.52798461914063 C 5.88735294342041 16.43344879150391 5.889845848083496 16.33579444885254 5.943763256072998 16.20520973205566 C 5.983500003814697 16.1087532043457 5.869795799255371 15.27017879486084 6.028639316558838 15.32196712493896 C 6.141979217529297 15.3588981628418 6.058350086212158 15.78914356231689 6.057883262634277 15.84353065490723 C 6.057052135467529 15.94045543670654 6.028639316558838 16.07499122619629 6.060791969299316 16.21456146240234 C 6.089672565460205 16.33969306945801 6.009627819061279 16.68454360961914 6.213712692260742 16.97137641906738 C 6.249605655670166 17.0218620300293 6.222387313842773 17.16772079467773 6.182754516601563 17.3284854888916 C 6.177196979522705 17.35123634338379 6.093204975128174 17.42800903320313 6.038040637969971 17.52005195617676 C 5.991239547729492 17.59807205200195 5.978513717651367 17.68564605712891 5.949892520904541 17.71515083312988 C 5.84636926651001 17.82205200195313 5.711629390716553 17.66029930114746 5.627584934234619 17.75187492370605 C 5.571901798248291 17.81259536743164 5.488688468933105 17.85685157775879 5.475131034851074 17.78496170043945 C 5.467288017272949 17.74325180053711 5.521880626678467 17.67671203613281 5.588419437408447 17.56544876098633 C 5.628104209899902 17.49901390075684 5.642076969146729 17.41190528869629 5.666334629058838 17.36032485961914 C 5.711577415466309 17.26407432556152 5.773025989532471 17.17348670959473 5.76216983795166 16.98903465270996 Z M 5.081037521362305 8.296847343444824 C 4.983695507049561 8.38930606842041 4.938765525817871 8.552096366882324 4.958607196807861 8.683512687683105 C 4.978345394134521 8.813474655151367 4.972268581390381 9.052828788757324 4.870667457580566 9.106538772583008 C 4.831294059753418 9.127264022827148 4.877627849578857 9.34459400177002 4.799089431762695 9.406822204589844 C 4.732654094696045 9.45933723449707 4.54841136932373 9.359813690185547 4.572824478149414 9.280237197875977 C 4.584511756896973 9.242266654968262 4.714214324951172 9.16684627532959 4.727511405944824 9.057348251342773 C 4.740653038024902 8.947853088378906 4.631364345550537 8.849316596984863 4.514336109161377 8.697693824768066 C 4.402657985687256 8.552876472473145 4.610898494720459 8.50108814239502 4.720290660858154 8.502179145812988 C 4.829683780670166 8.503217697143555 4.951075077056885 8.530695915222168 4.900534152984619 8.401044845581055 C 4.849993228912354 8.27144718170166 4.616975784301758 8.093384742736816 4.581446647644043 7.878547191619873 C 4.54596996307373 7.663710117340088 4.747925281524658 7.706562995910645 4.793063163757324 7.697421073913574 C 4.838202476501465 7.68838357925415 4.807451725006104 7.932309150695801 4.885782718658447 7.941295623779297 C 4.964112758636475 7.950282096862793 4.944010734558105 7.987160682678223 5.010134696960449 7.872990131378174 C 5.076258182525635 7.758766651153564 4.862615585327148 7.818345546722412 4.890093803405762 7.591457366943359 C 4.917572021484375 7.364673137664795 4.854356288909912 7.184273719787598 4.883652687072754 7.095919132232666 C 4.912949085235596 7.00756311416626 4.997304916381836 6.869810581207275 5.060311794281006 6.876250743865967 C 5.123422622680664 6.882796287536621 5.040313243865967 7.115345478057861 5.103840351104736 7.204376220703125 C 5.206739902496338 7.34877872467041 5.268968105316162 7.385866641998291 5.295354843139648 7.443263530731201 C 5.336182117462158 7.531982421875 5.33851957321167 7.623921871185303 5.239100456237793 7.691708087921143 C 5.147368431091309 7.754247665405273 5.216297149658203 7.803905487060547 5.104307651519775 7.901247024536133 C 5.050909519195557 7.947632789611816 5.178378582000732 8.204441070556641 5.081036567687988 8.296847343444824 Z M 4.85316276550293 11.88695812225342 C 4.789376258850098 11.95770359039307 4.679775714874268 12.00658226013184 4.600042819976807 12.01385593414307 C 4.407177925109863 12.03146362304688 4.545138835906982 11.92679882049561 4.630429267883301 11.7833309173584 C 4.715824127197266 11.63981151580811 4.541658401489258 11.39973068237305 4.681490421295166 11.35121440887451 C 4.842202186584473 11.2954797744751 4.882822036743164 11.43577861785889 4.964165210723877 11.51758861541748 C 5.013615608215332 11.56734943389893 4.935648441314697 11.67497730255127 4.890198230743408 11.72795963287354 C 4.846617698669434 11.77875900268555 4.895028591156006 11.84057235717773 4.85316276550293 11.88695812225342 Z M 4.409462928771973 11.54797554016113 C 4.327184677124023 11.75221729278564 4.183821201324463 11.74987983703613 4.107880592346191 11.87511444091797 C 4.065079212188721 11.94575691223145 4.242829322814941 12.02019214630127 3.970698118209839 12.15607643127441 C 3.885043859481812 12.19877338409424 3.780118703842163 12.14511585235596 3.855903625488281 12.0913553237915 C 3.931637048721313 12.03764629364014 3.928987741470337 11.8326244354248 3.787806272506714 11.72749137878418 C 3.70474910736084 11.66562843322754 3.678621530532837 11.47026920318604 3.784325838088989 11.45697116851807 C 3.889978170394897 11.44362163543701 3.959218740463257 11.68385982513428 4.066378116607666 11.67923641204834 C 4.207248210906982 11.67315864562988 4.252490997314453 11.52299118041992 4.246465682983398 11.42300033569336 C 4.241063594818115 11.33298301696777 4.144552707672119 11.3077392578125 4.073390483856201 11.22047328948975 C 4.030277252197266 11.16769790649414 4.018070697784424 11.08007049560547 3.956310272216797 11.03810119628906 C 3.794143438339233 10.92777347564697 3.852527618408203 10.84149551391602 3.953869342803955 10.84824848175049 C 4.145176410675049 10.8610782623291 4.229583740234375 11.06178665161133 4.306304454803467 11.11554718017578 C 4.413359642028809 11.19050121307373 4.491742134094238 11.34373474121094 4.409463882446289 11.54797458648682 Z M 4.3659348487854 12.33164501190186 C 4.296850204467773 12.40452098846436 4.189535140991211 12.39527416229248 4.090895175933838 12.37740612030029 C 3.992410659790039 12.35958957672119 4.191561222076416 12.35278606414795 4.2545166015625 12.05468273162842 C 4.282721519470215 11.92170810699463 4.509142398834229 12.18054103851318 4.3659348487854 12.33164501190186 Z M 4.456679821014404 9.719470024108887 C 4.404995918273926 9.664669036865234 4.31009578704834 9.572781562805176 4.292382717132568 9.516319274902344 C 4.274670124053955 9.459909439086914 4.2906174659729 9.354619979858398 4.37788200378418 9.319713592529297 C 4.452212810516357 9.289951324462891 4.495169639587402 9.424691200256348 4.527842044830322 9.53278636932373 C 4.572149276733398 9.679369926452637 4.688138961791992 9.700614929199219 4.689749240875244 9.791515350341797 C 4.692450046539307 9.945942878723145 4.590174198150635 10.06437301635742 4.47844409942627 10.09683799743652 C 4.369467258453369 10.1284704208374 4.130527973175049 10.12182235717773 4.055832862854004 10.03435039520264 C 3.981138706207275 9.946773529052734 4.028718948364258 9.88880443572998 4.067936420440674 9.881272315979004 C 4.164031028747559 9.863040924072266 4.204183578491211 10.00183296203613 4.313315868377686 10.02536392211914 C 4.415592193603516 10.04733657836914 4.390036106109619 9.974303245544434 4.450758457183838 9.924489974975586 C 4.520881652832031 9.866935729980469 4.50831127166748 9.77421760559082 4.456679821014404 9.719470024108887 Z M 4.205585956573486 10.44563579559326 C 4.181899547576904 10.43020915985107 4.130735397338867 10.35328102111816 4.203872203826904 10.3125057220459 C 4.203872203826904 10.3125057220459 4.254308700561523 10.2695484161377 4.358506679534912 10.28237819671631 C 4.460367679595947 10.29494857788086 4.48187255859375 10.3544225692749 4.580044746398926 10.33624362945557 C 4.678217887878418 10.31795787811279 4.725797653198242 10.16441440582275 4.795817375183105 10.1082124710083 C 4.865784645080566 10.05206203460693 4.984994411468506 10.17672538757324 4.99138355255127 10.3450231552124 C 4.994708061218262 10.43275356292725 4.959334850311279 10.49404716491699 4.8262038230896 10.49721527099609 C 4.802102565765381 10.49778747558594 4.789584159851074 10.4234561920166 4.73052453994751 10.43888378143311 C 4.650272369384766 10.45981693267822 4.765481948852539 10.61538600921631 4.662582874298096 10.75703620910645 C 4.573187828063965 10.88014125823975 4.538074493408203 10.98231410980225 4.511271953582764 10.86938953399658 C 4.492987632751465 10.79225254058838 4.548203468322754 10.66966724395752 4.456315994262695 10.56718349456787 C 4.407177925109863 10.51233100891113 4.276695728302002 10.49228096008301 4.205585479736328 10.44563579559326 Z M 4.822723865509033 9.456741333007813 C 4.869420528411865 9.45570182800293 4.917416572570801 9.499385833740234 4.907598972320557 9.559017181396484 C 4.897729873657227 9.618595123291016 4.910819530487061 9.693393707275391 4.875602245330811 9.712301254272461 C 4.798206806182861 9.753752708435059 4.80428409576416 9.656514167785645 4.780494213104248 9.654383659362793 C 4.692139148712158 9.646748542785645 4.693645000457764 9.459753036499023 4.822723865509033 9.456741333007813 Z M 4.834566593170166 11.14806461334229 C 4.853370189666748 11.06308650970459 4.868278026580811 10.91011333465576 4.831138134002686 10.88222026824951 C 4.794050693511963 10.85437870025635 4.700501441955566 10.71189785003662 4.786155223846436 10.67948532104492 C 4.827242374420166 10.66400527954102 4.853370189666748 10.66696739196777 4.939855575561523 10.76488018035889 C 5.026341438293457 10.86274147033691 5.064051628112793 11.13965129852295 5.002603054046631 11.21408557891846 C 4.941206455230713 11.28851985931396 4.815815448760986 11.23294067382813 4.834566593170166 11.14806461334229 Z M 4.62570333480835 6.584122657775879 C 4.55620288848877 6.461847305297852 4.133903980255127 6.502674579620361 3.959686517715454 6.197767734527588 C 3.892991542816162 6.081154823303223 3.944622993469238 5.986722469329834 3.933195352554321 5.857227802276611 C 3.91756010055542 5.680205345153809 3.789883613586426 5.656415462493896 3.788532972335815 5.550242900848389 C 3.78713059425354 5.444070816040039 3.957712411880493 5.338002681732178 3.957712411880493 5.338002681732178 C 3.957712411880493 5.338002681732178 3.961037158966064 5.359195232391357 3.9775550365448 5.375246524810791 C 3.921040773391724 5.312966823577881 3.946492910385132 5.070183277130127 4.041185855865479 5.05439281463623 C 4.217117786407471 5.024940490722656 4.21389627456665 5.156357288360596 4.359441757202148 5.297850608825684 C 4.49184513092041 5.426565170288086 4.554125308990479 5.277124881744385 4.593342304229736 5.391244888305664 C 4.60606861114502 5.428279876708984 4.59874439239502 5.482612609863281 4.735511302947998 5.546554565429688 C 4.855915069580078 5.602860927581787 4.927129745483398 5.558241844177246 4.994915962219238 5.57294225692749 C 5.078959465026855 5.591278076171875 5.184144973754883 5.757340908050537 5.148823738098145 5.982929706573486 C 5.133552074432373 6.080479621887207 5.097970962524414 6.127696514129639 4.964840412139893 6.206130027770996 C 4.820126533508301 6.291368961334229 4.764132022857666 6.119489192962646 4.771455764770508 6.025938510894775 C 4.778728008270264 5.932441234588623 4.683671474456787 5.823204517364502 4.600510597229004 5.790375709533691 C 4.517349243164063 5.757443904876709 4.360532760620117 5.79209041595459 4.217065334320068 5.737653732299805 C 4.088193416595459 5.688826560974121 4.15379810333252 5.427032947540283 4.045860290527344 5.393997192382813 C 4.067156791687012 5.41087818145752 4.055365562438965 5.538087368011475 4.044301986694336 5.623378276824951 C 4.024927139282227 5.772299766540527 4.182523250579834 6.00578498840332 4.27487850189209 6.049365520477295 C 4.461042881011963 6.137149810791016 4.635000705718994 6.158602237701416 4.774001121520996 6.230699062347412 C 4.932219982147217 6.312769412994385 5.056105136871338 6.507712364196777 4.958348274230957 6.694604873657227 C 4.860746383666992 6.881548404693604 4.629443168640137 6.872978210449219 4.567942142486572 6.835526943206787 C 4.50649356842041 6.798023700714111 4.695255279541016 6.706447601318359 4.62570333480835 6.584121227264404 Z M 3.248323440551758 6.474521636962891 C 2.990684986114502 6.2527756690979 2.938066482543945 6.124943256378174 2.940144062042236 5.960387229919434 C 2.941546440124512 5.854111671447754 3.023876667022705 5.753757476806641 3.115089178085327 5.805804252624512 C 3.206405401229858 5.857851028442383 3.342236757278442 6.042925357818604 3.425865650177002 6.08151912689209 C 3.509494304656982 6.120112895965576 3.395478487014771 6.275630950927734 3.471159934997559 6.301758289337158 C 3.524505853652954 6.320146560668945 3.511156320571899 6.271527290344238 3.534323215484619 6.258489608764648 C 3.562424659729004 6.242699146270752 3.559100151062012 6.166706085205078 3.564294815063477 6.117568016052246 C 3.566216707229614 6.100114345550537 3.597018718719482 6.121723651885986 3.606888055801392 6.098660469055176 C 3.621847629547119 6.064118385314941 3.626522541046143 6.00459098815918 3.604758501052856 5.960283279418945 C 3.565177917480469 5.879875659942627 3.51557183265686 5.961426734924316 3.35319709777832 5.666232585906982 C 3.303487539291382 5.575955390930176 3.167811632156372 5.496533870697021 3.113998413085938 5.454771041870117 C 3.018162965774536 5.380492687225342 3.024396419525146 5.317485332489014 3.007670640945435 5.267256259918213 C 2.978841781616211 5.181185722351074 2.814701080322266 5.006240367889404 2.889032125473022 4.962972164154053 C 3.00491738319397 4.895705699920654 3.054367542266846 5.105244636535645 3.163240671157837 5.150591373443604 C 3.271438360214233 5.195626258850098 3.294708967208862 5.135683536529541 3.378804922103882 5.180147171020508 C 3.467887401580811 5.227364063262939 3.392881870269775 5.390517711639404 3.530323505401611 5.513571262359619 C 3.66781759262085 5.63667631149292 3.74703049659729 5.635689258575439 3.782040596008301 5.714540004730225 C 3.790714979171753 5.733914375305176 3.754925966262817 5.780351638793945 3.774924278259277 5.817906856536865 C 3.844528198242188 5.948647975921631 3.842450618743896 6.14317512512207 3.776119232177734 6.242647171020508 C 3.661532163619995 6.414475440979004 3.421190977096558 6.412605762481689 3.478120565414429 6.444809913635254 C 3.535154342651367 6.477014541625977 3.709735631942749 6.465327262878418 3.798454761505127 6.654244899749756 C 3.904678583145142 6.880874156951904 3.809362888336182 7.14178466796875 3.642988443374634 7.223231315612793 C 3.475523471832275 7.305145740509033 3.22765040397644 7.221413135528564 3.282814502716064 7.179027557373047 C 3.373351573944092 7.109475612640381 3.445396661758423 7.011719226837158 3.475523471832275 6.856927394866943 C 3.501235723495483 6.725147247314453 3.4502272605896 6.648219585418701 3.248323678970337 6.474520683288574 Z M 4.264801502227783 4.341107845306396 C 4.30936861038208 4.293787479400635 4.327496528625488 4.529350280761719 4.4295654296875 4.542387962341309 C 4.531685829162598 4.555373668670654 4.633910179138184 4.581137657165527 4.677282333374023 4.65198802947998 C 4.720654964447021 4.722838878631592 4.721642017364502 4.795247554779053 4.81571102142334 4.847034931182861 C 4.90983247756958 4.898770809173584 5.084102630615234 4.994242668151855 5.111112594604492 5.112776756286621 C 5.138123035430908 5.231259822845459 5.00161600112915 5.356234550476074 4.917312145233154 5.442253589630127 C 4.833059787750244 5.528271198272705 4.869524002075195 5.296811580657959 4.706941604614258 5.200716972351074 C 4.544307708740234 5.104569911956787 4.258463382720947 5.087428569793701 4.185794830322266 4.933676242828369 C 4.115827560424805 4.78584623336792 4.089596271514893 4.527115821838379 4.264801025390625 4.341107845306396 Z M 6.551447868347168 4.553088188171387 C 6.535241603851318 4.418139457702637 6.515659332275391 4.277788639068604 6.621364116668701 4.293423652648926 C 6.700577259063721 4.305162906646729 6.729457378387451 4.391128540039063 6.676371097564697 4.551530361175537 C 6.631128311157227 4.688348770141602 6.62754487991333 4.768496990203857 6.628116130828857 4.817063808441162 C 6.631180763244629 5.052210807800293 6.510672092437744 5.209911346435547 6.303886413574219 5.200716972351074 C 6.075751304626465 5.190432548522949 6.209505558013916 5.122646808624268 6.080426216125488 4.996891498565674 C 6.011133670806885 4.929417133331299 5.867874622344971 4.863345146179199 5.822527885437012 4.759562492370605 C 5.781960487365723 4.666635990142822 5.775259494781494 4.551010608673096 5.808087825775146 4.427489280700684 C 5.839461326599121 4.309630393981934 5.987967014312744 4.417671680450439 6.145511150360107 4.336328983306885 C 6.303054809570313 4.25508975982666 6.253708839416504 4.157280921936035 6.335779190063477 4.161072731018066 C 6.414785385131836 4.164708614349365 6.459248542785645 4.363443374633789 6.467092037200928 4.46525239944458 C 6.474831581115723 4.567060947418213 6.467040538787842 4.679206848144531 6.467040538787842 4.679206848144531 C 6.467040538787842 4.679206848144531 6.560953617095947 4.632250308990479 6.551447868347168 4.553088665008545 Z M 7.237618923187256 5.605874538421631 C 7.277304172515869 5.651844024658203 7.248475074768066 5.813959121704102 7.195440769195557 5.878212928771973 C 7.106773853302002 5.985683441162109 6.891365051269531 5.96610164642334 6.864666938781738 6.099491119384766 C 6.836357593536377 6.241504669189453 6.859888553619385 6.232985973358154 6.81080150604248 6.312562942504883 C 6.802646160125732 6.325808525085449 6.726861476898193 6.389802932739258 6.663698196411133 6.379985332489014 C 6.574771404266357 6.366116523742676 6.527866363525391 6.32471752166748 6.489480018615723 6.203429698944092 C 6.453587055206299 6.089985847473145 6.436082363128662 5.847410678863525 6.322586536407471 5.77406644821167 C 6.199792861938477 5.69485330581665 5.960801601409912 5.365585327148438 5.933947086334229 5.278372287750244 C 5.911818981170654 5.20637845993042 5.957684993743896 5.194639205932617 5.975449562072754 5.205599784851074 C 6.091491222381592 5.277125358581543 6.228776454925537 5.393426418304443 6.331624507904053 5.487807750701904 C 6.428966522216797 5.577150344848633 6.427252769470215 5.126230239868164 6.632999420166016 5.19713306427002 C 6.763741493225098 5.242271423339844 6.703954219818115 5.465628147125244 6.745353221893311 5.628262042999268 C 6.836981296539307 5.988072872161865 6.806178569793701 5.517051696777344 6.916245937347412 5.490145206451416 C 7.053012371063232 5.45669412612915 7.019872665405273 5.669972896575928 7.004030227661133 5.761444568634033 C 6.988239288330078 5.852813243865967 7.189987182617188 5.550814628601074 7.237618923187256 5.605874538421631 Z M 7.686876773834229 4.208963871002197 C 7.53863000869751 4.200860500335693 7.457130908966064 4.173590660095215 7.268940448760986 4.077651023864746 C 7.220217227935791 4.052822589874268 7.242190361022949 3.976777791976929 7.369814395904541 4.00067138671875 C 7.497595310211182 4.024513721466064 7.536968231201172 4.055003643035889 7.778348922729492 4.063366889953613 C 8.046012878417969 4.072665214538574 8.251552581787109 3.964155435562134 8.387850761413574 3.904473066329956 C 8.52020263671875 3.846452474594116 8.582015037536621 3.815130472183228 8.597858428955078 3.721580982208252 C 8.613649368286133 3.627875089645386 8.554277420043945 3.637173175811768 8.429509162902832 3.757681608200073 C 8.304794311523438 3.8781898021698 7.815747737884521 3.939067363739014 7.630984783172607 3.90390157699585 C 7.422329425811768 3.864113569259644 7.371216297149658 3.775601863861084 7.254604339599609 3.623979568481445 C 7.195128917694092 3.546688079833984 7.198037624359131 3.452099323272705 7.286341190338135 3.450904369354248 C 7.367008686065674 3.449813365936279 7.43806791305542 3.693999052047729 7.561899662017822 3.743345260620117 C 7.738662242889404 3.813884019851685 7.948929309844971 3.847075700759888 8.148651123046875 3.795236349105835 C 8.276691436767578 3.762044668197632 8.40275764465332 3.710205078125 8.422548294067383 3.634420156478882 C 8.433819770812988 3.591203212738037 8.411640167236328 3.534273147583008 8.365774154663086 3.512145519256592 C 8.139301300048828 3.402805089950562 8.115303039550781 3.48835563659668 7.96830415725708 3.392572402954102 C 7.83247184753418 3.304008960723877 7.88898754119873 3.198408365249634 7.799332141876221 2.962326049804688 C 7.73201322555542 2.78499174118042 7.891064167022705 2.733931541442871 7.891064167022705 2.733931541442871 C 7.947682857513428 2.733152389526367 7.993756294250488 2.724841356277466 8.000925064086914 2.879892110824585 C 8.008716583251953 3.049694776535034 7.953501224517822 3.152334690093994 8.0400390625 3.27855658531189 C 8.126628875732422 3.404882907867432 8.220905303955078 3.292945146560669 8.42125129699707 3.415271282196045 C 8.521084785461426 3.476252794265747 8.731559753417969 3.530221700668335 8.773736953735352 3.523884773254395 C 8.888740539550781 3.506847143173218 8.916373252868652 3.403792142868042 9.052309036254883 3.390961885452271 C 9.172922134399414 3.379534244537354 9.14674186706543 3.465448617935181 9.282885551452637 3.500302791595459 C 9.417366981506348 3.534793138504028 9.531693458557129 3.508718013763428 9.651215553283691 3.403168916702271 C 9.74736213684082 3.318241834640503 9.784969329833984 3.340888977050781 9.815875053405762 3.239651441574097 C 9.848028182983398 3.134154796600342 9.799617767333984 3.125584125518799 9.819978713989258 2.989440679550171 C 9.84039306640625 2.853245258331299 10.12358665466309 3.024346590042114 9.992067337036133 3.378859043121338 C 9.942721366882324 3.511678218841553 9.840860366821289 3.617694616317749 9.684511184692383 3.684857130050659 C 9.528317451477051 3.751967668533325 9.228813171386719 3.682207822799683 9.031791687011719 3.560245037078857 C 8.844380378723145 3.44409966468811 8.984991073608398 3.652340650558472 9.186738967895508 3.719606876373291 C 9.587636947631836 3.853152990341187 9.673239707946777 3.798249006271362 9.787151336669922 3.742981195449829 C 9.986716270446777 3.646314859390259 9.993522644042969 3.494017124176025 10.13730049133301 3.446852922439575 C 10.25448417663574 3.408414840698242 10.25204467773438 3.561387777328491 10.16051959991455 3.709841728210449 C 10.07029438018799 3.856218099594116 9.951499938964844 3.949559926986694 9.713703155517578 3.961143016815186 C 9.476010322570801 3.972674608230591 9.387395858764648 3.95013165473938 9.240032196044922 3.900109529495239 C 9.011117935180664 3.82235050201416 8.978965759277344 3.753993034362793 8.817681312561035 3.641587972640991 C 8.717483520507813 3.571776151657104 8.766570091247559 3.693894624710083 8.819084167480469 3.752695083618164 C 8.91673755645752 3.861827611923218 9.111369132995605 4.029448509216309 9.370720863342285 4.051316738128662 C 9.545511245727539 4.066120147705078 9.748660087585449 4.122063159942627 10.03705024719238 4.02020263671875 C 10.3075704574585 3.924627304077148 10.23298168182373 3.738722324371338 10.43041610717773 3.61353874206543 C 10.50308609008789 3.567517042160034 10.55643081665039 3.667195796966553 10.59393405914307 3.729787588119507 C 10.64239692687988 3.810819149017334 10.63444995880127 3.937353134155273 10.60452938079834 3.976362466812134 C 10.55533885955811 4.040304660797119 10.49669551849365 3.990075826644897 10.51482486724854 3.919432640075684 C 10.54448318481445 3.804741621017456 10.41233921051025 3.805780649185181 10.37930393218994 3.885461807250977 C 10.27302837371826 4.141905307769775 9.956900596618652 4.40053129196167 9.489048004150391 4.342874050140381 C 9.114745140075684 4.296696662902832 8.973199844360352 4.188135147094727 8.822564125061035 4.02446174621582 C 8.742208480834961 3.937145709991455 8.739351272583008 3.793210506439209 8.658164024353027 3.792950868606567 C 8.599104881286621 3.792847156524658 8.642374038696289 3.839180707931519 8.558329582214355 3.964103937149048 C 8.483479499816895 4.075521945953369 8.360997200012207 4.157540321350098 8.21410083770752 4.274361133575439 C 8.091514587402344 4.371806621551514 7.993861198425293 4.319655418395996 7.736326694488525 4.462499618530273 C 7.616545677185059 4.528934955596924 7.406020164489746 4.51413106918335 7.421498775482178 4.39492130279541 C 7.436925888061523 4.275866985321045 7.636283397674561 4.320953845977783 7.737521171569824 4.268698692321777 C 7.839018821716309 4.216392517089844 7.7725830078125 4.213639259338379 7.686876773834229 4.208963871002197 Z M 7.621427536010742 3.159398794174194 C 7.736846446990967 3.248481035232544 7.618779182434082 3.292477130889893 7.78499698638916 3.444566965103149 C 7.951164722442627 3.596553087234497 8.168962478637695 3.612239837646484 8.168962478637695 3.612239837646484 C 8.168962478637695 3.612239837646484 8.033909797668457 3.685479879379272 7.804268836975098 3.655352830886841 C 7.627506256103516 3.632186412811279 7.464767456054688 3.453033685684204 7.412356376647949 3.340472936630249 C 7.359946250915527 3.227859735488892 7.512243747711182 3.074990749359131 7.621427536010742 3.159398794174194 Z M 9.435858726501465 2.835843801498413 C 9.494295120239258 2.772732973098755 9.644774436950684 2.792159795761108 9.645554542541504 2.960559606552124 C 9.646385192871094 3.127037763595581 9.649969100952148 3.28525710105896 9.451389312744141 3.385871171951294 C 9.20673656463623 3.509859800338745 9.148872375488281 3.298243045806885 9.148872375488281 3.298243045806885 C 9.148872375488281 3.298243045806885 9.303975105285645 3.269310474395752 9.397939682006836 3.188850402832031 C 9.498709678649902 3.102624654769897 9.356280326843262 2.921810150146484 9.435857772827148 2.835843801498413 Z M 10.65689086914063 5.975294589996338 C 10.83209419250488 5.834580898284912 10.7348575592041 5.406412124633789 10.66135692596436 5.313018321990967 C 10.56765079498291 5.193912506103516 10.78768348693848 5.320497989654541 10.88393402099609 5.313277721405029 C 10.94294261932373 5.308914661407471 10.87967491149902 5.210430145263672 10.73537635803223 5.149397373199463 C 10.67974472045898 5.125918865203857 10.66857814788818 5.065300464630127 10.74098682403564 5.021720409393311 C 10.80321407318115 4.984217166900635 10.92548942565918 5.052262783050537 11.10599136352539 5.230584621429443 C 11.21512413024902 5.338315010070801 11.15341472625732 5.608160495758057 11.07150077819824 5.75531530380249 C 10.99218463897705 5.897639751434326 11.00272750854492 6.013525009155273 10.84445667266846 6.020122528076172 C 10.72675323486328 6.025004386901855 10.67294025421143 6.190340518951416 10.61575031280518 6.286123275756836 C 10.54921054840088 6.397438049316406 10.4639720916748 6.455925941467285 10.33614063262939 6.433954238891602 C 10.24835586547852 6.418942451477051 10.25370597839355 6.356455326080322 10.28274250030518 6.331106185913086 C 10.30133819580078 6.314795970916748 10.36081409454346 6.327573776245117 10.37546157836914 6.317549228668213 C 10.41940402984619 6.287682056427002 10.3985767364502 6.185925006866455 10.36782646179199 6.118450164794922 C 10.33489322662354 6.045522212982178 10.22191619873047 5.889017105102539 10.19178867340088 5.847151279449463 C 10.09735679626465 5.715837955474854 10.16831207275391 5.620937824249268 10.16831207275391 5.620937824249268 C 10.2446174621582 5.563332557678223 10.335205078125 5.849955558776855 10.40828990936279 5.822529792785645 C 10.4422082901001 5.809751033782959 10.26819801330566 5.510714054107666 10.36164474487305 5.436590671539307 C 10.38122844696045 5.421112537384033 10.45088386535645 5.68093204498291 10.46786880493164 5.669608116149902 C 10.54412174224854 5.618599891662598 10.47212791442871 5.260087966918945 10.53155136108398 5.313329219818115 C 10.58692264556885 5.362987518310547 10.63943767547607 5.523751735687256 10.65694141387939 5.673816204071045 C 10.67694091796875 5.846579074859619 10.64016437530518 5.988695621490479 10.65689086914063 5.975294589996338 Z M 11.72562313079834 9.926723480224609 C 11.68188667297363 9.712352752685547 11.60391998291016 9.926307678222656 11.55140399932861 9.680356979370117 C 11.49873352050781 9.434405326843262 11.35526657104492 9.597662925720215 11.49873352050781 9.434405326843262 C 11.54958629608154 9.376487731933594 11.70297527313232 9.414770126342773 11.77309894561768 9.55823802947998 C 11.8432731628418 9.701757431030273 11.94066715240479 10.06759452819824 11.78286361694336 10.31499862670898 C 11.62490367889404 10.56245708465576 11.76920223236084 10.14104175567627 11.72562122344971 9.926723480224609 Z M 11.32997035980225 10.09626579284668 C 11.32997035980225 10.09626579284668 11.47832107543945 10.05891895294189 11.55504131317139 10.18986797332764 C 11.6602783203125 10.36948585510254 11.65014934539795 10.5394983291626 11.56002712249756 10.57461166381836 C 11.46985530853271 10.6097240447998 11.43702602386475 10.53482151031494 11.44814109802246 10.39405727386475 C 11.46289253234863 10.20654106140137 11.32997035980225 10.09626579284668 11.32997035980225 10.09626579284668 Z M 11.6034517288208 9.220709800720215 C 11.50569343566895 9.217697143554688 11.5386791229248 9.140872955322266 11.51660346984863 9.085968971252441 C 11.49478721618652 9.030961036682129 11.39988708496094 9.000834465026855 11.38269329071045 8.943124771118164 C 11.36648750305176 8.888792991638184 11.37973117828369 8.822565078735352 11.43214225769043 8.791451454162598 C 11.48356628417969 8.760959625244141 11.54589939117432 8.711821556091309 11.66967868804932 8.76547908782959 C 11.79356288909912 8.819085121154785 11.81215858459473 8.941982269287109 11.80473232269287 9.018547058105469 C 11.79720020294189 9.095060348510742 11.70110607147217 9.223723411560059 11.6034517288208 9.220709800720215 Z M 11.42606639862061 8.537811279296875 C 11.19361972808838 8.512515068054199 11.39193916320801 8.526955604553223 11.4245080947876 8.407641410827637 C 11.45681571960449 8.288275718688965 11.38258838653564 8.340998649597168 11.31121921539307 8.248124122619629 C 11.23990058898926 8.155145645141602 11.2202672958374 7.963838577270508 11.41858673095703 7.953657150268555 C 11.54298973083496 7.947268486022949 11.64734554290771 8.06040096282959 11.69965076446533 8.234203338623047 C 11.7234411239624 8.313104629516602 11.65856456756592 8.563108444213867 11.42606639862061 8.537811279296875 Z M 10.40491390228271 15.63476848602295 C 10.45882987976074 15.91043090820313 10.52116298675537 16.26021766662598 10.7201566696167 16.75591087341309 C 10.77817726135254 16.90072822570801 10.7542839050293 17.19722175598145 10.79002094268799 17.33206558227539 C 10.83079719543457 17.48659706115723 10.70005512237549 17.44301605224609 10.69589900970459 17.55630493164063 C 10.69039440155029 17.70590209960938 10.65289115905762 17.9023494720459 10.74077987670898 17.96904563903809 C 10.81375885009766 18.02441787719727 11.03836154937744 18.07064819335938 11.0897331237793 18.24767112731934 C 11.1173677444458 18.34262275695801 11.06947708129883 18.42495155334473 11.05098438262939 18.46541595458984 C 11.02288246154785 18.52655410766602 11.03036308288574 18.65625762939453 11.05015277862549 18.69256401062012 C 11.0912914276123 18.76725769042969 11.10853672027588 18.66955375671387 11.15097427368164 18.59792137145996 C 11.1981897354126 18.51819038391113 11.33625602722168 18.61127281188965 11.37620067596436 18.68233108520508 C 11.40144443511963 18.72731399536133 11.4381160736084 18.9279727935791 11.43302631378174 19.00225067138672 C 11.42731285095215 19.08696937561035 11.37806987762451 19.08322906494141 11.3433198928833 19.06198310852051 C 11.29698657989502 19.03357124328613 11.39245796203613 18.822265625 11.32025623321533 18.7515697479248 C 11.28732395172119 18.71926116943359 11.21683788299561 18.68970680236816 11.15834903717041 18.72341728210449 C 11.06781196594238 18.77572250366211 11.26654720306396 19.02032470703125 11.1770486831665 19.04312896728516 C 11.14614200592041 19.05107498168945 11.08168125152588 19.08073425292969 11.04236030578613 19.03351974487305 C 11.0150899887085 19.00063896179199 11.03482818603516 18.85223770141602 11.00667476654053 18.8319263458252 C 10.98143100738525 18.81353759765625 10.91208648681641 18.79234504699707 10.89510059356689 18.92111396789551 C 10.87655735015869 19.0621395111084 10.85811710357666 18.96386337280273 10.86112976074219 18.82221412658691 C 10.86455821990967 18.6570873260498 10.93764209747314 18.57667922973633 10.85302639007568 18.47621917724609 C 10.82300281524658 18.4404296875 10.7627477645874 18.40573310852051 10.70483207702637 18.25909805297852 C 10.66270542144775 18.15240478515625 10.74758243560791 18.06508827209473 10.55466365814209 18.03366470336914 C 10.49368286132813 18.02363777160645 10.28102684020996 17.97584915161133 10.3090238571167 17.86235427856445 C 10.32575035095215 17.79420471191406 10.35244846343994 17.71899032592773 10.25500392913818 17.62409019470215 C 10.19355392456055 17.56435585021973 10.32969760894775 17.37081527709961 10.24996566772461 17.23918914794922 C 10.16098499298096 17.09208679199219 9.997831344604492 16.77331161499023 10.0017261505127 16.42690086364746 C 10.00692176818848 15.95681381225586 9.953835487365723 15.35328483581543 9.953835487365723 15.35328483581543 C 9.918929100036621 15.36715316772461 9.882413864135742 15.72296619415283 9.810834884643555 16.11794281005859 C 9.709493637084961 16.67763137817383 9.561612129211426 17.25326728820801 9.603945732116699 17.37720489501953 C 9.611632347106934 17.39974784851074 9.636928558349609 17.51651573181152 9.626696586608887 17.6064281463623 C 9.617242813110352 17.68917465209961 9.519901275634766 17.87076759338379 9.502241134643555 17.9178295135498 C 9.459855079650879 18.03111839294434 9.429831504821777 18.27093887329102 9.471750259399414 18.3385181427002 C 9.502241134643555 18.3878116607666 9.338047027587891 18.41606903076172 9.329581260681152 18.25192832946777 C 9.323866844177246 18.13994026184082 9.359240531921387 17.95252799987793 9.417313575744629 17.84469413757324 C 9.449413299560547 17.78511428833008 9.537613868713379 17.69868087768555 9.55039119720459 17.63603973388672 C 9.570388793945313 17.53760719299316 9.48016357421875 17.36941146850586 9.462555885314941 17.33897399902344 C 9.409521102905273 17.24786567687988 9.444064140319824 17.06159782409668 9.466763496398926 16.95651626586914 C 9.552313804626465 16.56242179870605 9.761748313903809 15.21781730651855 9.797797203063965 15.10458087921143 C 9.835923194885254 14.98505878448486 9.83348274230957 13.47330284118652 9.828235626220703 13.28651428222656 C 9.82293701171875 13.0996732711792 9.643681526184082 12.7391881942749 9.776188850402832 12.72132015228271 C 10.09683513641357 12.67799949645996 10.08883476257324 12.65182018280029 10.15054416656494 12.59873294830322 C 10.22892665863037 12.53125953674316 10.44038867950439 12.23606586456299 10.52998924255371 12.23528671264648 C 10.695481300354 12.23383235931396 10.81598949432373 12.29393100738525 10.80575752258301 12.3622350692749 C 10.76274681091309 12.64823532104492 11.0375804901123 12.8834342956543 10.8868408203125 13.4887809753418 C 10.7710075378418 13.95419311523438 10.81515884399414 14.07787132263184 10.64104557037354 14.61813259124756 C 10.46771049499512 15.15558910369873 10.35343551635742 15.37125778198242 10.40491104125977 15.634765625 Z M 10.87967491149902 17.69993019104004 C 10.93057823181152 17.65749168395996 10.94891548156738 17.78288078308105 10.98132705688477 17.81882667541504 C 11.03934860229492 17.88318634033203 11.12578296661377 17.96556854248047 11.09622669219971 17.97865676879883 C 11.06661891937256 17.99174499511719 10.97031688690186 17.96863174438477 10.92632102966309 17.93341445922852 C 10.86793613433838 17.88681983947754 10.84170532226563 17.73161315917969 10.87967491149902 17.69993019104004 Z M 10.80788898468018 19.43758583068848 C 10.781813621521 19.39826774597168 10.56328773498535 19.21573638916016 10.61206245422363 19.21583938598633 C 10.72898769378662 19.21625518798828 10.82419872283936 19.18093299865723 10.9527063369751 19.31354713439941 C 11.0037670135498 19.36637115478516 11.0864086151123 19.47405052185059 11.11461448669434 19.59175300598145 C 11.12973022460938 19.65507125854492 11.08131790161133 19.65507125854492 10.98797607421875 19.65507125854492 C 10.89660835266113 19.65507125854492 10.80414867401123 19.6766300201416 10.82238101959229 19.59814262390137 C 10.83240509033203 19.55450820922852 10.83380889892578 19.47685623168945 10.80788803100586 19.43758583068848 Z M 10.3627872467041 19.38673400878906 C 10.26180839538574 19.31094741821289 10.14114475250244 19.19521903991699 10.19490623474121 19.18841552734375 C 10.26186275482178 19.1799488067627 10.34294414520264 19.18717002868652 10.38922595977783 19.21173858642578 C 10.45010471343994 19.24415016174316 10.5629243850708 19.34715461730957 10.59393501281738 19.41068077087402 C 10.62151622772217 19.46703720092773 10.72815608978271 19.65502166748047 10.65673446655273 19.65502166748047 C 10.52204513549805 19.65502166748047 10.41499042510986 19.66156768798828 10.39441967010498 19.59149551391602 C 10.37561702728271 19.5283317565918 10.40626335144043 19.41940879821777 10.3627872467041 19.3867359161377 Z M 9.765958786010742 18.91794586181641 C 9.80600643157959 19.02635192871094 9.715054512023926 19.10556602478027 9.645034790039063 19.06047821044922 C 9.596310615539551 19.02905082702637 9.57148265838623 18.62399864196777 9.677809715270996 18.52644920349121 C 9.764140129089355 18.44723701477051 9.707834243774414 18.33342742919922 9.641345977783203 18.33431053161621 C 9.590182304382324 18.33498573303223 9.590129852294922 18.08217811584473 9.697756767272949 18.08503341674805 C 9.777853965759277 18.08726692199707 9.875350952148438 18.42458724975586 9.890257835388184 18.2945728302002 C 9.901581764221191 18.19546508789063 9.827250480651855 18.01683044433594 9.795564651489258 17.88640403747559 C 9.760244369506836 17.74085807800293 9.759515762329102 17.55562782287598 9.791929244995117 17.56222534179688 C 9.838261604309082 17.57162857055664 9.85612964630127 17.32079124450684 9.80927848815918 17.30448341369629 C 9.742062568664551 17.28100395202637 9.769229888916016 16.80847549438477 9.793487548828125 16.7855167388916 C 9.817900657653809 16.76245498657227 9.840963363647461 16.43064117431641 9.899971008300781 16.42845916748047 C 9.963601112365723 16.42596817016602 9.998403549194336 16.81356620788574 9.974041938781738 16.90311813354492 C 9.959081649780273 16.95802116394043 10.007493019104 16.9929256439209 10.03585433959961 17.08917999267578 C 10.05304718017578 17.14740562438965 10.00629901885986 17.30661201477051 10.05657958984375 17.37777328491211 C 10.151686668396 17.51241111755371 10.04421710968018 17.63338661193848 10.05798244476318 17.81513786315918 C 10.07164287567139 17.99694061279297 9.93648624420166 17.95263290405273 10.02463436126709 18.19785690307617 C 10.04785346984863 18.26231956481934 10.05195617675781 18.35113906860352 10.08675956726074 18.40724182128906 C 10.12140560150146 18.46344184875488 10.17506217956543 18.3839168548584 10.19194412231445 18.31125068664551 C 10.20082664489746 18.27286148071289 10.25266647338867 18.13531684875488 10.30632305145264 18.06524658203125 C 10.33270931243896 18.03059959411621 10.41691112518311 18.0737133026123 10.4508810043335 18.10384178161621 C 10.50651264190674 18.15282440185547 10.51653861999512 18.22445297241211 10.4760217666626 18.30231666564941 C 10.44708919525146 18.35826110839844 10.38948440551758 18.3925952911377 10.34507274627686 18.45913505554199 C 10.30066204071045 18.5255184173584 10.48931884765625 18.46827507019043 10.6016206741333 18.4833927154541 C 10.6712760925293 18.49279403686523 10.73106288909912 18.53544044494629 10.7662296295166 18.62571716308594 C 10.78409671783447 18.67163276672363 10.78960418701172 18.7653923034668 10.78570747375488 18.79328536987305 C 10.77074813842773 18.89888572692871 10.73521900177002 19.00874710083008 10.70550632476807 19.04328727722168 C 10.65896606445313 19.0975170135498 10.57959651947021 19.06011772155762 10.56754493713379 19.01918601989746 C 10.54635238647461 18.94703674316406 10.67060089111328 18.85047721862793 10.66862678527832 18.74181175231934 C 10.66815853118896 18.71012687683105 10.66306972503662 18.64561080932617 10.60494422912598 18.61730194091797 C 10.53975582122803 18.58551216125488 10.43431091308594 18.60582160949707 10.38714694976807 18.65179252624512 C 10.33993053436279 18.69771194458008 10.32891845703125 18.7742748260498 10.37229061126709 18.81759452819824 C 10.41571617126465 18.86091613769531 10.45872497558594 18.9014835357666 10.47186756134033 18.9606990814209 C 10.4962797164917 19.07170295715332 10.40828895568848 19.08338928222656 10.2978048324585 19.05892372131348 C 10.26279544830322 19.05118370056152 10.21744823455811 18.89239311218262 10.22679805755615 18.73453903198242 C 10.2361478805542 18.57668304443359 10.12374210357666 18.63423728942871 10.053879737854 18.49887084960938 C 10.01881694793701 18.4307746887207 9.941058158874512 18.48147201538086 10.01315498352051 18.55346488952637 C 10.07372188568115 18.61397933959961 10.08784961700439 18.71365737915039 10.08914756774902 18.81416702270508 C 10.09044647216797 18.91473197937012 10.03221893310547 18.96817970275879 9.961367607116699 18.99093246459961 C 9.933733940124512 18.99971008300781 9.945265769958496 18.87125396728516 9.932953834533691 18.75900459289551 C 9.92064380645752 18.64685821533203 9.811563491821289 18.60068130493164 9.762373924255371 18.64987182617188 C 9.674849510192871 18.73734283447266 9.754166603088379 18.88611030578613 9.765956878662109 18.91795349121094 Z M 10.54848384857178 18.90386962890625 C 10.53149890899658 18.91446685791016 10.49108600616455 18.87410736083984 10.47404956817627 18.81250190734863 C 10.45701217651367 18.75089836120605 10.45706462860107 18.68087768554688 10.50594329833984 18.68087768554688 C 10.54199123382568 18.68087768554688 10.56967735290527 18.71910858154297 10.56759929656982 18.76367378234863 C 10.56541728973389 18.80829429626465 10.56541728973389 18.89327239990234 10.54848384857178 18.90386962890625 Z M 9.811615943908691 18.70632934570313 C 9.829692840576172 18.70632934570313 9.866883277893066 18.7828426361084 9.85197639465332 18.86345672607422 C 9.83717155456543 18.94417762756348 9.832808494567871 18.96116256713867 9.811615943908691 18.86345672607422 C 9.790423393249512 18.76585578918457 9.764919281005859 18.70632934570313 9.811615943908691 18.70632934570313 Z M 9.897010803222656 19.22602272033691 C 9.994196891784668 19.22602272033691 10.05257987976074 19.24544906616211 10.11366653442383 19.2933406829834 C 10.30076694488525 19.43982124328613 10.23910999298096 19.5307731628418 10.19220447540283 19.48132133483887 C 10.10265350341797 19.38709831237793 9.970977783203125 19.30299949645996 9.858364105224609 19.30507850646973 C 9.815615653991699 19.30591011047363 9.828600883483887 19.22602081298828 9.897010803222656 19.22602081298828 Z M 11.1138334274292 19.22129440307617 C 11.20878601074219 19.21184158325195 11.27610397338867 19.2282543182373 11.33615112304688 19.25240898132324 C 11.41479396820068 19.28414535522461 11.58916664123535 19.54069328308105 11.59477710723877 19.57492637634277 C 11.61015319824219 19.67034530639648 11.43785572052002 19.64380264282227 11.37864112854004 19.64162063598633 C 11.24057483673096 19.63668632507324 11.35838317871094 19.43945693969727 11.1772575378418 19.30856132507324 C 11.138352394104 19.2805118560791 11.04973697662354 19.22753143310547 11.11383533477783 19.2212963104248 Z M 11.2321081161499 18.88335227966309 C 11.23782157897949 18.83244705200195 11.24067878723145 18.80491638183594 11.26607990264893 18.79317855834961 C 11.2888822555542 18.78273773193359 11.31973743438721 18.8767032623291 11.29708957672119 18.90553283691406 C 11.27464962005615 18.93430709838867 11.22650051116943 18.93430709838867 11.2321081161499 18.88335227966309 Z M 9.187360763549805 18.47398567199707 C 9.308025360107422 18.61044311523438 9.261484146118164 18.9554500579834 9.151726722717285 19.00863838195801 C 9.042076110839844 19.06193161010742 8.393147468566895 19.03014183044434 8.175142288208008 19.02536392211914 C 8.056192398071289 19.02276802062988 8.181167602539063 18.83867835998535 8.118887901306152 18.73983001708984 C 8.090371131896973 18.69453430175781 7.964980125427246 18.53849792480469 8.006897926330566 18.4891529083252 C 8.048764228820801 18.43980407714844 8.129277229309082 18.24922752380371 7.99183464050293 18.10929298400879 C 7.929970741271973 18.04633712768555 7.971992015838623 17.64502334594727 7.985134124755859 17.59126472473145 C 8.001964569091797 17.52248954772949 8.007833480834961 17.24267196655273 7.946904182434082 17.13306999206543 C 7.886078357696533 17.02346992492676 7.890961647033691 16.16552352905273 8.124290466308594 15.73641872406006 C 8.234930038452148 15.53295707702637 7.961344242095947 13.8720703125 8.13021183013916 13.67006397247314 C 8.16787052154541 13.62518310546875 8.111148834228516 13.48852157592773 8.195816040039063 13.47049617767334 C 8.267705917358398 13.45512199401855 8.336946487426758 13.58430576324463 8.411640167236328 13.52223300933838 C 8.521240234375 13.43102073669434 8.620088577270508 13.4515905380249 8.679926872253418 13.4619779586792 C 8.770671844482422 13.47781944274902 8.821056365966797 13.57287788391113 8.869987487792969 13.5851879119873 C 8.905049324035645 13.59391498565674 9.001923561096191 13.47938060760498 9.03662109375 13.53843879699707 C 9.071268081665039 13.59744644165039 9.085811614990234 15.07699775695801 9.067995071411133 15.14810943603516 C 9.050126075744629 15.21895980834961 9.246420860290527 16.23138809204102 9.348125457763672 16.45251083374023 C 9.423910140991211 16.61711883544922 9.353527069091797 16.86867904663086 9.353527069091797 16.86867904663086 C 9.353527069091797 16.86867904663086 9.333945274353027 16.97121429443359 9.3309326171875 17.09821510314941 C 9.328854560852051 17.1818962097168 9.340489387512207 17.40442085266113 9.277379035949707 17.52674865722656 C 9.22730541229248 17.623779296875 9.158533096313477 17.84490203857422 9.070799827575684 18.01080894470215 C 9.030180931091309 18.08784103393555 9.066644668579102 18.33742713928223 9.187360763549805 18.47398567199707 Z M 7.783177375793457 18.70664024353027 C 7.761672973632813 18.65776062011719 7.597065448760986 18.55782318115234 7.533434391021729 18.72024917602539 C 7.50564432144165 18.79104995727539 7.52247428894043 18.88703727722168 7.536550998687744 18.92054176330566 C 7.554990291595459 18.96479606628418 7.649320125579834 19.01923370361328 7.664798736572266 19.09844779968262 C 7.672174453735352 19.13579368591309 7.512188911437988 19.11579513549805 7.480711460113525 19.0440616607666 C 7.45905065536499 18.99450874328613 7.466842651367188 18.9283332824707 7.456713199615479 18.89773750305176 C 7.411107063293457 18.75998497009277 7.455051422119141 18.62166213989258 7.470322132110596 18.58742904663086 C 7.512188911437988 18.49325752258301 7.609737873077393 18.49637222290039 7.638981819152832 18.49606323242188 C 7.725259304046631 18.49528121948242 7.801616191864014 18.56686019897461 7.822860717773438 18.60015678405762 C 7.865297794342041 18.6663818359375 7.869453907012939 18.75853157043457 7.853506565093994 18.82267951965332 C 7.844052791595459 18.8609619140625 7.885918617248535 18.93425559997559 7.885918617248535 18.97959899902344 C 7.885918617248535 19.0440616607666 7.814393043518066 19.04053115844727 7.803796768188477 19.0440616607666 C 7.788629055023193 19.04899597167969 7.725259304046631 19.03902435302734 7.744321823120117 18.96479606628418 C 7.753100395202637 18.93098258972168 7.769046306610107 18.87337684631348 7.781720638275146 18.8345775604248 C 7.795485973358154 18.79255485534668 7.795693397521973 18.73489570617676 7.783174991607666 18.70663833618164 Z M 7.693367958068848 18.85509300231934 C 7.676382541656494 18.90319442749023 7.605583190917969 18.89467430114746 7.588545799255371 18.85509300231934 C 7.571560382843018 18.81546211242676 7.540446758270264 18.73910522460938 7.63389253616333 18.73053550720215 C 7.676849365234375 18.72658538818359 7.710300922393799 18.80699348449707 7.693367958068848 18.85509300231934 Z M 6.858172416687012 19.12332916259766 C 6.943047523498535 19.11673164367676 7.142717361450195 19.09346008300781 7.096019744873047 19.12706756591797 C 7.049271106719971 19.16072845458984 6.944397449493408 19.22446250915527 6.887883186340332 19.30788230895996 C 6.860249519348145 19.34871101379395 6.888454437255859 19.46028327941895 6.856820583343506 19.49196815490723 C 6.831472396850586 19.51737022399902 6.72914457321167 19.52168083190918 6.632270336151123 19.50469589233398 C 6.535447597503662 19.48771095275879 6.793761253356934 19.12826156616211 6.858171463012695 19.12332725524902 Z M 6.796670913696289 18.70461463928223 C 6.878377437591553 18.72201538085938 6.883780002593994 18.79837226867676 6.879105091094971 18.85275650024414 C 6.87385892868042 18.91290664672852 6.864612579345703 18.96033096313477 6.829759120941162 18.96459007263184 C 6.796671867370605 18.96864318847656 6.768154144287109 18.90714263916016 6.765921115875244 18.85275650024414 C 6.763687133789063 18.79837226867676 6.767322540283203 18.6983814239502 6.796670913696289 18.70461463928223 Z M 7.308363914489746 19.09844970703125 C 7.359320640563965 19.09777450561523 7.499359607696533 19.1524715423584 7.378798961639404 19.2315788269043 C 7.258239269256592 19.31068992614746 7.187232494354248 19.42402839660645 7.149210453033447 19.49612426757813 C 7.130614280700684 19.5312385559082 7.028961181640625 19.53248596191406 7.028961181640625 19.42496109008789 C 7.029013156890869 19.25625038146973 7.263017654418945 19.0992259979248 7.308363914489746 19.09844779968262 Z M 7.37048864364624 18.54192924499512 C 7.332258224487305 18.53818893432617 7.370176315307617 18.57169151306152 7.367372035980225 18.63121795654297 C 7.364099025726318 18.70144462585449 7.352827548980713 19.02313232421875 7.30405330657959 19.03907585144043 C 7.223644733428955 19.06530952453613 7.247123718261719 18.92957878112793 7.282756328582764 18.84278297424316 C 7.333713054656982 18.7187442779541 7.231591701507568 18.63729667663574 7.209516048431396 18.57382202148438 C 7.187491893768311 18.51039695739746 7.194140434265137 18.37295532226563 7.154716491699219 18.27639198303223 C 7.115239143371582 18.1800365447998 7.071918487548828 18.11261558532715 7.050622463226318 18.10866928100586 C 7.029325485229492 18.1047191619873 6.984965324401855 18.28782081604004 6.917751312255859 18.34402465820313 C 6.850536823272705 18.4000186920166 6.804099559783936 18.42593765258789 6.79599666595459 18.4558048248291 C 6.787892818450928 18.48577690124512 6.778439998626709 18.52831840515137 6.830226898193359 18.53200721740723 C 6.88191032409668 18.53548622131348 6.984030723571777 18.5513801574707 7.016443729400635 18.57870292663574 C 7.098982334136963 18.64825439453125 7.108435153961182 18.74476623535156 7.102877616882324 18.80403327941895 C 7.091657161712646 18.92324256896973 7.000964641571045 19.02910423278809 6.968500137329102 19.03902435302734 C 6.896559238433838 19.06120491027832 6.976083755493164 18.79364585876465 6.979824066162109 18.75894737243652 C 6.983615398406982 18.72419738769531 6.92938756942749 18.66191482543945 6.877494812011719 18.63319206237793 C 6.837291240692139 18.61090850830078 6.773661136627197 18.62062072753906 6.703901290893555 18.6555290222168 C 6.665359497070313 18.67485046386719 6.634245872497559 18.74767303466797 6.655749797821045 18.78039741516113 C 6.718549251556396 18.87597465515137 6.713250637054443 18.98297691345215 6.702342987060547 19.00780487060547 C 6.668216705322266 19.08561706542969 6.50797176361084 19.12327575683594 6.508179187774658 18.86730003356934 C 6.508334636688232 18.75229835510254 6.555083751678467 18.63620376586914 6.610715389251709 18.62062072753906 C 6.674190044403076 18.60280609130859 6.610715389251709 18.33857154846191 6.668787956237793 18.14752388000488 C 6.693668842315674 18.06571006774902 6.716316223144531 17.87726211547852 6.873392105102539 17.87528800964355 C 6.925542831420898 17.87456130981445 6.993225574493408 17.94795608520508 7.052649021148682 17.94302177429199 C 7.112020015716553 17.93798446655273 7.028391361236572 17.70969200134277 7.0791916847229 17.70054817199707 C 7.130095958709717 17.69140815734863 7.174559593200684 17.51677513122559 7.22961950302124 17.50326919555664 C 7.284678936004639 17.48981475830078 7.298703670501709 17.59152030944824 7.32041597366333 17.62949180603027 C 7.342128276824951 17.66746139526367 7.342232227325439 18.00363731384277 7.325662136077881 18.03324508666992 C 7.309040069580078 18.06280136108398 7.309715747833252 18.1137580871582 7.364880084991455 18.1130313873291 C 7.420095443725586 18.11235618591309 7.529695987701416 18.04722023010254 7.463416576385498 18.17967414855957 C 7.434951305389404 18.23670768737793 7.400720596313477 18.26158905029297 7.397085189819336 18.30179405212402 C 7.393344879150391 18.34199714660645 7.419680118560791 18.40542030334473 7.461753845214844 18.37939643859863 C 7.503828525543213 18.35337448120117 7.538785934448242 18.25473213195801 7.577120304107666 18.23769569396973 C 7.646412372589111 18.2070484161377 7.718873500823975 18.22356605529785 7.724015712738037 18.29753494262695 C 7.729261875152588 18.37165832519531 7.717003345489502 18.40999221801758 7.649113178253174 18.41518592834473 C 7.581223011016846 18.42022514343262 7.487673282623291 18.40859031677246 7.475362777709961 18.4470272064209 C 7.463156223297119 18.48557090759277 7.408823013305664 18.54566955566406 7.370489597320557 18.54192924499512 Z M 6.492386817932129 18.28496551513672 C 6.504749774932861 18.33181762695313 6.473791599273682 18.41264152526855 6.456909656524658 18.50271034240723 C 6.444131851196289 18.5711727142334 6.442054271697998 18.67007064819336 6.422108173370361 18.74118232727051 C 6.392967700958252 18.84532928466797 6.344193458557129 18.89426040649414 6.365230560302734 18.95550155639648 C 6.419458389282227 19.11335754394531 6.149302005767822 19.09024047851563 6.125667572021484 19.00972938537598 C 6.106293201446533 18.94371032714844 6.163690090179443 18.81655311584473 6.245812892913818 18.82122802734375 C 6.265914916992188 18.82232093811035 6.332921981811523 18.76762390136719 6.288406372070313 18.60685729980469 C 6.273082733154297 18.55164337158203 6.344193458557129 18.46676635742188 6.362165927886963 18.40209770202637 C 6.381176948547363 18.33389663696289 6.346426963806152 18.287353515625 6.29983377456665 18.28751182556152 C 6.209244728088379 18.28792572021484 6.049622535705566 18.32189750671387 6.079750061035156 18.23156929016113 C 6.11247444152832 18.13350105285645 6.101774215698242 18.02093887329102 6.131433963775635 17.95917892456055 C 6.152107715606689 17.91611862182617 6.198389053344727 17.88406944274902 6.266642570495605 17.93850517272949 C 6.330480098724365 17.98935699462891 6.437639236450195 17.94780158996582 6.498101234436035 17.84729194641113 C 6.584274768829346 17.7039794921875 6.71673059463501 16.91111946105957 6.632634162902832 16.97781181335449 C 6.580483436584473 17.01921081542969 6.590508937835693 17.31908226013184 6.549576759338379 17.46795082092285 C 6.538253307342529 17.50934791564941 6.501114368438721 17.58674240112305 6.450106143951416 17.64502334594727 C 6.318066120147705 17.79648971557617 6.21719217300415 17.80194473266602 6.178182601928711 17.77347946166992 C 6.105774402618408 17.72049903869629 6.208258152008057 17.41813659667969 6.25131893157959 17.41668128967285 C 6.3845534324646 17.41231918334961 6.338998794555664 17.60175514221191 6.368450164794922 17.60009384155273 C 6.433587074279785 17.59661483764648 6.436860084533691 17.346923828125 6.406628608703613 17.23462104797363 C 6.403408527374268 17.22308921813965 6.386163234710693 17.08964729309082 6.385436058044434 17.04331207275391 C 6.381280422210693 16.78458404541016 6.423355102539063 16.18536758422852 6.408291339874268 16.15638160705566 C 6.385072708129883 16.1113452911377 6.438210010528564 14.96687984466553 6.38076114654541 14.8996639251709 C 6.323312282562256 14.83244895935059 6.162391662597656 13.79078006744385 6.182598114013672 13.61225032806396 C 6.197037696838379 13.48504161834717 6.135329246520996 13.36131191253662 6.09990406036377 13.20735263824463 C 6.034871101379395 12.92483329772949 6.075231075286865 12.61312103271484 6.235112190246582 12.49500274658203 C 6.285132884979248 12.4580192565918 6.69719934463501 12.42674922943115 6.877754211425781 12.59852504730225 C 6.991509914398193 12.7067232131958 7.245148181915283 12.93028545379639 7.267484664916992 13.04809379577637 C 7.289872169494629 13.16605663299561 7.346957683563232 13.52534770965576 7.271015644073486 13.78683185577393 C 7.258342266082764 13.83056831359863 7.205827713012695 13.91840267181396 7.202035427093506 14.03402900695801 C 7.193932056427002 14.28330516815186 7.162662506103516 14.68384075164795 7.219332695007324 15.04453277587891 C 7.232110500335693 15.12618827819824 7.23912239074707 15.20519351959229 7.243537425994873 15.27349853515625 C 7.251744747161865 15.40309810638428 7.391939640045166 15.85630321502686 7.45588207244873 15.93338680267334 C 7.597115516662598 16.1033992767334 7.592025279998779 16.37605094909668 7.555613040924072 16.40352630615234 C 7.492501735687256 16.45110702514648 7.478217601776123 16.1939868927002 7.418898105621338 16.15326499938965 C 7.37079906463623 16.12027931213379 7.322699069976807 16.12552642822266 7.32991886138916 16.1713924407959 C 7.342229843139648 16.24935913085938 7.455986022949219 16.38877487182617 7.463984966278076 16.6583080291748 C 7.467360973358154 16.76967430114746 7.506941318511963 16.88717079162598 7.538835048675537 17.01188659667969 C 7.584752559661865 17.19088363647461 7.532549381256104 17.4881534576416 7.426532745361328 17.5021800994873 C 7.395990371704102 17.50622940063477 7.324101448059082 17.24729156494141 7.309972286224365 17.13712120056152 C 7.30134916305542 17.07001113891602 7.278546333312988 17.03354644775391 7.25735330581665 16.97126770019531 C 7.23927640914917 16.91818046569824 7.212578773498535 16.8434886932373 7.187229633331299 16.84146118164063 C 7.123391628265381 16.8361644744873 7.301453590393066 17.34203720092773 7.200734615325928 17.43340682983398 C 7.162920475006104 17.46763610839844 7.051969528198242 17.59074401855469 7.028958320617676 17.54726600646973 C 6.989480972290039 17.47257232666016 6.957275867462158 16.92441368103027 6.900607109069824 16.83943367004395 C 6.825497150421143 16.72682189941406 6.931980609893799 17.46903991699219 6.834898948669434 17.62315368652344 C 6.766021728515625 17.7321834564209 6.456647872924805 18.15022468566895 6.492384433746338 18.28496360778809 Z M 5.964020729064941 19.51487731933594 C 5.991862297058105 19.62707710266113 5.932438373565674 19.63429641723633 5.788036346435547 19.63284301757813 C 5.669138431549072 19.63169860839844 5.623740196228027 19.61549186706543 5.62644100189209 19.51742362976074 C 5.627843856811523 19.46589660644531 5.701291561126709 19.32627296447754 5.745598793029785 19.26700592041016 C 5.803152084350586 19.18997383117676 5.843200206756592 19.13735389709473 5.97898006439209 19.12483787536621 C 6.060790538787842 19.11730575561523 6.191271781921387 19.08369827270508 6.191998958587646 19.13865280151367 C 6.19251823425293 19.17693519592285 6.129251480102539 19.21267127990723 6.070244312286377 19.27157592773438 C 6.011600017547607 19.32995796203613 5.949735641479492 19.4569091796875 5.964019775390625 19.51487731933594 Z M 5.93145227432251 18.59033966064453 C 5.885533809661865 18.65454292297363 5.852394104003906 18.79837226867676 5.916129112243652 18.87467765808105 C 5.961267948150635 18.92890548706055 5.993264675140381 19.00261497497559 5.961943626403809 19.0390796661377 C 5.909739971160889 19.09980010986328 5.791673183441162 19.06593132019043 5.737184524536133 19.0047435760498 C 5.69765567779541 18.96033096313477 5.706381797790527 18.65262222290039 5.79920482635498 18.54525184631348 C 5.870367050170898 18.46292304992676 5.968747138977051 18.4665584564209 5.993835926055908 18.46624755859375 C 6.019028186798096 18.46588325500488 6.0773606300354 18.49600982666016 6.157664775848389 18.57195281982422 C 6.306586742401123 18.71261596679688 6.210024356842041 18.83052635192871 6.196674346923828 18.83463096618652 C 6.169559955596924 18.84288787841797 6.230385303497314 18.71261596679688 6.080321788787842 18.5883674621582 C 6.05092191696167 18.56410980224609 5.965734958648682 18.54234504699707 5.931452751159668 18.59033966064453 Z M 6.035286903381348 18.89462471008301 C 6.00604248046875 18.90605163574219 5.95035982131958 18.84735488891602 5.964020729064941 18.79738616943359 C 5.977733612060547 18.74736213684082 5.966098308563232 18.69588851928711 6.000380516052246 18.700927734375 C 6.028689384460449 18.70513534545898 6.055076599121094 18.70830345153809 6.070192337036133 18.75900077819824 C 6.08530855178833 18.8096981048584 6.064530372619629 18.88335418701172 6.035286903381348 18.89462471008301 Z M 5.922622203826904 18.13282203674316 C 5.864705085754395 18.25519943237305 5.647789478302002 18.48390769958496 5.659944534301758 18.54598045349121 C 5.665087223052979 18.57236671447754 5.649296283721924 18.64051818847656 5.652204990386963 18.71261596679688 C 5.660672187805176 18.92334938049316 5.584003448486328 19.05466079711914 5.554136276245117 19.03902626037598 C 5.504322528839111 19.01294898986816 5.609352111816406 18.87285995483398 5.572472095489502 18.71869277954102 C 5.543227672576904 18.59589767456055 5.352595806121826 18.60805320739746 5.316807270050049 18.63797378540039 C 5.227516651153564 18.71261596679688 5.326624870300293 19.06582832336426 5.261280059814453 19.04297637939453 C 5.216712951660156 19.02733993530273 5.134330749511719 18.83218765258789 5.172353267669678 18.71261596679688 C 5.214791297912598 18.57901954650879 5.337117195129395 18.49455833435059 5.505153656005859 18.47258758544922 C 5.646075248718262 18.45424842834473 5.65838623046875 18.37701034545898 5.66264533996582 18.26948738098145 C 5.666905403137207 18.16180801391602 5.71895170211792 17.92630004882813 5.884910583496094 17.89014625549316 C 5.993368148803711 17.86656379699707 5.974409103393555 18.02322387695313 5.922621726989746 18.13282585144043 Z M 5.474403381347656 18.8345775604248 C 5.45798921585083 18.8947811126709 5.435549736022949 18.96121406555176 5.397371768951416 18.92293167114258 C 5.359193325042725 18.8846492767334 5.376646041870117 18.72544479370117 5.427706241607666 18.71261405944824 C 5.521723747253418 18.68928909301758 5.490817546844482 18.77432060241699 5.474403381347656 18.8345775604248 Z M 5.474403381347656 19.1524715423584 C 5.597457408905029 19.14239311218262 5.633557796478271 19.17849349975586 5.629869937896729 19.21760749816895 C 5.625195026397705 19.26716232299805 5.486609935760498 19.33078956604004 5.453470230102539 19.39478492736816 C 5.42033052444458 19.45903968811035 5.456327438354492 19.55788803100586 5.4015793800354 19.59684562683105 C 5.368699073791504 19.62027168273926 5.27940845489502 19.6100902557373 5.138381958007813 19.61886978149414 C 5.02426290512085 19.62598419189453 5.085971832275391 19.49171447753906 5.126227855682373 19.37722969055176 C 5.194324970245361 19.18343162536621 5.363036632537842 19.16161346435547 5.474403381347656 19.1524715423584 Z M 6.029521465301514 10.71386909484863 C 6.084580898284912 10.68410587310791 6.199427127838135 10.89400863647461 6.135121822357178 10.96345615386963 C 6.07138729095459 11.03228092193604 6.174442768096924 11.00199794769287 6.063231945037842 11.16130924224854 C 5.953839302062988 11.31812477111816 5.821435928344727 11.26301383972168 5.775258541107178 11.12364959716797 C 5.746273994445801 11.03612613677979 5.950982570648193 10.75630664825439 6.029520988464355 10.71386909484863 Z M 5.719523906707764 10.60535907745361 C 5.620363712310791 10.65683555603027 5.608884334564209 10.42755699157715 5.64363431930542 10.32502174377441 C 5.684565544128418 10.20451354980469 5.808814525604248 10.07330513000488 5.903766632080078 10.0335168838501 C 5.951138973236084 10.01367378234863 6.124836921691895 10.04286575317383 6.070348262786865 10.14711570739746 C 6.01580810546875 10.25131416320801 5.818631172180176 10.55398750305176 5.719523906707764 10.60535907745361 Z M 8.745686531066895 4.951542377471924 C 8.773113250732422 4.974605560302734 8.828639984130859 5.011796951293945 8.931385040283203 4.961203575134277 C 9.017142295837402 4.919025897979736 9.001247406005859 4.885625839233398 9.135209083557129 4.745483875274658 C 9.242056846618652 4.633701324462891 9.334878921508789 4.655465602874756 9.316646575927734 4.733952045440674 C 9.292440414428711 4.837942600250244 9.14570140838623 5.08498477935791 8.961666107177734 5.0906982421875 C 8.902607917785645 5.092568397521973 8.775241851806641 5.079894065856934 8.763347625732422 5.128253936767578 C 8.751347541809082 5.176924228668213 8.589753150939941 5.221076488494873 8.452206611633301 5.101554393768311 C 8.308169364929199 4.976371288299561 8.158623695373535 4.778207778930664 8.187088966369629 4.646115779876709 C 8.208540916442871 4.546332836151123 8.383018493652344 4.447121143341064 8.517135620117188 4.439485549926758 C 8.616140365600586 4.433824062347412 8.624034881591797 4.325833797454834 8.654733657836914 4.354557991027832 C 8.797369956970215 4.487585067749023 8.896477699279785 4.53287935256958 9.060514450073242 4.524569034576416 C 9.23857593536377 4.515530586242676 9.090434074401855 4.826462745666504 8.877778053283691 4.843344211578369 C 8.687042236328125 4.858460426330566 8.704963684082031 4.917416095733643 8.745685577392578 4.951542377471924 Z M 8.188232421875 5.02353572845459 C 8.236330986022949 5.072570323944092 8.295027732849121 5.17983341217041 8.59801197052002 5.262994766235352 C 8.693068504333496 5.289070129394531 8.98431396484375 5.302055835723877 9.134690284729004 5.189495086669922 C 9.312180519104004 5.056519985198975 9.516525268554688 4.580460071563721 9.652407646179199 4.547060489654541 C 9.761592864990234 4.520205497741699 9.795979499816895 5.229283809661865 9.784292221069336 5.337066173553467 C 9.772449493408203 5.444796085357666 9.524003982543945 5.674125671386719 9.35498046875 5.696721076965332 C 9.253951072692871 5.710226535797119 9.060722351074219 5.70253849029541 9.112457275390625 5.640154838562012 C 9.14570140838623 5.600210666656494 9.272961616516113 5.574394702911377 9.289012908935547 5.506244659423828 C 9.296596527099609 5.474559783935547 9.203046798706055 5.517673015594482 9.117236137390137 5.501778125762939 C 9.018752098083496 5.483441829681396 8.919177055358887 5.442821979522705 8.938915252685547 5.489830493927002 C 8.960783958435059 5.541826248168945 9.020569801330566 5.616520881652832 8.970028877258301 5.651218891143799 C 8.919643402099609 5.685812950134277 8.582220077514648 5.725185871124268 8.528407096862793 5.645556926727295 C 8.491735458374023 5.591276168823242 8.617542266845703 5.47071647644043 8.576766967773438 5.429265022277832 C 8.542743682861328 5.394722461700439 8.501553535461426 5.494921207427979 8.40379524230957 5.530710697174072 C 8.243342399597168 5.589354515075684 8.102992057800293 5.523022651672363 8.137690544128418 5.57917308807373 C 8.172388076782227 5.6353759765625 8.258251190185547 5.622805595397949 8.319595336914063 5.633454322814941 C 8.387640953063965 5.64524507522583 8.428104400634766 5.684098720550537 8.283754348754883 5.699578285217285 C 8.139455795288086 5.715056896209717 7.91874885559082 5.729237079620361 7.81548547744751 5.62296199798584 C 7.712170600891113 5.516685962677002 7.625164985656738 5.355557441711426 7.66251277923584 5.175782203674316 C 7.699859142303467 4.995954513549805 7.720065116882324 4.592511177062988 7.792369842529297 4.592458724975586 C 7.924773693084717 4.592354774475098 8.075461387634277 4.908585548400879 8.188230514526367 5.023535251617432 Z M 10.23365592956543 4.401151657104492 C 10.25427722930908 4.328638553619385 10.33037281036377 4.317782402038574 10.35483837127686 4.283240795135498 C 10.40350914001465 4.214519500732422 10.37333011627197 4.099569320678711 10.42906475067139 4.047521591186523 C 10.45363426208496 4.024510860443115 10.50947380065918 3.993708848953247 10.53830146789551 4.083311080932617 C 10.56328678131104 4.160758495330811 10.51632881164551 4.282876968383789 10.57689476013184 4.375440120697021 C 10.6389684677124 4.470132350921631 10.60292053222656 4.546489238739014 10.58032321929932 4.638740539550781 C 10.5521183013916 4.753690719604492 10.43114280700684 4.774416446685791 10.29359722137451 4.803816318511963 C 10.20882415771484 4.821892261505127 10.10795021057129 4.891132831573486 10.04198265075684 5.059117317199707 C 9.976274490356445 5.227102279663086 9.877218246459961 5.082283973693848 9.880231857299805 5.024471282958984 C 9.88397216796875 4.954035758972168 9.82252311706543 4.807088851928711 9.872076034545898 4.771040439605713 C 9.931240081787109 4.727874755859375 10.012375831604 4.730991363525391 10.18846321105957 4.550384998321533 C 10.2627420425415 4.474236011505127 10.20799350738525 4.491014003753662 10.2336540222168 4.40115213394165 Z M 9.970977783203125 6.357491016387939 C 10.03777599334717 6.263213634490967 9.987961769104004 5.935763359069824 10.03039932250977 5.937061786651611 C 10.06920051574707 5.938256740570068 10.15407657623291 6.041935443878174 10.18493175506592 6.167430400848389 C 10.25552272796631 6.454832553863525 10.04847717285156 6.185454368591309 10.10571765899658 6.312559604644775 C 10.21724128723145 6.560692310333252 10.14275360107422 6.715431690216064 10.08966827392578 6.765765190124512 C 9.974821090698242 6.874586582183838 9.78403377532959 6.990939617156982 9.603426933288574 6.970213890075684 C 9.483230590820313 6.95639705657959 9.508526802062988 6.926114559173584 9.562235832214355 6.874534606933594 C 9.61568546295166 6.822851181030273 9.63584041595459 6.70369291305542 9.617451667785645 6.596326351165771 C 9.599064826965332 6.489011287689209 9.50416374206543 6.375723838806152 9.517513275146484 6.306586742401123 C 9.537874221801758 6.200467109680176 9.731103897094727 6.492959022521973 9.787514686584473 6.480856418609619 C 9.843976974487305 6.468805313110352 9.719832420349121 6.194233417510986 9.787514686584473 6.170703411102295 C 9.85509204864502 6.147120952606201 9.92630672454834 6.420342922210693 9.970977783203125 6.357491493225098 Z M 10.35837078094482 7.18718147277832 C 10.31193351745605 7.098358154296875 10.32258129119873 6.964085102081299 10.46589374542236 6.962215423583984 C 10.65455150604248 6.95982551574707 10.67917346954346 7.127186298370361 10.65179824829102 7.219905853271484 C 10.62935924530029 7.296054363250732 10.56017017364502 7.418120861053467 10.38657569885254 7.402642726898193 C 10.21163082122803 7.387007713317871 10.43960952758789 7.342855453491211 10.35837078094482 7.187181949615479 Z M 10.75532150268555 8.481918334960938 C 10.7094030380249 8.395588874816895 10.7540225982666 8.2293701171875 10.96891212463379 8.252641677856445 C 11.08614730834961 8.265263557434082 11.17512607574463 8.338138580322266 11.19470977783203 8.402029991149902 C 11.24680805206299 8.571261405944824 11.17554187774658 8.695198059082031 11.16437530517578 8.767659187316895 C 11.15237522125244 8.845417976379395 11.02412700653076 9.083733558654785 11.04386615753174 8.82614803314209 C 11.06531715393066 8.545809745788574 10.88149070739746 8.719144821166992 10.75532150268555 8.48192024230957 Z M 9.885167121887207 10.67574310302734 C 9.825069427490234 10.62291622161865 9.823042869567871 10.21038341522217 9.878517150878906 10.16030979156494 C 9.983702659606934 10.06546115875244 10.11704063415527 10.59746360778809 10.29328632354736 10.73267269134521 C 10.46521854400635 10.86455726623535 10.51113510131836 10.95966339111328 10.47186756134033 11.04505825042725 C 10.39737892150879 11.20608425140381 10.27510547637939 11.27646636962891 10.3317756652832 11.04687786102295 C 10.37519931793213 10.87001132965088 9.945369720458984 10.72846412658691 9.885166168212891 10.67574310302734 Z M 9.868597030639648 12.3517951965332 C 9.873739242553711 12.3025016784668 9.991599082946777 12.3535099029541 10.013258934021 12.3722095489502 C 10.05190563201904 12.40571308135986 10.08042144775391 12.49323749542236 9.99102783203125 12.5285587310791 C 9.919086456298828 12.55707550048828 9.861065864562988 12.42410087585449 9.868597984313965 12.3517951965332 Z M 9.820601463317871 11.92347145080566 C 9.850832939147949 11.84773921966553 9.939552307128906 11.92700386047363 9.948589324951172 11.96684551239014 C 9.957575798034668 12.00668430328369 10.01003932952881 12.1267786026001 9.971809387207031 12.12210369110107 C 9.933526992797852 12.11737728118896 9.771257400512695 12.04730415344238 9.820602416992188 11.92347145080566 Z M 9.903711318969727 11.66765117645264 C 9.845743179321289 11.5650110244751 9.870779991149902 11.25132656097412 9.89192008972168 11.19938278198242 C 9.922826766967773 11.12364959716797 9.788396835327148 11.0779390335083 9.757646560668945 10.99841403961182 C 9.731310844421387 10.93057632446289 9.845585823059082 10.92091464996338 9.957107543945313 10.98594760894775 C 10.01684188842773 11.02080154418945 10.08805751800537 11.09611797332764 10.09574508666992 11.19673252105713 C 10.10462760925293 11.31293106079102 10.08109664916992 11.39603900909424 10.11345767974854 11.41208934783936 C 10.1729850769043 11.44174861907959 10.34626865386963 11.73969554901123 10.30829811096191 11.86472320556641 C 10.27027606964111 11.98975086212158 10.21095657348633 12.06127643585205 10.12483406066895 11.96440315246582 C 10.03860855102539 11.86773681640625 9.961628913879395 11.77028942108154 9.903711318969727 11.66765117645264 Z M 8.801007270812988 12.22500133514404 C 8.809682846069336 12.02133274078369 8.718001365661621 11.84067344665527 8.74288272857666 11.81989765167236 C 8.773633003234863 11.79397773742676 8.914658546447754 11.87973499298096 8.964472770690918 11.91354942321777 C 9.029766082763672 11.95785808563232 9.140975952148438 12.01489162445068 9.18195915222168 12.13223075866699 C 9.238005638122559 12.29195690155029 9.051736831665039 12.24188327789307 9.056827545166016 12.29242515563965 C 9.058957099914551 12.31335735321045 9.128768920898438 12.33797836303711 9.21083927154541 12.38571453094482 C 9.253693580627441 12.41069889068604 9.245798110961914 12.52383232116699 9.136404991149902 12.54325866699219 C 8.952733993530273 12.57593154907227 8.798306465148926 12.28681564331055 8.801007270812988 12.22500324249268 Z M 9.007534027099609 13.11941337585449 C 8.955591201782227 13.16756439208984 8.885519027709961 13.18247222900391 8.872481346130371 13.15738487243652 C 8.864377021789551 13.1419563293457 8.913152694702148 12.86083984375 8.98670482635498 12.90431594848633 C 9.013767242431641 12.92021179199219 9.204813957214355 12.93688488006592 9.007534027099609 13.11941337585449 Z M 8.697328567504883 10.38776779174805 C 8.560873985290527 10.31037139892578 8.58533763885498 10.15968608856201 8.624763488769531 10.19339561462402 C 8.780800819396973 10.32730579376221 9.17988109588623 10.54219532012939 9.258834838867188 10.63257598876953 C 9.325011253356934 10.7083101272583 9.296078681945801 10.89592933654785 9.26252269744873 10.92133045196533 C 9.097967147827148 11.04557800292969 8.784022331237793 10.68405246734619 8.73213005065918 10.61922836303711 C 8.680342674255371 10.55435085296631 8.769269943237305 10.42859554290771 8.697328567504883 10.38776874542236 Z M 8.66268253326416 10.91036987304688 C 8.692601203918457 10.893798828125 8.708392143249512 10.9174861907959 8.715300559997559 10.9570140838623 L 8.715248107910156 10.95618343353271 C 8.715248107910156 10.95618343353271 9.193697929382324 11.27324485778809 9.262418746948242 11.33469486236572 C 9.331087112426758 11.39614295959473 9.295351028442383 11.69668579101563 9.233329772949219 11.72011184692383 C 9.171414375305176 11.74359035491943 8.925722122192383 11.57815170288086 8.93018913269043 11.48964023590088 C 8.934657096862793 11.4011812210083 8.992988586425781 11.4019603729248 8.991378784179688 11.33890151977539 C 8.989819526672363 11.27589511871338 8.717585563659668 11.16452789306641 8.74958324432373 11.09211730957031 C 8.78157901763916 11.01970958709717 8.718624114990234 11.05695343017578 8.718624114990234 11.05695343017578 L 8.718624114990234 11.05638122558594 C 8.714988708496094 11.11564922332764 8.704132080078125 11.17387676239014 8.694211959838867 11.19262886047363 C 8.674472808837891 11.22997570037842 8.636815071105957 11.23028945922852 8.505969047546387 11.25449275970459 C 8.350658416748047 11.28332042694092 8.257316589355469 11.56563282012939 8.24625301361084 11.69528388977051 C 8.236175537109375 11.81345462799072 8.307129859924316 11.9684009552002 8.182621955871582 11.91983509063721 C 8.093175888061523 11.88492774963379 7.923632144927979 11.6895694732666 7.939267635345459 11.59300804138184 C 7.955058574676514 11.49655055999756 8.13187313079834 11.49686145782471 8.192647933959961 11.38258647918701 C 8.253473281860352 11.2683629989624 8.171609878540039 11.08199024200439 8.301936149597168 11.07289981842041 C 8.488673210144043 11.05996608734131 8.602947235107422 10.9433012008667 8.66268253326416 10.91036987304688 Z M 9.542082786560059 11.77434158325195 C 9.634697914123535 11.83901119232178 9.676979064941406 11.9717264175415 9.665187835693359 12.05732822418213 C 9.649603843688965 12.16983795166016 9.645552635192871 12.18053722381592 9.430455207824707 12.29668235778809 C 9.393732070922852 12.31652641296387 9.285689353942871 12.32530307769775 9.326932907104492 12.22495079040527 C 9.364436149597168 12.13358116149902 9.342671394348145 11.91557598114014 9.311299324035645 11.79621028900146 C 9.275301933288574 11.6588191986084 9.499591827392578 11.74468231201172 9.542082786560059 11.77434158325195 Z M 9.646799087524414 11.12094783782959 C 9.728455543518066 11.20156383514404 9.698535919189453 11.39229965209961 9.64825439453125 11.40751934051514 C 9.567066192626953 11.43198299407959 9.519798278808594 11.32295513153076 9.519071578979492 11.26628494262695 C 9.518343925476074 11.20961570739746 9.440948486328125 11.15678882598877 9.432119369506836 11.11372756958008 C 9.409523010253906 11.00298404693604 9.572833061218262 11.0479679107666 9.646799087524414 11.12094879150391 Z M 9.365266799926758 12.50289821624756 C 9.409107208251953 12.51681900024414 9.434455871582031 12.61644649505615 9.409834861755371 12.68147945404053 C 9.350411415100098 12.83949089050293 9.216241836547852 12.82702350616455 9.205385208129883 12.79570293426514 C 9.197750091552734 12.77352333068848 9.267302513122559 12.78204154968262 9.261277198791504 12.68340110778809 C 9.250576972961426 12.5073127746582 9.318155288696289 12.4880428314209 9.365266799926758 12.50289821624756 Z M 8.521500587463379 10.52993774414063 C 8.499580383300781 10.6824426651001 8.158572196960449 10.92984867095947 8.097799301147461 10.96111679077148 C 8.03697395324707 10.99238681793213 8.059517860412598 11.15200901031494 8.003522872924805 11.19803142547607 C 7.947475910186768 11.24405288696289 7.850653648376465 11.20000457763672 7.819954872131348 11.01352882385254 C 7.78925609588623 10.82705307006836 7.900518894195557 10.67475414276123 8.069802284240723 10.62764167785645 C 8.207867622375488 10.58925533294678 8.209894180297852 10.52147006988525 8.214515686035156 10.43571090698242 C 8.219139099121094 10.34995269775391 8.31829833984375 10.24585914611816 8.390446662902832 10.24741649627686 C 8.473660469055176 10.24907970428467 8.544822692871094 10.36719799041748 8.521499633789063 10.52993583679199 Z M 8.393045425415039 11.98684215545654 C 8.460517883300781 11.92591190338135 8.576353073120117 11.64225006103516 8.590272903442383 11.68458366394043 C 8.663825035095215 11.90731620788574 8.544822692871094 11.9248743057251 8.507372856140137 12.07223606109619 C 8.472829818725586 12.20863914489746 8.182311058044434 12.33387470245361 8.17259693145752 12.45443534851074 C 8.16283130645752 12.57494354248047 8.172961235046387 12.64678192138672 8.121433258056641 12.68002414703369 C 8.062424659729004 12.71804714202881 7.915217876434326 12.72734546661377 7.917243957519531 12.4165678024292 C 7.919684886932373 12.05203056335449 8.303181648254395 12.06797695159912 8.393045425415039 11.98684215545654 Z M 8.459219932556152 12.73259162902832 C 8.563522338867188 12.69233512878418 8.47947883605957 12.58034515380859 8.532824516296387 12.50923442840576 C 8.563003540039063 12.46903133392334 8.633646965026855 12.45303153991699 8.671513557434082 12.47188758850098 C 8.740649223327637 12.5065336227417 8.776802062988281 12.54788017272949 8.741272926330566 12.66418170928955 C 8.69364070892334 12.82011604309082 8.653280258178711 12.98420333862305 8.516722679138184 13.00929260253906 C 8.434755325317383 13.02425289154053 8.396577835083008 12.75684833526611 8.459221839904785 12.73259162902832 Z M 9.114693641662598 13.17696571350098 C 9.133235931396484 13.00674819946289 9.510916709899902 12.90737915039063 9.550497055053711 12.94389629364014 C 9.620152473449707 13.00804615020752 9.588519096374512 13.2949800491333 9.592155456542969 13.37460899353027 C 9.60716724395752 13.71395397186279 9.730012893676758 13.72392845153809 9.735622406005859 13.79690837860107 C 9.746685981750488 13.94048023223877 9.605401039123535 15.29469203948975 9.516526222229004 15.39826679229736 C 9.40443229675293 15.52885437011719 9.42255973815918 15.2918872833252 9.329425811767578 15.00032997131348 C 9.234993934631348 14.70487689971924 9.171102523803711 14.14778518676758 9.170583724975586 13.88541984558105 C 9.170064926147461 13.57526683807373 9.095733642578125 13.35154628753662 9.114691734313965 13.17696571350098 Z M 9.648825645446777 10.60738372802734 C 9.620984077453613 10.64026355743408 9.587947845458984 10.67818260192871 9.469413757324219 10.70358276367188 C 9.347243309020996 10.72965812683105 9.456168174743652 10.59039783477783 9.460583686828613 10.5178337097168 C 9.464999198913574 10.44526863098145 9.293482780456543 10.25240421295166 9.097344398498535 10.17246341705322 C 9.001249313354492 10.13334941864014 8.927853584289551 10.20014953613281 8.742779731750488 10.00925731658936 C 8.667513847351074 9.93165397644043 8.689434051513672 9.770007133483887 8.566743850708008 9.701545715332031 C 8.472987174987793 9.649187088012695 8.607467651367188 9.569350242614746 8.39112377166748 9.421832084655762 C 8.390708923339844 9.421571731567383 8.390501976013184 9.421208381652832 8.39013671875 9.420896530151367 C 8.385930061340332 9.454192161560059 8.384528160095215 9.489046096801758 8.389617919921875 9.525405883789063 C 8.420784950256348 9.745904922485352 8.297731399536133 9.770110130310059 8.223867416381836 9.844649314880371 C 8.152498245239258 9.916590690612793 7.996771812438965 10.01891803741455 8.015315055847168 10.25224876403809 C 8.02679443359375 10.39638996124268 7.904052257537842 10.4617862701416 7.769779205322266 10.31489086151123 C 7.644855499267578 10.1781759262085 7.792374134063721 9.861373901367188 7.80104923248291 9.770421981811523 C 7.815074443817139 9.623786926269531 7.86296558380127 9.638486862182617 7.982694149017334 9.584517478942871 C 8.072712898254395 9.543898582458496 8.131772041320801 9.404430389404297 8.084659576416016 9.334047317504883 C 8.067933082580566 9.309061050415039 8.020977020263672 9.267040252685547 8.04876708984375 9.221225738525391 C 8.080867767333984 9.168243408203125 8.336116790771484 9.096717834472656 8.419693946838379 9.15962028503418 C 8.479272842407227 9.110898017883301 8.587574005126953 9.0484619140625 8.602118492126465 9.092561721801758 C 8.619831085205078 9.146271705627441 8.615778923034668 9.270572662353516 8.634011268615723 9.372276306152344 C 8.652400016784668 9.473980903625488 8.747871398925781 9.586698532104492 8.841421127319336 9.652717590332031 C 8.936372756958008 9.719725608825684 9.076308250427246 9.697129249572754 9.206113815307617 9.823559761047363 C 9.272029876708984 9.887813568115234 9.232657432556152 10.00728321075439 9.285326957702637 10.06031703948975 C 9.413887977600098 10.18960380554199 9.509567260742188 10.19630432128906 9.629191398620605 10.23952102661133 C 9.758062362670898 10.28611373901367 9.721235275268555 10.52204132080078 9.648826599121094 10.60738372802734 Z M 7.348206043243408 12.36379337310791 C 7.355842113494873 12.46274566650391 7.506113529205322 12.52164840698242 7.350283622741699 12.52450561523438 C 7.169832229614258 12.52777862548828 7.098098754882813 12.39599895477295 7.082152366638184 12.20557403564453 C 7.075088024139404 12.12043857574463 7.254707813262939 11.94056034088135 7.314286231994629 11.87277412414551 C 7.349140644073486 11.83324527740479 7.300624847412109 11.79885768890381 7.336726188659668 11.74675941467285 C 7.365346431732178 11.70567226409912 7.572807788848877 11.54901123046875 7.60490894317627 11.54854393005371 C 7.688122272491455 11.54745388031006 7.693057060241699 11.89568138122559 7.599766731262207 11.93702793121338 C 7.432872772216797 12.01094341278076 7.338907241821289 12.24432563781738 7.348205089569092 12.36379528045654 Z M 6.523190975189209 12.10906410217285 C 6.431718826293945 12.11020660400391 6.325130939483643 11.90061473846436 6.373594284057617 11.70884132385254 C 6.410733699798584 11.56173706054688 6.494778156280518 11.61191368103027 6.5472412109375 11.56225681304932 C 6.591652393341064 11.52018260955811 6.565265655517578 11.46148586273193 6.590925216674805 11.43567180633545 C 6.669671535491943 11.35682106018066 6.730185508728027 11.44704627990723 6.723121166229248 11.47467994689941 C 6.684267044067383 11.62703037261963 6.559915065765381 11.66827297210693 6.527190685272217 11.92206764221191 C 6.51529598236084 12.01338481903076 6.669671058654785 12.1070384979248 6.523190975189209 12.10906410217285 Z M 6.474363803863525 10.74508571624756 C 6.364659786224365 10.71298408508301 6.262020111083984 10.76664066314697 6.263526439666748 10.65662574768066 C 6.265084743499756 10.54660892486572 6.237451076507568 10.37426090240479 6.32804012298584 10.15641117095947 C 6.411097049713135 9.956846237182617 6.494465827941895 9.965934753417969 6.494465827941895 9.965934753417969 C 6.494465827941895 9.965934753417969 6.68800687789917 9.96302604675293 6.592950820922852 10.2817497253418 C 6.557577610015869 10.40049266815186 6.366374015808105 10.49440574645996 6.401591777801514 10.60005855560303 C 6.437017440795898 10.70581531524658 6.609624862670898 10.58369636535645 6.646400451660156 10.69459629058838 C 6.683228015899658 10.80549430847168 6.652997016906738 11.03113651275635 6.598145008087158 11.12271308898926 C 6.495452880859375 11.29402256011963 6.333597660064697 11.39541530609131 6.329079151153564 11.26664733886719 C 6.324559688568115 11.13741207122803 6.226127147674561 11.06926250457764 6.330325603485107 11.00184059143066 C 6.439302444458008 10.93145656585693 6.622194766998291 10.78830051422119 6.474364757537842 10.74508571624756 Z M 6.379307746887207 9.735048294067383 C 6.440029144287109 9.810261726379395 6.135693550109863 9.866205215454102 6.130084037780762 9.47855281829834 C 6.128837585449219 9.38386058807373 6.226387500762939 9.182683944702148 6.312405109405518 9.160504341125488 C 6.470468997955322 9.119832992553711 6.523398876190186 8.919384002685547 6.56708288192749 8.928889274597168 C 6.634193897247314 8.943432807922363 6.729353904724121 9.102535247802734 6.697616100311279 9.170736312866211 C 6.554304122924805 9.478293418884277 6.403876781463623 9.449152946472168 6.379411220550537 9.525873184204102 C 6.354946613311768 9.602644920349121 6.34460973739624 9.69209098815918 6.379307746887207 9.735048294067383 Z M 6.402629852294922 8.478021621704102 C 6.363620758056641 8.513238906860352 6.268564701080322 8.52653694152832 6.29962682723999 8.72911548614502 C 6.310586452484131 8.801056861877441 5.994148254394531 8.68247127532959 6.172365665435791 8.314504623413086 C 6.350530624389648 7.946434497833252 6.615026473999023 7.880673885345459 6.615026473999023 7.880673885345459 C 6.714705944061279 7.862390041351318 6.799996376037598 8.040295600891113 6.827578067779541 8.134469032287598 C 6.855315208435059 8.228693962097168 6.499556064605713 8.390809059143066 6.402629852294922 8.478021621704102 Z M 6.877963066101074 9.762994766235352 C 6.962059497833252 9.696455001831055 6.855211734771729 9.528107643127441 7.046518802642822 9.444218635559082 C 7.192946910858154 9.380068778991699 7.241513252258301 9.254262924194336 7.317766189575195 9.179723739624023 C 7.376513957977295 9.122326850891113 7.522578239440918 9.471489906311035 7.495827674865723 9.590803146362305 C 7.456870079040527 9.763825416564941 7.23616361618042 9.818937301635742 7.124330043792725 9.937472343444824 C 7.057634830474854 10.0081148147583 7.116642475128174 10.09761333465576 7.143548488616943 10.18461799621582 C 7.170506477355957 10.2716236114502 7.040960311889648 10.32990455627441 6.934581279754639 10.19822788238525 C 6.817241191864014 10.05320072174072 6.744624614715576 9.868335723876953 6.877963066101074 9.762994766235352 Z M 6.980395317077637 10.67901420593262 C 7.279484272003174 10.38906669616699 7.308676719665527 10.12545490264893 7.390124320983887 10.18139743804932 C 7.499152660369873 10.25635147094727 7.525955677032471 10.48427772521973 7.512917995452881 10.63486194610596 C 7.499828338623047 10.78539276123047 7.029689788818359 10.94626235961914 7.009847164154053 10.99301147460938 C 6.990679740905762 11.03835678100586 6.871002674102783 10.78497791290283 6.980395317077637 10.67901420593262 Z M 6.952761650085449 11.53436279296875 C 6.989485263824463 11.38949394226074 7.169001579284668 11.36591243743896 7.240786552429199 11.22415828704834 C 7.312572479248047 11.08240413665771 7.173416614532471 10.98283004760742 7.3295578956604 10.97103881835938 C 7.40622615814209 10.96522045135498 7.426223754882813 10.9269905090332 7.456247329711914 10.9196662902832 C 7.520449161529541 10.90408420562744 7.566730976104736 11.00796985626221 7.518579006195068 11.07243156433105 C 7.470376014709473 11.1368932723999 7.525124549865723 11.23688411712646 7.497489452362061 11.29230785369873 C 7.456454753875732 11.37489700317383 7.180480003356934 11.41941261291504 7.175597190856934 11.51228713989258 C 7.170610904693604 11.60511016845703 7.083189487457275 11.62889957427979 7.12157678604126 11.74951267242432 C 7.155131340026855 11.85500907897949 7.176323890686035 11.96471405029297 7.115862369537354 11.92720985412598 C 7.055400848388672 11.88976001739502 6.91312837600708 11.69071197509766 6.952760219573975 11.53436279296875 Z M 7.633218765258789 9.271973609924316 C 7.545642375946045 9.078433036804199 7.56070613861084 8.935900688171387 7.627660751342773 8.839701652526855 C 7.704433441162109 8.729425430297852 7.782400131225586 8.775604248046875 7.938488960266113 8.652914047241211 C 8.054271697998047 8.561909675598145 8.01707935333252 8.43740177154541 8.064140319824219 8.348994255065918 C 8.10231876373291 8.27720832824707 8.172026634216309 8.219448089599609 8.228853225708008 8.201319694519043 C 8.392111778259277 8.149323463439941 8.526436805725098 8.207345008850098 8.539629936218262 8.419272422790527 C 8.550434112548828 8.591154098510742 8.461922645568848 8.656187057495117 8.41860294342041 8.698311805725098 C 8.365360260009766 8.750203132629395 8.319025993347168 8.751917839050293 8.222517013549805 8.778200149536133 C 8.12185001373291 8.805574417114258 7.919167995452881 9.053864479064941 7.894857883453369 9.140037536621094 C 7.870444297790527 9.226367950439453 8.00825023651123 9.371809005737305 7.969085216522217 9.406403541564941 C 7.908310890197754 9.460111618041992 7.710562705993652 9.44291877746582 7.633219242095947 9.271973609924316 Z M 8.822149276733398 6.293702602386475 C 8.928165435791016 6.282222747802734 9.068775177001953 6.316661357879639 9.12066650390625 6.386109352111816 C 9.172453880310059 6.45550537109375 9.236241340637207 6.557106494903564 9.236241340637207 6.557106494903564 C 9.236241340637207 6.557106494903564 9.261693000793457 6.275989532470703 9.325583457946777 6.276821136474609 C 9.412068367004395 6.277963638305664 9.495489120483398 6.576585292816162 9.489879608154297 6.697301864624023 C 9.484062194824219 6.823316097259521 9.488268852233887 6.90034818649292 9.34459400177002 6.950629234313965 C 9.200710296630859 7.000858306884766 9.019638061523438 7.086616516113281 8.790360450744629 6.953953742980957 C 8.684186935424805 6.892608165740967 8.871598243713379 6.843677520751953 8.959954261779785 6.664733409881592 C 9.048881530761719 6.48407506942749 8.635880470275879 6.31390905380249 8.822149276733398 6.293702602386475 Z M 9.590129852294922 8.20843505859375 C 9.566549301147461 8.032398223876953 9.34308910369873 8.036710739135742 9.225955963134766 7.964561462402344 C 9.093240737915039 7.88280200958252 8.946709632873535 7.713311672210693 8.927282333374023 7.530991077423096 C 8.913881301879883 7.404301166534424 8.635621070861816 7.303791046142578 9.043272018432617 7.298544406890869 C 9.290105819702148 7.295323371887207 9.29976749420166 7.429648876190186 9.343036651611328 7.490110874176025 C 9.386253356933594 7.550521373748779 9.49860668182373 7.78312349319458 9.635787963867188 7.875790119171143 C 9.782476425170898 7.974689960479736 9.891972541809082 8.154206275939941 9.787878036499023 8.394755363464355 C 9.73432445526123 8.518588066101074 9.594752311706543 8.563623428344727 9.516006469726563 8.49791431427002 C 9.421158790588379 8.418544769287109 9.621296882629395 8.442386627197266 9.590129852294922 8.208434104919434 Z M 8.713536262512207 6.715429782867432 C 8.687824249267578 6.715429782867432 8.666838645935059 6.680782794952393 8.666838645935059 6.638086795806885 C 8.666838645935059 6.595337390899658 8.687824249267578 6.560691356658936 8.713536262512207 6.560691356658936 C 8.739402770996094 6.560691356658936 8.76017951965332 6.595337390899658 8.76017951965332 6.638086795806885 C 8.76017951965332 6.680784225463867 8.739402770996094 6.715429782867432 8.713536262512207 6.715429782867432 Z M 8.713379859924316 8.067928314208984 C 8.769477844238281 8.032295227050781 8.700081825256348 7.854545116424561 8.784177780151367 7.852779865264893 C 8.871962547302246 7.85090970993042 9.154014587402344 8.132857322692871 9.241850852966309 8.213006019592285 C 9.345062255859375 8.307075500488281 9.363709449768066 8.585283279418945 9.54893970489502 8.633538246154785 C 9.81088924407959 8.701894760131836 9.815095901489258 8.833208084106445 9.794474601745605 8.908576965332031 C 9.774685859680176 8.980728149414063 9.645242691040039 9.1893310546875 9.532473564147949 9.229743003845215 C 9.419756889343262 9.270207405090332 9.362565994262695 9.214316368103027 9.343296051025391 9.153646469116211 C 9.321115493774414 9.083263397216797 9.381682395935059 9.009451866149902 9.340023994445801 8.898916244506836 C 9.287405014038086 8.759345054626465 8.835498809814453 8.541391372680664 8.702004432678223 8.497966766357422 C 8.58897590637207 8.46124267578125 8.4996337890625 8.209213256835938 8.536356925964355 8.157062530517578 C 8.571627616882324 8.106781005859375 8.657280921936035 8.103507995605469 8.713380813598633 8.067928314208984 Z M 9.370928764343262 9.986349105834961 C 9.247148513793945 9.920018196105957 9.422404289245605 9.831870079040527 9.42723560333252 9.741333961486816 C 9.432117462158203 9.650795936584473 9.368642807006836 9.478864669799805 9.236863136291504 9.469929695129395 C 9.104252815246582 9.460942268371582 8.994704246520996 9.464527130126953 8.876845359802246 9.3790283203125 C 8.758881568908691 9.293477058410645 8.69442081451416 9.196291923522949 8.681745529174805 9.073654174804688 C 8.664812088012695 8.908267021179199 8.770049095153809 8.845155715942383 8.841108322143555 8.824846267700195 C 8.886453628540039 8.81196403503418 8.860067367553711 8.947536468505859 9.018182754516602 8.980104446411133 C 9.19276237487793 9.016049385070801 9.201541900634766 9.055889129638672 9.273430824279785 9.137545585632324 C 9.382096290588379 9.26096248626709 9.387084007263184 9.394975662231445 9.549613952636719 9.434503555297852 C 9.763568878173828 9.486447334289551 9.876856803894043 9.698064804077148 9.755153656005859 9.815715789794922 C 9.635061264038086 9.931809425354004 9.470711708068848 10.03985118865967 9.370928764343262 9.986350059509277 Z M 10.43758487701416 11.79516887664795 C 10.44402503967285 11.74270725250244 10.45623302459717 11.7041654586792 10.49872207641602 11.70380210876465 C 10.57876777648926 11.70312595367432 10.60951709747314 11.86305904388428 10.61434745788574 11.88856410980225 C 10.62359237670898 11.93723487854004 10.56604099273682 11.9803991317749 10.50194263458252 11.94762229919434 C 10.4446496963501 11.91837787628174 10.42865085601807 11.86825370788574 10.43758487701416 11.79516887664795 Z M 10.29214382171631 10.64332675933838 C 10.25858688354492 10.64945602416992 10.21557807922363 10.61455154418945 10.27011966705322 10.55445194244385 C 10.32455539703369 10.49430179595947 10.33935928344727 10.38371467590332 10.28762435913086 10.29520416259766 C 10.23594188690186 10.20664024353027 10.02525806427002 10.00764560699463 9.956954002380371 9.984115600585938 C 9.888700485229492 9.960585594177246 9.889219284057617 9.83311653137207 9.954460144042969 9.787874221801758 C 10.00375461578369 9.753539085388184 10.06047630310059 9.77556324005127 10.0003776550293 9.733957290649414 C 9.940486907958984 9.692350387573242 9.890933036804199 9.577712059020996 9.845328330993652 9.476993560791016 C 9.802733421325684 9.382820129394531 9.843508720397949 9.336851119995117 9.843508720397949 9.336851119995117 C 9.903555870056152 9.295711517333984 10.00079345703125 9.432478904724121 10.02234935760498 9.453462600708008 C 10.04380226135254 9.474344253540039 10.21744823455811 9.639627456665039 10.22898101806641 9.667365074157715 C 10.25526332855225 9.730631828308105 10.20643615722656 9.839817047119141 10.25677013397217 9.849634170532227 C 10.35904598236084 9.86958122253418 10.32419204711914 9.969779014587402 10.50495529174805 9.994036674499512 C 10.66779708862305 10.01595687866211 10.66322612762451 10.24570178985596 10.6284761428833 10.34782218933105 C 10.59949111938477 10.43290615081787 10.42984580993652 10.61813449859619 10.29214382171631 10.64332675933838 Z M 9.964900016784668 8.609904289245605 C 10.11750888824463 8.716075897216797 10.10171890258789 8.80952262878418 10.24929141998291 9.056876182556152 C 10.39686107635498 9.304333686828613 10.56541728973389 9.234417915344238 10.60967254638672 9.338251113891602 C 10.64478588104248 9.420322418212891 10.63413715362549 9.478446960449219 10.60728454589844 9.581761360168457 C 10.56941699981689 9.726528167724609 10.42693614959717 9.79613208770752 10.36325359344482 9.779977798461914 C 10.29946804046631 9.763771057128906 10.30673980712891 9.602798461914063 10.29458427429199 9.489511489868164 C 10.28175640106201 9.370924949645996 10.02094650268555 9.351497650146484 9.97373104095459 9.294255256652832 C 9.926514625549316 9.237013816833496 9.869532585144043 8.543468475341797 9.964900016784668 8.609903335571289 Z M 10.34029483795166 9.055733680725098 C 10.28315734863281 9.03952693939209 10.40901565551758 8.926446914672852 10.40787315368652 8.828428268432617 C 10.40699005126953 8.756539344787598 10.18846416473389 8.596918106079102 10.02738857269287 8.522586822509766 C 9.92568302154541 8.475734710693359 9.966146469116211 8.38124942779541 9.999390602111816 8.329825401306152 C 10.03284168243408 8.278349876403809 9.963082313537598 8.034838676452637 10.05528163909912 8.051617622375488 C 10.1574535369873 8.070213317871094 10.29250717163086 8.20360279083252 10.33000946044922 8.258195877075195 C 10.37436962127686 8.322813987731934 10.48963165283203 8.368782997131348 10.61081695556641 8.515159606933594 C 10.73199939727783 8.661535263061523 10.8027982711792 8.71015453338623 10.74493408203125 8.875125885009766 C 10.67257690429688 9.081600189208984 10.44174003601074 9.084561347961426 10.34029579162598 9.055733680725098 Z M 10.84871482849121 8.122624397277832 C 10.67652320861816 8.153944969177246 10.75142574310303 8.034060478210449 10.79349994659424 7.999517917633057 C 10.83557319641113 7.965027809143066 10.91011238098145 7.819638729095459 10.77308559417725 7.736478328704834 C 10.63616275787354 7.653368473052979 10.56723499298096 7.570674896240234 10.66556262969971 7.500083923339844 C 10.73075199127197 7.453335762023926 10.86289501190186 7.442376136779785 11.04370975494385 7.648122787475586 C 11.26207828521729 7.896307945251465 11.02101039886475 8.091355323791504 10.84871387481689 8.122624397277832 Z M 10.60640048980713 7.982844829559326 C 10.60707569122314 8.055305480957031 10.45882892608643 8.233211517333984 10.33728218078613 8.192279815673828 C 10.26856136322021 8.169216156005859 10.32814025878906 8.111715316772461 10.2898063659668 7.968144416809082 C 10.25204277038574 7.826287269592285 10.08733081817627 7.841922760009766 9.998819351196289 7.79964017868042 C 9.919814109802246 7.761773586273193 9.714741706848145 7.667963981628418 9.644203186035156 7.466580390930176 C 9.573716163635254 7.265143871307373 9.781644821166992 7.290388107299805 9.781644821166992 7.290388107299805 C 9.970561981201172 7.290855884552002 9.974457740783691 7.391574382781982 9.987547874450684 7.409598350524902 C 10.005934715271 7.435050964355469 10.07034492492676 7.556182384490967 10.27074337005615 7.641108989715576 C 10.48002243041992 7.729672431945801 10.60562133789063 7.878853321075439 10.60640048980713 7.98284387588501 Z M 8.055986404418945 6.293753147125244 C 8.087775230407715 6.288558959960938 8.091410636901855 6.476957321166992 8.119461059570313 6.520226001739502 C 8.136238098144531 6.546145439147949 8.206206321716309 6.350163459777832 8.246825218200684 6.33868408203125 C 8.31648063659668 6.319049835205078 8.276484489440918 6.480332851409912 8.297470092773438 6.54006814956665 C 8.311287879943848 6.579441070556641 8.529449462890625 6.29027271270752 8.593754768371582 6.299622535705566 C 8.634840965270996 6.305595874786377 8.462857246398926 6.542873382568359 8.446650505065918 6.605205059051514 C 8.424886703491211 6.688885688781738 8.466285705566406 6.768929958343506 8.484518051147461 6.780720710754395 C 8.599260330200195 6.854844093322754 8.661487579345703 6.803420543670654 8.660502433776855 6.877543449401855 C 8.65904712677002 6.976963043212891 8.616142272949219 6.900086879730225 8.520930290222168 6.961172103881836 C 8.459169387817383 7.000857353210449 8.424004554748535 7.055864810943604 8.347440719604492 7.050981998443604 C 8.27061653137207 7.04610013961792 8.183870315551758 7.015712738037109 8.106630325317383 6.962263584136963 C 8.040454864501953 6.916345596313477 7.937399387359619 6.888452053070068 7.9335036277771 6.651954650878906 C 7.930698394775391 6.479295253753662 7.963786602020264 6.308868885040283 8.055987358093262 6.293754100799561 Z M 7.963890552520752 7.46980094909668 C 8.085073471069336 7.356253147125244 8.13468074798584 7.336930274963379 8.202569961547852 7.316827774047852 C 8.264642715454102 7.298439502716064 8.392162322998047 7.307010650634766 8.471480369567871 7.323320865631104 C 8.57578182220459 7.34482479095459 8.552563667297363 7.715128421783447 8.362087249755859 7.876100540161133 C 8.17171573638916 8.037176132202148 7.979525089263916 8.018840789794922 7.88633918762207 8.158879280090332 C 7.813306331634521 8.268740653991699 7.851588726043701 8.416881561279297 7.90327262878418 8.472825050354004 C 7.9549560546875 8.528767585754395 7.62122106552124 8.474643707275391 7.583665370941162 8.275908470153809 C 7.558005809783936 8.140179634094238 7.645842552185059 8.032814025878906 7.734976291656494 7.93375825881958 C 7.762661933898926 7.902904033660889 7.752585411071777 7.840779781341553 7.778141021728516 7.773304462432861 C 7.809307098388672 7.691183090209961 7.899532318115234 7.530054569244385 7.963890552520752 7.469799995422363 Z M 7.343064308166504 7.844155788421631 C 7.220010280609131 7.96461296081543 7.255851745605469 8.034632682800293 7.232944965362549 8.086991310119629 C 7.204532146453857 8.151867866516113 7.028652191162109 8.157425880432129 6.994058132171631 8.010634422302246 C 6.959568023681641 7.863842487335205 7.156224727630615 7.374485015869141 7.459521293640137 7.221615791320801 C 7.534475326538086 7.183853149414063 7.778505325317383 7.183437824249268 7.79710054397583 7.282129764556885 C 7.839641571044922 7.508083343505859 7.466066360473633 7.723699569702148 7.343064308166504 7.844155311584473 Z M 7.128019332885742 8.302087783813477 C 7.248164176940918 8.259493827819824 7.442327499389648 8.354134559631348 7.40617561340332 8.491940498352051 C 7.37007474899292 8.629745483398438 7.167444229125977 8.723295211791992 7.134719848632813 8.820949554443359 C 7.105320453643799 8.908732414245605 7.103606224060059 9.046850204467773 7.172483444213867 9.110844612121582 C 7.241203784942627 9.174942016601563 7.037014961242676 9.142477035522461 6.94221830368042 9.040927886962891 C 6.877342224121094 8.971480369567871 6.811632633209229 8.800015449523926 6.843734264373779 8.650107383728027 C 6.875834941864014 8.500199317932129 7.02221155166626 8.339798927307129 7.128020286560059 8.302087783813477 Z M 6.921753406524658 7.228524208068848 C 6.819944381713867 7.536963939666748 6.662815093994141 7.454010009765625 6.371777534484863 7.61155366897583 C 6.255944728851318 7.674300670623779 6.279214859008789 7.488603115081787 6.306692600250244 7.397755146026611 C 6.35016918182373 7.254183769226074 6.530412673950195 7.179749488830566 6.643077373504639 7.13294792175293 C 6.755690574645996 7.086147308349609 6.783064365386963 6.942524433135986 6.850226879119873 6.954730987548828 C 6.880614280700684 6.9602370262146 6.960554122924805 7.110767841339111 6.921753406524658 7.228523254394531 Z M 6.099854946136475 7.16821813583374 C 6.089985370635986 7.275949001312256 5.829489707946777 6.987923622131348 5.948855876922607 6.863466739654541 C 6.066091537475586 6.741348743438721 6.115437984466553 6.598504543304443 6.20488452911377 6.528017520904541 C 6.260671138763428 6.48412561416626 6.375517845153809 6.585155487060547 6.388919353485107 6.744465351104736 C 6.402268886566162 6.903878688812256 6.110451221466064 7.053215980529785 6.099854946136475 7.16821813583374 Z M 5.950517654418945 11.6180419921875 C 5.957634449005127 11.56978702545166 5.942934036254883 11.35869026184082 6.063910484313965 11.40705013275146 C 6.095180034637451 11.41956806182861 6.127748012542725 11.49800300598145 6.144837379455566 11.53342819213867 C 6.182703971862793 11.61191272735596 6.123384952545166 11.64661121368408 6.085882186889648 11.73522663116455 C 6.060585975646973 11.79522132873535 6.089414119720459 11.97120475769043 6.04318380355835 11.99338436126709 C 5.976437091827393 12.02543449401855 5.87706995010376 11.84830665588379 5.872083187103271 11.73512268066406 C 5.867096900939941 11.62193775177002 5.943453311920166 11.66619491577148 5.950517654418945 11.6180419921875 Z M 7.80442476272583 17.46426010131836 C 7.822084903717041 17.59972763061523 7.896935939788818 18.21000862121582 7.865665912628174 18.32942771911621 C 7.837045192718506 18.43845558166504 7.664801120758057 17.54955101013184 7.664801120758057 17.23653984069824 C 7.664801120758057 17.04045486450195 7.677943229675293 16.59145545959473 7.766817569732666 16.52792930603027 C 7.766817569732666 16.52792930603027 7.766765594482422 16.75679397583008 7.766765594482422 16.90160942077637 C 7.76671314239502 17.07837295532227 7.800476551055908 17.41714668273926 7.80442476272583 17.46426010131836 Z M 7.619402885437012 15.77833652496338 C 7.520139217376709 15.87588500976563 7.525853633880615 15.39416408538818 7.529125213623047 15.31962490081787 C 7.54356575012207 14.99243354797363 7.430692672729492 14.16009616851807 7.424615383148193 14.00561618804932 C 7.417707443237305 13.82978820800781 7.315794467926025 13.33014678955078 7.406331539154053 13.15644836425781 C 7.462741851806641 13.04845905303955 7.413499355316162 12.70802211761475 7.711394309997559 12.70329570770264 C 7.809099197387695 12.70173740386963 7.935322284698486 12.93724727630615 8.020509719848633 12.96166038513184 C 8.105800628662109 12.98607540130615 7.942126274108887 13.29820156097412 7.929555892944336 13.38759613037109 C 7.921816349029541 13.44333171844482 7.8864426612854 13.48182106018066 7.88374137878418 13.5537633895874 C 7.879898071289063 13.65666198730469 7.923789978027344 13.73359107971191 7.94680118560791 13.83327007293701 C 7.986018657684326 14.00260639190674 7.976045608520508 15.42735767364502 7.619402885437012 15.7783374786377 Z M 10.74285697937012 11.92461204528809 C 10.62551689147949 11.95105171203613 10.68218803405762 11.92539119720459 10.68218803405762 11.92539119720459 C 10.68218803405762 11.92539119720459 10.78389167785645 11.86035823822021 10.77365875244141 11.72660446166992 C 10.76347827911377 11.59279823303223 10.72395038604736 11.56267166137695 10.67688846588135 11.47218704223633 C 10.628737449646 11.37936496734619 10.63938522338867 11.28721618652344 10.71376895904541 11.2593240737915 C 10.86606693267822 11.20239353179932 10.9391508102417 11.42912578582764 10.94013786315918 11.50558567047119 C 10.94164371490479 11.62448406219482 10.91998386383057 11.88461589813232 10.74285697937012 11.92461204528809 Z M 10.93047618865967 10.94246864318848 C 10.93172264099121 10.85847568511963 10.80373382568359 10.98636150360107 10.71756076812744 10.8749418258667 C 10.69112110137939 10.84076309204102 10.65574741363525 10.7113733291626 10.78539848327637 10.66410446166992 C 10.90964603424072 10.61886215209961 11.10983657836914 10.79219627380371 11.15596199035645 10.85561943054199 C 11.20208835601807 10.91899013519287 11.13170528411865 11.05108261108398 11.07960605621338 11.07913017272949 C 11.01478004455566 11.11388206481934 10.9284496307373 11.09035015106201 10.93047618865967 10.94246864318848 Z M 11.07378673553467 10.44500827789307 C 11.05191993713379 10.32076072692871 10.94938278198242 10.20876979827881 10.85204219818115 10.12508964538574 C 10.75464820861816 10.04140949249268 10.73252105712891 10.08130168914795 10.70919895172119 10.02499485015869 C 10.68577194213867 9.968740463256836 10.81277275085449 9.71790599822998 10.90346527099609 9.722373962402344 C 10.90346527099609 9.722373962402344 10.96029281616211 9.73302173614502 10.99327659606934 9.789172172546387 C 11.02636337280273 9.845375061035156 11.00252151489258 9.941937446594238 10.99587440490723 9.987751007080078 C 10.98912048339844 10.03356552124023 11.07737350463867 10.03159141540527 11.15746879577637 10.1074800491333 C 11.23782539367676 10.18342208862305 11.22816467285156 10.31276035308838 11.21206092834473 10.37535095214844 C 11.19585514068604 10.43783855438232 11.09555244445801 10.56925582885742 11.0737886428833 10.44500732421875 Z M 11.10085010528564 9.663209915161133 C 11.13700199127197 9.620928764343262 11.19086742401123 9.616721153259277 11.15248203277588 9.532312393188477 C 11.11409568786621 9.447853088378906 10.86570358276367 9.409415245056152 10.80264377593994 9.231145858764648 C 10.77610111236572 9.15655517578125 10.84523773193359 9.047630310058594 10.98376941680908 9.047526359558105 C 11.0525426864624 9.047473907470703 11.12121200561523 9.077186584472656 11.22213745117188 9.186059951782227 C 11.27584648132324 9.24387264251709 11.37817478179932 9.360121726989746 11.27963924407959 9.547688484191895 C 11.19772434234619 9.703830718994141 11.06641292572021 9.703675270080566 11.10085010528564 9.663209915161133 Z M 11.36279964447021 7.853507518768311 C 11.20286750793457 7.856571674346924 11.22951412200928 7.775903701782227 11.17154407501221 7.674770832061768 C 11.11367988586426 7.573585510253906 11.01493453979492 7.570053100585938 10.98174285888672 7.445025444030762 C 10.96335601806641 7.375785350799561 10.99831295013428 7.319115161895752 11.02340126037598 7.297091007232666 C 11.09373378753662 7.235486030578613 11.1740894317627 7.295583724975586 11.2484712600708 7.342333316802979 C 11.33906078338623 7.399262428283691 11.49785137176514 7.511980533599854 11.51582431793213 7.591089725494385 C 11.53384780883789 7.670095443725586 11.54636573791504 7.849974632263184 11.3627986907959 7.853507518768311 Z M 11.13097667694092 7.160012722015381 C 11.0063648223877 7.161571025848389 11.01639080047607 7.059554100036621 10.97031688690186 6.929592132568359 C 10.92429447174072 6.799630165100098 10.96423816680908 6.690341472625732 11.0307788848877 6.684887409210205 C 11.12406921386719 6.677096366882324 11.11835479736328 6.840198040008545 11.17024612426758 6.914268970489502 C 11.23366737365723 7.004806041717529 11.25543308258057 7.158401966094971 11.13097667694092 7.160012722015381 Z M 7.69897985458374 6.238591194152832 C 7.744274616241455 6.247109889984131 7.682202339172363 6.457064151763916 7.703239440917969 6.4808030128479 C 7.738716602325439 6.52090311050415 7.782608509063721 6.366735458374023 7.782608509063721 6.366735458374023 C 7.782608509063721 6.366735458374023 7.8703932762146 6.211997032165527 7.913246154785156 6.208879470825195 C 7.971318244934082 6.204567909240723 7.957605838775635 6.261965751647949 7.913246154785156 6.338738441467285 C 7.876470565795898 6.402472019195557 7.7431321144104 6.547237873077393 7.749936580657959 6.637774467468262 C 7.756741046905518 6.728260040283203 7.823280811309814 6.886531352996826 7.7431321144104 6.943720817565918 C 7.605066776275635 7.042257308959961 7.554526329040527 7.001792907714844 7.418694496154785 6.910580635070801 C 7.259695529937744 6.803889274597168 7.284732818603516 6.620633602142334 7.232581615447998 6.530720233917236 C 7.180482864379883 6.440805912017822 7.168275833129883 6.438416481018066 7.067039012908936 6.425274848937988 C 6.987617492675781 6.414990425109863 7.002006053924561 6.21308708190918 7.012239456176758 6.139950752258301 C 7.022576332092285 6.06619119644165 7.118670463562012 6.039544582366943 7.118670463562012 6.039544582366943 C 7.218921184539795 6.038246154785156 7.254242897033691 6.117095470428467 7.262917041778564 6.202646255493164 C 7.274240493774414 6.314999580383301 7.340675354003906 6.181869029998779 7.39521598815918 6.111174583435059 C 7.474170207977295 6.008689880371094 7.439835071563721 6.399926662445068 7.495674610137939 6.400186538696289 C 7.532087802886963 6.40044641494751 7.602574348449707 6.22051477432251 7.698980331420898 6.238591194152832 Z M 5.926467418670654 7.630515098571777 C 6.014927387237549 7.610983848571777 6.145979881286621 7.747958183288574 6.064065933227539 7.843949317932129 C 5.965945243835449 7.959003448486328 5.703527450561523 8.051150321960449 5.727213382720947 8.132909774780273 C 5.750951290130615 8.214616775512695 5.515752792358398 8.060397148132324 5.661660671234131 7.866128921508789 C 5.80756950378418 7.671809673309326 5.850838184356689 7.647240161895752 5.926467418670654 7.630515098571777 Z M 5.822684764862061 8.837884902954102 C 5.71994161605835 8.92390251159668 5.677919387817383 9.135675430297852 5.627326011657715 9.057967185974121 C 5.614444732666016 9.038229942321777 5.562241554260254 8.927070617675781 5.606289863586426 8.720439910888672 C 5.650285720825195 8.513757705688477 5.767677783966064 8.401767730712891 5.858993053436279 8.439739227294922 C 5.901845932006836 8.457607269287109 5.892756462097168 8.779343605041504 5.822684764862061 8.837882995605469 Z M 5.776975154876709 7.270703792572021 C 5.74773120880127 7.347424030303955 5.703683376312256 7.513123512268066 5.606809139251709 7.465958595275879 C 5.567020893096924 7.446739673614502 5.498039722442627 7.196061134338379 5.651791572570801 7.085993766784668 C 5.704513549804688 7.048387050628662 5.806271076202393 7.1938796043396 5.776975154876709 7.270703792572021 Z M 5.798272132873535 9.250209808349609 C 5.907924652099609 9.181540489196777 5.970360279083252 9.438451766967773 5.907508850097656 9.540779113769531 C 5.844709396362305 9.643054962158203 5.672933101654053 9.79872989654541 5.624157905578613 9.909784317016602 C 5.575331211090088 10.02083969116211 5.498610973358154 9.724087715148926 5.5482177734375 9.621552467346191 C 5.597875118255615 9.518963813781738 5.703423500061035 9.30958080291748 5.798272132873535 9.250209808349609 Z M 5.53419303894043 7.871998310089111 C 5.514713764190674 7.968769073486328 5.524271011352539 8.092913627624512 5.389166831970215 8.153063774108887 C 5.311252117156982 8.187709808349609 5.310525417327881 8.100236892700195 5.303252696990967 7.985649108886719 C 5.297591209411621 7.896567344665527 5.304707050323486 7.745827674865723 5.372909069061279 7.735335350036621 C 5.456485748291016 7.72240161895752 5.559437274932861 7.746762752532959 5.53419303894043 7.871997356414795 Z M 5.269229888916016 8.598893165588379 C 5.214533805847168 8.56279182434082 5.289955615997314 8.388626098632813 5.338833332061768 8.344681739807129 C 5.399763584136963 8.289986610412598 5.447239398956299 8.39833927154541 5.44775915145874 8.43724536895752 C 5.448538303375244 8.498797416687012 5.360649585723877 8.659302711486816 5.269229888916016 8.598893165588379 Z M 5.367351055145264 9.253118515014648 C 5.299357414245605 9.406922340393066 5.263204574584961 9.189435005187988 5.257957935333252 9.155308723449707 C 5.245751857757568 9.075264930725098 5.219000816345215 8.875491142272949 5.289175987243652 8.846247673034668 C 5.382829666137695 8.807341575622559 5.493780612945557 8.967378616333008 5.367350578308105 9.253118515014648 Z M 5.24871301651001 9.467435836791992 C 5.309330463409424 9.434971809387207 5.406672477722168 9.640822410583496 5.365065574645996 9.748138427734375 C 5.322004318237305 9.859504699707031 5.1271653175354 9.677910804748535 5.126333713531494 9.610020637512207 C 5.125399112701416 9.542078971862793 5.206119060516357 9.490240097045898 5.24871301651001 9.467437744140625 Z M 5.13521671295166 10.30055522918701 C 5.147735118865967 10.17885112762451 5.220143795013428 10.15075016021729 5.270788192749023 10.15012741088867 C 5.332133769989014 10.14934825897217 5.359923839569092 10.16971015930176 5.361533641815186 10.28860759735107 C 5.363663196563721 10.44781398773193 5.26673698425293 10.58068466186523 5.245751857757568 10.58104801177979 C 5.203885555267334 10.58162021636963 5.122646331787109 10.42168712615967 5.13521671295166 10.30055522918701 Z M 5.401166439056396 10.9448070526123 C 5.457940578460693 10.91301727294922 5.566294193267822 11.02557849884033 5.578293323516846 11.07076930999756 C 5.590240955352783 11.1159086227417 5.663376331329346 11.25646686553955 5.63672924041748 11.296462059021 C 5.610082149505615 11.33651161193848 5.515909671783447 11.38866138458252 5.40511417388916 11.24773979187012 C 5.335042953491211 11.15891742706299 5.264762878417969 11.02116298675537 5.401166915893555 10.9448070526123 Z M 5.640832901000977 11.61918640136719 C 5.713449478149414 11.62952327728271 5.739784240722656 11.74250030517578 5.723681926727295 11.80961132049561 C 5.707528114318848 11.87672233581543 5.805492401123047 12.00216484069824 5.726123332977295 12.00107288360596 C 5.646857738494873 11.9999828338623 5.606498241424561 11.9424295425415 5.571384429931641 11.85620403289795 C 5.536374092102051 11.76997756958008 5.586655139923096 11.61144733428955 5.64083194732666 11.61918640136719 Z M 5.767158508300781 12.71503448486328 C 5.792247295379639 12.63883304595947 5.821959018707275 12.39002418518066 5.921170234680176 12.39002418518066 C 6.045730590820313 12.39002418518066 6.011967182159424 13.30193901062012 5.951817035675049 13.37907695770264 C 5.891666412353516 13.45636749267578 5.98277473449707 14.29722499847412 5.915456771850586 14.25239849090576 C 5.804349899291992 14.17817115783691 5.704410552978516 13.38790607452393 5.706280708312988 13.30869293212891 C 5.708514213562012 13.20927238464355 5.673816204071045 13.05952072143555 5.664206981658936 12.94960880279541 C 5.658700942993164 12.88732814788818 5.741965770721436 12.79118156433105 5.767158508300781 12.71503257751465 Z M 5.453940391540527 16.80276298522949 C 5.421840190887451 16.94472312927246 5.372233867645264 17.46109199523926 5.326627731323242 17.43330192565918 C 5.280970573425293 17.40556526184082 5.302734375 16.89132690429688 5.346574306488037 16.77746772766113 C 5.39036226272583 16.66360664367676 5.499131202697754 16.49905014038086 5.543179988861084 16.47136306762695 C 5.587331295013428 16.44362640380859 5.48609447479248 16.66080093383789 5.453940868377686 16.80276298522949 Z M 5.326627731323242 17.79056739807129 C 5.326160430908203 17.89445304870605 5.299928665161133 17.92582893371582 5.295566082000732 17.98088836669922 C 5.288449764251709 18.0715274810791 5.195783615112305 18.00945472717285 5.195783615112305 17.86074447631836 C 5.195783615112305 17.81404685974121 5.227779865264893 17.66959190368652 5.295566082000732 17.6602954864502 C 5.295566082000732 17.66034698486328 5.326835632324219 17.74220848083496 5.326627731323242 17.79056739807129 Z M 5.25629711151123 18.24184989929199 C 5.357637882232666 18.21790504455566 5.429475784301758 17.83804321289063 5.512481212615967 17.89455795288086 C 5.60223913192749 17.95569610595703 5.477627277374268 18.36952781677246 5.362988471984863 18.40079689025879 C 5.122854232788086 18.46624565124512 5.040680408477783 18.79831886291504 5.015228271484375 18.70087242126465 C 4.991957664489746 18.61199760437012 4.924639225006104 18.19821739196777 5.02140998840332 18.16024780273438 C 5.118596076965332 18.1221752166748 5.104207515716553 18.27774238586426 5.25629711151123 18.24185180664063 Z M 5.07781982421875 19.24248695373535 C 4.831920623779297 19.37037086486816 4.91180944442749 19.58780479431152 4.849581718444824 19.58551979064941 C 4.773172855377197 19.58255767822266 4.661910533905029 19.58551979064941 4.602487087249756 19.58551979064941 C 4.547946453094482 19.58551979064941 4.608824253082275 19.4422607421875 4.633029460906982 19.4031982421875 C 4.661182880401611 19.3577995300293 4.743253707885742 19.20732116699219 4.928431034088135 19.18498420715332 C 5.00016450881958 19.1762580871582 5.111634731292725 19.22492980957031 5.077819347381592 19.24248695373535 Z M 6.136995315551758 19.56027412414551 C 6.110192775726318 19.55850982666016 6.129203319549561 19.42018508911133 6.212728977203369 19.2841968536377 C 6.254127025604248 19.21672248840332 6.306849479675293 19.12203025817871 6.381700038909912 19.12332916259766 C 6.451459884643555 19.1246280670166 6.579707622528076 19.12873077392578 6.586408138275146 19.1277961730957 C 6.722239971160889 19.10930442810059 6.534672260284424 19.23531913757324 6.450524806976318 19.30793571472168 C 6.365857601165771 19.38086128234863 6.417437076568604 19.55336761474609 6.361286640167236 19.56843185424805 C 6.291994094848633 19.58708000183105 6.251010894775391 19.5677547454834 6.136995315551758 19.56027412414551 Z M 9.142849922180176 24.55815124511719 C 9.192351341247559 24.51446914672852 9.210790634155273 24.45333099365234 9.18944263458252 24.41697120666504 C 9.17172908782959 24.38642692565918 9.118851661682129 24.27786636352539 9.156146049499512 24.26991844177246 C 9.218270301818848 24.25662422180176 9.270731925964355 24.24477958679199 9.295665740966797 24.23475646972656 C 9.332493782043457 24.2201042175293 9.471181869506836 24.47883605957031 9.403396606445313 24.54007530212402 C 9.35898494720459 24.5803337097168 9.113138198852539 24.58428192138672 9.142849922180176 24.55815124511719 Z M 10.10821437835693 24.7380313873291 C 10.11122608184814 24.69756889343262 10.24170970916748 24.71808624267578 10.33260917663574 24.71865653991699 C 10.42356300354004 24.71902084350586 10.40377235412598 24.76608085632324 10.41322612762451 24.79548263549805 C 10.4384183883667 24.87401962280273 10.3170280456543 24.8695011138916 10.22571086883545 24.86996841430664 C 10.10779857635498 24.87038421630859 10.10302066802979 24.81070137023926 10.10821533203125 24.7380313873291 Z M 10.26814842224121 24.54953002929688 C 10.29360008239746 24.49431419372559 10.30762386322021 24.44387626647949 10.29360008239746 24.4172306060791 C 10.25827884674072 24.34991264343262 10.09003353118896 24.16031837463379 10.14924812316895 24.15860557556152 C 10.19449138641357 24.15730667114258 10.22570896148682 24.13907432556152 10.28653526306152 24.1800594329834 C 10.32274150848389 24.20446968078613 10.46781921386719 24.32658958435059 10.47618103027344 24.38284111022949 C 10.48469924926758 24.43904685974121 10.51700687408447 24.55835723876953 10.44220924377441 24.57503318786621 C 10.3719310760498 24.59072113037109 10.24269580841064 24.60474586486816 10.26814842224121 24.54953002929688 Z M 11.46450424194336 21.23373222351074 C 11.44409084320068 21.22017669677734 11.43739032745361 21.17399597167969 11.49151515960693 21.17129707336426 C 11.51291561126709 21.17020606994629 11.56376838684082 21.1983585357666 11.54574394226074 21.21742248535156 C 11.52761650085449 21.23648452758789 11.48471164703369 21.24723625183105 11.46450614929199 21.23373222351074 Z M 11.79257774353027 18.81390190124512 C 11.7940845489502 18.77011489868164 11.81465530395508 18.7179126739502 11.85475540161133 18.72492408752441 C 11.89594554901123 18.73209190368652 11.9060754776001 18.79416465759277 11.91589260101318 18.82673263549805 C 11.93287658691406 18.88335037231445 11.95407009124756 19.01554489135742 11.94134426116943 19.03975105285645 C 11.91864585876465 19.08291816711426 11.87683010101318 19.10608291625977 11.82525253295898 18.95768356323242 C 11.81398105621338 18.92501068115234 11.7900857925415 18.8839225769043 11.79257869720459 18.81390190124512 Z M 11.94524002075195 18.38573455810547 C 11.90300941467285 18.42396545410156 11.88129806518555 18.39892768859863 11.86883163452148 18.343505859375 C 11.85636520385742 18.28813362121582 11.93059158325195 18.19681549072266 11.90301036834717 18.10976028442383 C 11.87542819976807 18.02265167236328 11.81912136077881 17.89949417114258 11.85470294952393 17.89320945739746 C 11.88436317443848 17.88785743713379 11.99214458465576 18.09485244750977 11.99001502990723 18.17349433898926 C 11.98809337615967 18.25197792053223 11.98752117156982 18.34755706787109 11.94524002075195 18.38573455810547 Z M 11.79055213928223 18.27104377746582 C 11.78977298736572 18.30033874511719 11.75871086120605 18.36028099060059 11.73190879821777 18.33903694152832 C 11.70157337188721 18.31488227844238 11.72910404205322 18.11609649658203 11.67045974731445 18.04561042785645 C 11.63841152191162 18.00685882568359 11.67799186706543 17.95476150512695 11.73232460021973 17.95476150512695 C 11.78000736236572 17.95476150512695 11.79242324829102 18.20533561706543 11.79055213928223 18.27104377746582 Z M 11.51286506652832 18.1189022064209 C 11.50855350494385 18.22528266906738 11.55358695983887 18.4382495880127 11.64573574066162 18.54483795166016 C 11.66194152832031 18.56364059448242 11.64921569824219 18.63397216796875 11.64573574066162 18.65121650695801 C 11.64069652557373 18.67480087280273 11.67451190948486 18.64591979980469 11.69149589538574 18.61553382873535 C 11.72266387939453 18.55985069274902 11.82254886627197 18.58296203613281 11.85475540161133 18.66955375671387 C 11.85766315460205 18.67729187011719 11.74930953979492 18.6514778137207 11.67674541473389 18.72347068786621 C 11.6539945602417 18.74596214294434 11.59571361541748 18.8521842956543 11.65976047515869 18.90215492248535 C 11.71539115905762 18.94568252563477 11.79865646362305 19.06245231628418 11.73237705230713 19.06245231628418 C 11.69622421264648 19.06245231628418 11.58610439300537 19.09283828735352 11.56335353851318 18.98770523071289 C 11.54060077667236 18.88257217407227 11.54590034484863 18.83411026000977 11.51530456542969 18.6668529510498 C 11.49759292602539 18.56971740722656 11.43359851837158 18.533203125 11.37755298614502 18.37420272827148 C 11.33449172973633 18.25213623046875 11.23876094818115 18.15230178833008 11.33656883239746 18.05246734619141 C 11.38638210296631 18.00166702270508 11.51712417602539 18.01236724853516 11.51286506652832 18.1189022064209 Z M 11.39557647705078 17.81056594848633 C 11.37194156646729 17.88733863830566 11.09809684753418 17.82355117797852 11.02496147155762 17.73493766784668 C 10.95187759399414 17.6463737487793 10.93868446350098 16.65280342102051 10.96886348724365 16.50798606872559 C 10.98262691497803 16.44144630432129 11.00854778289795 16.11685180664063 11.13570499420166 16.09815216064453 C 11.23808479309082 16.08308982849121 11.27932834625244 16.30919647216797 11.3087797164917 16.41022872924805 C 11.34976387023926 16.5497989654541 11.41936588287354 17.73374366760254 11.39557838439941 17.8105640411377 Z M 11.11638069152832 15.03118515014648 C 11.14089775085449 15.17802810668945 10.80279922485352 15.93567276000977 10.74555778503418 15.94180393218994 C 10.69148540496826 15.94762134552002 10.66083908081055 15.71652412414551 10.78602313995361 14.88813400268555 C 10.7926721572876 14.84434604644775 10.83957576751709 14.65423393249512 10.83074474334717 14.61563968658447 C 10.76773738861084 14.33909320831299 10.88149356842041 14.37924575805664 10.91936111450195 14.24647808074951 C 10.95488834381104 14.12197113037109 10.82949829101563 14.11470031738281 10.93286514282227 13.9801139831543 C 11.01638889312744 13.87150001525879 10.92751407623291 12.6836109161377 11.13076877593994 12.63338184356689 C 11.21341037750244 12.6129150390625 11.324049949646 13.11453056335449 11.23792743682861 13.91970443725586 C 11.21045017242432 14.17645931243896 11.09186363220215 14.88418579101563 11.11638069152832 15.03118801116943 Z M 11.24400615692139 11.9150562286377 C 11.27215957641602 11.96564960479736 11.09066963195801 11.94533920288086 11.08874797821045 11.78680896759033 C 11.08667087554932 11.62827777862549 11.19548988342285 11.50226402282715 11.27750968933105 11.50122547149658 C 11.36773490905762 11.50008296966553 11.38586330413818 11.65705490112305 11.3509578704834 11.73507308959961 C 11.31615543365479 11.8129358291626 11.21606159210205 11.86446475982666 11.24400615692139 11.9150562286377 Z M 12.17233562469482 12.56845092773438 C 12.13301467895508 12.60579776763916 11.9336051940918 12.40160942077637 12.06138515472412 12.28099727630615 C 12.14002704620361 12.20687389373779 12.25887298583984 12.29548931121826 12.27669048309326 12.35470485687256 C 12.29435062408447 12.41397285461426 12.23445987701416 12.50939178466797 12.17233562469482 12.56845188140869 Z M 12.2730541229248 10.54531288146973 C 12.21404552459717 10.63548564910889 12.23617267608643 10.75796794891357 12.28261089324951 10.84107780456543 C 12.36130619049072 10.98189449310303 12.240797996521 10.90273380279541 12.240797996521 10.90273380279541 C 12.240797996521 10.90273380279541 12.11343193054199 10.87224197387695 12.08330631256104 10.58613967895508 C 12.05998229980469 10.36439323425293 12.15940284729004 10.12275314331055 12.25087451934814 10.02774906158447 C 12.3727855682373 9.901164054870605 12.44254493713379 9.638850212097168 12.31829738616943 9.653134346008301 C 12.26536750793457 9.659263610839844 12.31549167633057 9.940692901611328 12.17264842987061 9.972481727600098 C 12.04673862457275 10.00063514709473 11.94695377349854 9.844804763793945 11.95308399200439 9.657859802246094 C 11.95916080474854 9.470916748046875 11.94435787200928 9.416584014892578 11.9068546295166 9.36967945098877 C 11.87662315368652 9.331864356994629 11.7756986618042 9.312957763671875 11.76972389221191 9.271142959594727 C 11.76375007629395 9.229068756103516 11.82862758636475 9.152036666870117 11.93957901000977 9.268959999084473 C 11.99115753173828 9.32344913482666 11.99115753173828 9.32344913482666 12.09213542938232 9.242832183837891 C 12.19290637969971 9.162164688110352 12.30806350708008 9.193954467773438 12.33912658691406 9.263818740844727 C 12.37782382965088 9.351186752319336 12.10512161254883 9.596409797668457 12.13187217712402 9.689545631408691 C 12.16641521453857 9.81010627746582 12.28365135192871 9.39549446105957 12.44000053405762 9.441827774047852 C 12.59650421142578 9.488161087036133 12.46166133880615 9.719204902648926 12.53536891937256 9.760759353637695 C 12.60907554626465 9.802313804626465 12.67145919799805 10.02234554290771 12.58045482635498 10.21884727478027 C 12.489501953125 10.41540050506592 12.35393047332764 10.4213752746582 12.2730541229248 10.54531097412109 Z M 11.99068927764893 5.330467700958252 C 11.92830562591553 5.32070255279541 11.79377365112305 5.195986747741699 11.90856838226318 5.108617782592773 C 11.9529275894165 5.074906349182129 12.03442668914795 4.976213932037354 12.13259887695313 4.922349452972412 C 12.2957010269165 4.832954883575439 12.15773963928223 4.770207405090332 12.33964443206787 4.726523399353027 C 12.56118297576904 4.673385620117188 12.65520000457764 4.609858989715576 12.71768856048584 4.616922855377197 C 12.91341018676758 4.638843059539795 13.01740074157715 4.785738468170166 13.07422637939453 4.82750129699707 C 13.1400899887085 4.875808715820313 12.94265460968018 5.055428028106689 12.75809955596924 5.125136852264404 C 12.491943359375 5.225698947906494 12.31024551391602 5.114955902099609 12.22978496551514 5.214946269989014 C 12.18210029602051 5.274317264556885 12.0247631072998 5.33935022354126 12.18480110168457 5.453313827514648 C 12.25009441375732 5.499855518341064 12.20625400543213 5.516165256500244 12.10314559936523 5.509204387664795 C 11.95043277740479 5.49881649017334 12.04315185546875 5.338675022125244 11.99068927764893 5.330467700958252 Z M 11.8266019821167 4.461509227752686 C 11.85844230651855 4.29991340637207 12.0275182723999 4.234621047973633 12.06969547271729 4.207662105560303 C 12.11182117462158 4.180599689483643 12.06330680847168 4.01173210144043 12.12252140045166 4.020042896270752 C 12.1815299987793 4.028406143188477 12.40176868438721 4.035470485687256 12.54263782501221 3.996617078781128 C 12.7161283493042 3.948725700378418 12.82843112945557 3.737420320510864 12.84240341186523 3.823957920074463 C 12.86956977844238 3.992410182952881 12.74729537963867 4.316327571868896 12.65026473999023 4.450912952423096 C 12.57442665100098 4.556253910064697 12.40852069854736 4.463950634002686 12.28972625732422 4.476572513580322 C 12.17103576660156 4.48924732208252 12.09436798095703 4.519997596740723 12.07494163513184 4.623780250549316 C 12.05889129638672 4.710162162780762 12.07488918304443 4.785323619842529 11.99198818206787 4.764962196350098 C 11.87683010101318 4.73670482635498 11.79475879669189 4.623104572296143 11.82660102844238 4.461509704589844 Z M 12.29944038391113 5.567901611328125 C 12.51755046844482 5.352752208709717 12.69878005981445 5.352648258209229 12.73846435546875 5.352128505706787 C 12.82656002044678 5.351037979125977 12.80448532104492 5.649711608886719 12.86988067626953 5.715939044952393 C 12.89346313476563 5.739781379699707 12.80214691162109 5.850109100341797 12.68906688690186 5.912025451660156 C 12.57588195800781 5.97409725189209 12.44088077545166 5.987758636474609 12.42410373687744 6.016431331634521 C 12.34821510314941 6.147484302520752 12.50373363494873 6.236203670501709 12.41059970855713 6.280458927154541 C 12.29024696350098 6.337596416473389 12.18355464935303 6.303730010986328 12.14854526519775 6.215841293334961 C 12.11343193054199 6.128057479858398 12.08153820037842 5.782998085021973 12.29944038391113 5.567901611328125 Z M 12.30541515350342 6.615493297576904 C 12.33107471466064 6.541993618011475 12.54866504669189 6.43950891494751 12.5818567276001 6.38637113571167 C 12.61520481109619 6.333180904388428 12.55500221252441 6.278121471405029 12.57957077026367 6.210335731506348 C 12.60419178009033 6.142601013183594 12.7300500869751 6.122032165527344 12.80292701721191 6.081671714782715 C 12.83835220336914 6.062141418457031 12.94914817810059 6.053518772125244 13.03423023223877 6.102085590362549 C 13.15510272979736 6.171066284179688 13.10591220855713 6.298223495483398 12.95626354217529 6.441015243530273 C 12.81721115112305 6.573938369750977 12.55079460144043 6.660371780395508 12.57468795776367 6.71101713180542 C 12.59858322143555 6.761661529541016 12.61899662017822 6.852042198181152 12.54393768310547 6.954890727996826 C 12.46872425079346 7.057790756225586 12.4287281036377 7.027144432067871 12.36816215515137 6.937697887420654 C 12.30770015716553 6.84830379486084 12.2607946395874 6.743430137634277 12.30541515350342 6.615493774414063 Z M 12.45823097229004 7.777100563049316 C 12.51786231994629 7.77933406829834 12.55058670043945 7.906179904937744 12.55178070068359 7.996768951416016 C 12.55292320251465 8.087357521057129 12.35522842407227 8.296428680419922 12.25700283050537 8.419639587402344 C 12.20692920684814 8.482491493225098 12.12439155578613 8.234461784362793 12.15747928619385 8.166105270385742 C 12.19056701660156 8.097747802734375 12.33543682098389 7.772530555725098 12.45823097229004 7.777101516723633 Z M 12.61302280426025 9.203670501708984 C 12.82801628112793 9.336541175842285 12.86738872528076 8.984989166259766 12.92764282226563 8.825627326965332 C 12.9878454208374 8.666316986083984 13.06955146789551 8.685796737670898 13.13437747955322 8.821575164794922 C 13.23171806335449 9.025557518005371 13.09110832214355 9.108303070068359 13.06046009063721 9.254470825195313 C 12.96847057342529 9.695728302001953 12.83269119262695 9.41035270690918 12.86136245727539 9.617866516113281 C 12.89169788360596 9.836442947387695 12.95501613616943 9.962458610534668 12.87154388427734 9.96354866027832 C 12.77674770355225 9.964795112609863 12.62673568725586 9.756711006164551 12.63644886016846 9.632098197937012 C 12.64611053466797 9.507434844970703 12.71005249023438 9.397522926330566 12.66590023040771 9.352384567260742 C 12.55957317352295 9.243200302124023 12.38727760314941 9.199307441711426 12.34083938598633 8.945097923278809 C 12.29445457458496 8.690887451171875 12.49168300628662 8.300065994262695 12.65187549591064 8.30120849609375 C 12.70574283599854 8.301624298095703 12.77763175964355 8.384526252746582 12.7786693572998 8.475114822387695 C 12.77981376647949 8.565755844116211 12.56694793701172 8.809734344482422 12.52445888519287 8.925774574279785 C 12.48435974121094 9.035219192504883 12.50695419311523 9.138067245483398 12.61302280426025 9.203671455383301 Z M 12.15316867828369 8.466127395629883 C 12.23534297943115 8.490541458129883 12.2317066192627 8.583935737609863 12.19529438018799 8.724546432495117 C 12.1588306427002 8.865207672119141 12.12932777404785 9.014336585998535 12.16096115112305 9.073397636413574 C 12.19259357452393 9.132404327392578 12.01811695098877 9.104927062988281 11.98570442199707 8.892997741699219 C 11.95318698883057 8.681069374084473 12.0616455078125 8.438961029052734 12.15317058563232 8.466127395629883 Z M 13.62311172485352 6.329442024230957 C 13.465256690979 6.388085842132568 13.38972949981689 6.457014083862305 13.39954853057861 6.558823108673096 C 13.41102886199951 6.677306652069092 13.49164390563965 6.680526256561279 13.5317964553833 6.715692043304443 C 13.56301403045654 6.742857933044434 13.55537891387939 6.790282726287842 13.38557529449463 6.791996479034424 C 13.28345489501953 6.793087482452393 13.26522350311279 6.673826217651367 13.21837043762207 6.561160564422607 C 13.17151737213135 6.448495864868164 13.17281627655029 6.383930206298828 13.31077671051025 6.268876552581787 C 13.44884204864502 6.153874397277832 13.77525234222412 5.834890365600586 13.78579711914063 5.777544975280762 C 13.79634284973145 5.720199584960938 13.68845558166504 5.683059692382813 13.78403186798096 5.636518955230713 C 13.87965965270996 5.589977741241455 14.09667873382568 5.352337837219238 14.16051483154297 5.399501800537109 C 14.21448516845703 5.439601898193359 14.2196798324585 5.602652072906494 14.22040748596191 5.662646293640137 C 14.22196483612061 5.786634922027588 14.13387012481689 5.977474212646484 14.03907299041748 6.092425346374512 C 13.9442253112793 6.207427501678467 13.78086280822754 6.270746231079102 13.62311172485352 6.329442501068115 Z M 11.73892116546631 4.254359722137451 C 11.76510143280029 4.237738132476807 11.81579780578613 4.223660945892334 11.77445125579834 4.372790336608887 C 11.73559665679932 4.513400554656982 11.71191120147705 4.7993483543396 11.71700191497803 4.957359313964844 C 11.71804141998291 4.988837718963623 11.68328952789307 5.000991821289063 11.68168067932129 5.021561622619629 C 11.68033027648926 5.037611961364746 11.658203125 5.05558443069458 11.63280200958252 5.073764324188232 C 11.46455860137939 5.194272994995117 11.45162391662598 5.386826515197754 11.47546672821045 5.38106107711792 C 11.48512744903564 5.378724098205566 11.6183614730835 5.186118125915527 11.68677139282227 5.142589569091797 C 11.73035144805908 5.115007877349854 11.7553882598877 5.196921825408936 11.75398540496826 5.245748996734619 C 11.75060939788818 5.352284908294678 11.73242950439453 5.469104766845703 11.69118595123291 5.575692653656006 C 11.62838649749756 5.73785924911499 11.51135921478271 5.787361145019531 11.47665977478027 5.971032619476318 C 11.46341419219971 6.041155815124512 11.42019748687744 6.260772228240967 11.46871280670166 6.374839782714844 C 11.54751110076904 6.560692310333252 11.54143238067627 6.49498462677002 11.53743267059326 6.325233459472656 C 11.53587627410889 6.264252185821533 11.51187705993652 6.175428867340088 11.54745864868164 6.083333969116211 C 11.5671443939209 6.032845020294189 11.6392936706543 5.916440486907959 11.67908191680908 5.860393047332764 C 11.74536228179932 5.767051219940186 11.78535938262939 5.682487964630127 11.870285987854 5.692876815795898 C 11.99526119232178 5.708044052124023 11.97370338439941 5.984070301055908 11.96045780181885 6.078035831451416 C 11.94685077667236 6.173092365264893 11.92009925842285 6.266849994659424 11.90171146392822 6.337440967559814 C 11.84109210968018 6.571861267089844 11.7121696472168 6.457066059112549 11.66017532348633 6.705822467803955 C 11.6271390914917 6.864249706268311 11.64739608764648 7.030052185058594 11.69414520263672 7.029428482055664 C 11.74510288238525 7.028753280639648 11.75237464904785 6.776257514953613 12.02814102172852 6.582144737243652 C 12.04954242706299 6.567081451416016 12.1684398651123 6.597312927246094 12.13291072845459 6.771426677703857 C 12.12174320220947 6.825967311859131 12.02216720581055 6.809033870697021 12.08299255371094 6.883000373840332 C 12.13659858703613 6.948293685913086 12.00050735473633 7.027610778808594 11.96736812591553 7.147807598114014 C 11.9229040145874 7.309766292572021 11.78177452087402 7.326284885406494 11.81294059753418 7.351528644561768 C 11.93739604949951 7.452402591705322 11.88212966918945 7.814862728118896 11.93635845184326 7.700276374816895 C 12.02725791931152 7.508034229278564 12.15820789337158 7.239227294921875 12.27855968475342 7.237617492675781 C 12.33486557006836 7.236890316009521 12.353928565979 7.413549423217773 12.20334625244141 7.654410362243652 C 12.01027297973633 7.962954044342041 12.00596141815186 8.054997444152832 11.94362926483154 8.052659034729004 C 11.82306957244873 8.048088073730469 11.80410861968994 7.913399696350098 11.81725215911865 7.689056396484375 C 11.82774448394775 7.510527610778809 11.66168212890625 7.474479198455811 11.56569004058838 7.288833141326904 C 11.52107238769531 7.202139377593994 11.55067825317383 6.925282955169678 11.46382999420166 6.626296997070313 C 11.37495517730713 6.320559024810791 11.27324962615967 6.337076663970947 11.23647403717041 6.125252246856689 C 11.19990634918213 5.913427352905273 11.40876960754395 5.655840396881104 11.35615253448486 5.52089262008667 C 11.3297643661499 5.453470230102539 11.3216609954834 5.370983600616455 11.38274574279785 5.273953914642334 C 11.46242713928223 5.147315979003906 11.53571891784668 5.075011253356934 11.53410816192627 4.945983409881592 C 11.53083610534668 4.697695255279541 11.67466831207275 4.295497894287109 11.73892116546631 4.254358768463135 Z M 9.982874870300293 0.5260279774665833 C 10.13200378417969 0.4373608231544495 10.31733894348145 0.4093114733695984 10.49223136901855 0.4397501647472382 C 10.69647407531738 0.4753313064575195 10.79703426361084 0.5876846313476563 10.75906372070313 0.7168674468994141 C 10.71023750305176 0.8828780651092529 10.56032752990723 0.972064733505249 10.35162162780762 1.063848614692688 C 10.22067165374756 1.121349811553955 10.22202301025391 1.183473944664001 10.26934337615967 1.217133283615112 C 10.33967399597168 1.26720654964447 10.42402935028076 1.217444896697998 10.48547840118408 1.242481589317322 C 10.67761707305908 1.320760011672974 10.73558616638184 1.506457209587097 10.77365970611572 1.514820098876953 C 10.84788703918457 1.531130313873291 10.87209320068359 1.449839234352112 10.80539703369141 1.348809361457825 C 10.72441673278809 1.225911736488342 10.60473918914795 1.147529244422913 10.59367656707764 1.060732126235962 C 10.58453464508057 0.990037202835083 10.69278430938721 0.8911372423171997 10.82960319519043 0.9573130011558533 C 10.96195411682129 1.021307229995728 10.86928749084473 1.173241138458252 10.94465732574463 1.274842143058777 C 11.000807762146 1.35057544708252 11.1044340133667 1.485108494758606 11.09757709503174 1.604110479354858 C 11.09056663513184 1.723164558410645 11.03737640380859 1.88096809387207 10.90699768066406 1.976076364517212 C 10.77656841278076 2.071236371994019 10.84902858734131 2.09575366973877 10.86611843109131 2.104012727737427 C 10.88325977325439 2.112271547317505 10.94605922698975 2.015033721923828 11.02272701263428 2.059549331665039 C 11.08864307403564 2.09783148765564 11.12422370910645 2.17901873588562 11.20821666717529 2.286489248275757 C 11.2997407913208 2.403621435165405 11.39677047729492 2.419983625411987 11.41640567779541 2.619341850280762 C 11.43120956420898 2.770133256912231 11.3929271697998 2.882122755050659 11.34846305847168 2.955674409866333 C 11.16837596893311 3.254140377044678 11.34493160247803 3.160642623901367 11.4317798614502 3.260425806045532 C 11.48803424835205 3.325146913528442 11.48741245269775 3.36072826385498 11.4747371673584 3.447784900665283 C 11.45079040527344 3.611406326293945 11.35105991363525 3.699294328689575 11.48330783843994 3.858552217483521 C 11.53322505950928 3.918598413467407 11.53665256500244 4.014745235443115 11.49099445343018 4.041080474853516 C 11.40617179870605 4.089959621429443 11.48637199401855 4.361103534698486 11.43593597412109 4.395697116851807 C 11.38539409637451 4.430343627929688 11.25621032714844 4.268436431884766 11.26602840423584 4.378764152526855 C 11.27600288391113 4.488987922668457 11.38980960845947 4.513764381408691 11.36108589172363 4.599055290222168 C 11.33256912231445 4.684398174285889 11.23673248291016 4.708396434783936 11.21065711975098 4.66673755645752 C 11.18297290802002 4.622637271881104 11.1455717086792 4.49854564666748 11.1002779006958 4.45647144317627 C 11.06589221954346 4.424526214599609 10.9901065826416 4.357519149780273 11.03706359863281 4.497142791748047 C 11.05472373962402 4.549553871154785 11.07653999328613 4.59006929397583 11.10251235961914 4.63640308380127 C 11.128586769104 4.682839870452881 11.12058925628662 4.71353816986084 11.12650966644287 4.844175815582275 C 11.13243103027344 4.975748062133789 11.12552261352539 5.013198852539063 11.07378673553467 5.040261745452881 C 10.98730373382568 5.085556030273438 10.81235694885254 4.865264892578125 10.80300807952881 4.788908004760742 C 10.79350185394287 4.712603569030762 10.81375980377197 4.640142917633057 10.74477863311768 4.556150436401367 C 10.67574596405029 4.472054004669189 10.58375453948975 4.250983715057373 10.6797456741333 4.128034591674805 C 10.78275012969971 3.996306180953979 10.8144359588623 4.102581977844238 10.84570407867432 4.147097110748291 C 10.9432544708252 4.285993576049805 10.96024036407471 4.170731067657471 10.89977836608887 4.065701961517334 C 10.8638858795166 4.003265857696533 10.79729461669922 4.020303249359131 10.79599571228027 3.914183616638184 C 10.79459381103516 3.808011770248413 10.80415058135986 3.564189910888672 10.95073509216309 3.403893232345581 C 11.09731864929199 3.243492126464844 11.13570499420166 2.924508810043335 11.09191608428955 2.823115587234497 C 11.04802417755127 2.721774101257324 10.85754871368408 2.435410976409912 10.80581283569336 2.376611232757568 C 10.75413036346436 2.317863464355469 10.67263126373291 2.255219697952271 10.71247100830078 2.055082559585571 C 10.75251960754395 1.854944944381714 10.80903244018555 1.633355021476746 10.753662109375 1.621356010437012 C 10.69829177856445 1.609357118606567 10.54235744476318 1.373534798622131 10.46631240844727 1.39997386932373 C 10.39016342163086 1.426413059234619 10.01492500305176 1.308086156845093 9.971084594726563 1.202485680580139 C 9.931608200073242 1.107689142227173 9.891508102416992 0.9572094082832336 10.10676097869873 0.8524917960166931 C 10.32196235656738 0.7478260397911072 10.38787841796875 0.9253162741661072 10.39940929412842 0.8275070786476135 C 10.4109411239624 0.7296978235244751 10.3460636138916 0.6413424015045166 10.22747707366943 0.6683528423309326 C 10.10889053344727 0.6954153180122375 10.04089736938477 0.6919870972633362 9.987082481384277 0.7946269512176514 C 9.933115005493164 0.8972668647766113 9.888079643249512 1.025203227996826 9.821435928344727 1.030293583869934 C 9.737859725952148 1.036786556243896 9.720355033874512 0.9273940920829773 9.729081153869629 0.8744118809700012 C 9.748819351196289 0.7550981640815735 9.873432159423828 0.5911652445793152 9.982875823974609 0.5260283946990967 Z M 9.327247619628906 0.7789916396141052 C 9.331767082214355 0.7197243571281433 9.34999942779541 0.5657126307487488 9.425161361694336 0.4634363353252411 C 9.526345252990723 0.3257347047328949 9.665554046630859 0.2605978846549988 9.745338439941406 0.2667790949344635 C 9.870055198669434 0.276544451713562 9.832291603088379 0.4214141964912415 9.814475059509277 0.4839539229869843 C 9.796710968017578 0.5464936494827271 9.726691246032715 0.6192660927772522 9.634542465209961 0.8939940929412842 C 9.596364974975586 1.007697939872742 9.473103523254395 1.105507016181946 9.410460472106934 1.076003313064575 C 9.347713470458984 1.046395659446716 9.312806129455566 0.971649169921875 9.327247619628906 0.7789916396141052 Z M 8.106113433837891 1.14030909538269 C 8.115306854248047 1.138698816299438 8.16008186340332 1.055901288986206 8.153485298156738 1.007178544998169 C 8.146941184997559 0.9584557414054871 8.121644020080566 0.8759177923202515 8.018278121948242 0.7690185904502869 C 7.914961814880371 0.6619635820388794 7.923895835876465 0.5578691959381104 7.925557613372803 0.489875465631485 C 7.926544666290283 0.4496194422245026 7.949139595031738 0.3441745936870575 8.065701484680176 0.3266697525978088 C 8.183249473571777 0.3090609908103943 8.241996765136719 0.3452653884887695 8.293732643127441 0.387443333864212 C 8.39881420135498 0.4731497168540955 8.39195728302002 0.5963591337203979 8.372270584106445 0.7160363793373108 C 8.353155136108398 0.8317661285400391 8.315340995788574 0.9159141182899475 8.28246021270752 0.9949198365211487 C 8.249476432800293 1.073925614356995 8.258306503295898 1.116363286972046 8.258306503295898 1.116363286972046 C 8.258306503295898 1.116363286972046 8.254618644714355 1.116934537887573 8.248904228210449 1.11786961555481 C 8.361725807189941 1.101715087890625 8.48311710357666 1.089456558227539 8.613443374633789 1.086703658103943 C 8.600092887878418 1.077665567398071 8.584095001220703 1.046031951904297 8.577082633972168 0.950767993927002 C 8.573135375976563 0.8967469334602356 8.581758499145508 0.8445439338684082 8.535683631896973 0.7852767109870911 C 8.443693161010742 0.6667421460151672 8.471898078918457 0.461618185043335 8.526853561401367 0.401467889547348 C 8.579264640808105 0.3440186381340027 8.676554679870605 0.3218908309936523 8.71925163269043 0.3420448005199432 C 8.814516067504883 0.3870795965194702 8.812229156494141 0.5712704658508301 8.812229156494141 0.5761012434959412 C 8.809684753417969 0.7104264497756958 8.834929466247559 0.8509849309921265 8.805736541748047 0.9103041887283325 C 8.741326332092285 1.040474057197571 8.692656517028809 1.0278000831604 8.722264289855957 1.086391925811768 L 8.702369689941406 1.086287975311279 C 8.729588508605957 1.086651563644409 8.756911277770996 1.087222933769226 8.78495979309082 1.088521480560303 C 8.855446815490723 1.093352198600769 8.918402671813965 1.098338842391968 8.976785659790039 1.10384476184845 L 8.974344253540039 1.103585124015808 C 8.974344253540039 1.103585124015808 9.023068428039551 1.072315335273743 9.002030372619629 0.9706621766090393 C 8.980941772460938 0.8690091967582703 8.918350219726563 0.8390898704528809 8.896222114562988 0.7193607091903687 C 8.87736701965332 0.617759644985199 8.880431175231934 0.5074841380119324 8.933049201965332 0.400377094745636 C 8.985565185546875 0.2935298085212708 9.037559509277344 0.2752977311611176 9.088100433349609 0.2765963077545166 C 9.171469688415527 0.2786221206188202 9.260552406311035 0.3282279074192047 9.273330688476563 0.5446234941482544 C 9.285952568054199 0.7581104040145874 9.201855659484863 0.7528640627861023 9.167313575744629 0.8913968205451965 C 9.147056579589844 0.9723763465881348 9.139420509338379 1.044941186904907 9.201180458068848 1.100468516349792 C 9.223620414733887 1.12067449092865 9.224087715148926 1.13018012046814 9.214426040649414 1.133764147758484 C 9.28226375579834 1.144724249839783 9.348700523376465 1.157761931419373 9.420018196105957 1.174072027206421 C 10.31172847747803 1.377845525741577 10.47701072692871 1.712723731994629 10.5354471206665 1.822272062301636 C 10.6660327911377 2.066872835159302 10.63294506072998 2.367416858673096 10.70182323455811 2.431670427322388 C 10.81640911102295 2.538517713546753 10.87583255767822 2.695438385009766 10.88762283325195 2.780313491821289 C 10.91863250732422 3.006371021270752 10.56406688690186 3.098933696746826 10.49160671234131 3.252581834793091 C 10.43649578094482 3.369297981262207 10.41275787353516 3.385348796844482 10.35437297821045 3.367532014846802 C 10.15823459625244 3.307797431945801 10.08125495910645 2.869708299636841 9.902050971984863 2.801246881484985 C 9.817279815673828 2.768834114074707 10.30975532531738 2.621055364608765 10.4472484588623 2.45753812789917 C 10.59637832641602 2.280359745025635 10.49955558776855 2.370688915252686 10.20191955566406 2.483301639556885 C 9.979498863220215 2.567501783370972 9.559018135070801 2.735122919082642 9.310521125793457 2.568540811538696 C 9.069816589355469 2.407049179077148 9.33701229095459 1.979296207427979 9.516632080078125 1.858008623123169 C 9.694331169128418 1.738123774528503 9.886260032653809 1.682232737541199 10.15756034851074 1.948909521102905 C 10.41317462921143 2.200003147125244 10.41930389404297 2.215846061706543 10.44750881195068 2.204210758209229 C 10.47566223144531 2.19252347946167 10.19901084899902 1.721917510032654 9.98957633972168 1.648105978965759 C 9.67957878112793 1.538869261741638 9.394099235534668 1.570866465568542 9.032573699951172 2.085156679153442 C 8.824957847595215 2.380506038665771 9.116826057434082 2.469069242477417 9.164977073669434 2.689309120178223 C 9.229334831237793 2.983307838439941 9.057402610778809 2.908457517623901 9.019017219543457 2.955881595611572 C 9.000628471374512 2.978736639022827 8.96141242980957 3.002319097518921 8.809633255004883 3.005331754684448 C 8.657855033874512 3.00621485710144 8.678009033203125 3.019720315933228 8.596406936645508 2.948609828948975 C 8.550383567810059 2.90856146812439 8.302666664123535 2.995254516601563 8.359389305114746 2.699697494506836 C 8.401774406433105 2.478315353393555 8.581238746643066 2.432293653488159 8.453770637512207 2.096843957901001 C 8.276538848876953 1.630341649055481 7.891067981719971 1.475550532341003 7.492455005645752 1.650547504425049 C 7.289149284362793 1.73978590965271 6.898431777954102 2.136684656143188 6.926897048950195 2.147644758224487 C 6.955413341522217 2.158604621887207 7.131449699401855 2.059444904327393 7.359428405761719 1.877279758453369 C 7.594264030456543 1.689712524414063 7.80738639831543 1.759732127189636 7.986331462860107 1.877747297286987 C 8.13790225982666 1.977686047554016 8.211350440979004 2.338743686676025 7.974852561950684 2.50641655921936 C 7.730771064758301 2.679387807846069 7.547723770141602 2.579708576202393 7.317354202270508 2.520493030548096 C 7.121788024902344 2.470264196395874 6.93281888961792 2.38159704208374 6.819478034973145 2.400920152664185 C 6.675646781921387 2.425489187240601 6.785194873809814 2.465173959732056 6.836099624633789 2.464550495147705 C 6.891108512878418 2.46387505531311 6.963724613189697 2.479821681976318 7.053431034088135 2.522571086883545 C 7.115036010742188 2.551815032958984 7.19539213180542 2.660844087600708 7.314965724945068 2.710345983505249 C 7.484975814819336 2.78057336807251 7.694774150848389 2.737200736999512 7.655505657196045 2.773872375488281 C 7.560812950134277 2.862435817718506 7.40493106842041 2.765769720077515 7.270658016204834 3.224740505218506 C 7.247128009796143 3.305148601531982 7.176069259643555 3.318705797195435 7.113529682159424 3.372519016265869 C 7.113996982574463 3.374284744262695 7.113010883331299 3.387011051177979 7.087038993835449 3.477755784988403 C 7.055561065673828 3.587719917297363 7.03244686126709 3.525180339813232 7.033797740936279 3.626833200454712 C 7.03504467010498 3.728538274765015 7.167447566986084 3.67228364944458 7.147553443908691 3.888886690139771 C 7.136593818664551 4.008719921112061 7.201159000396729 4.09343957901001 7.064652442932129 4.047054290771484 C 6.980712413787842 4.018537044525146 6.958272457122803 3.843592405319214 6.833193302154541 3.880160570144653 C 6.782393455505371 3.894964694976807 6.823012828826904 3.967996597290039 6.908303260803223 4.000928401947021 C 6.979465484619141 4.028250217437744 7.005697250366211 4.120085716247559 7.010787963867188 4.149641990661621 C 7.043459892272949 4.341675758361816 6.976089954376221 4.421875953674316 6.982115268707275 4.561967372894287 C 6.98814058303833 4.702058792114258 7.022423267364502 4.727043151855469 7.163033485412598 4.759195804595947 C 7.303540229797363 4.791349411010742 7.439579963684082 4.802360534667969 7.53863525390625 4.91149377822876 C 7.637743473052979 5.020678520202637 7.558062076568604 5.151576042175293 7.517234802246094 5.226010322570801 C 7.463265895843506 5.324442863464355 7.415789127349854 5.265591144561768 7.342601776123047 5.185806274414063 C 7.269413471221924 5.106072902679443 7.361457347869873 5.002914428710938 7.088807106018066 4.934245109558105 C 6.896668434143066 4.885937690734863 6.892928600311279 4.894300937652588 6.815064907073975 4.844382286071777 C 6.737254619598389 4.794413566589355 6.759485721588135 4.653958320617676 6.753720283508301 4.529502868652344 C 6.744890689849854 4.338715553283691 6.856931686401367 4.444263935089111 6.838284492492676 4.281317710876465 C 6.819117069244385 4.113852500915527 6.743643760681152 4.187040328979492 6.716062545776367 4.030276298522949 C 6.688739776611328 3.87413501739502 6.707283020019531 3.852006912231445 6.831479549407959 3.752743244171143 C 6.938379287719727 3.667244434356689 6.935678005218506 3.602731227874756 6.935678005218506 3.602731227874756 L 6.923523902893066 3.318393468856812 C 6.72400951385498 3.105737924575806 6.448346614837646 3.018680810928345 6.425491809844971 2.697775602340698 C 6.417336940765381 2.583292484283447 6.523092746734619 2.454369306564331 6.671910762786865 2.331055879592896 C 6.744423389434814 2.271009683609009 6.630148887634277 1.974413394927979 6.729100227355957 1.740980386734009 C 6.818599224090576 1.529779076576233 7.394025325775146 1.265232086181641 8.071938514709473 1.1461261510849 C 8.085027694702148 1.143840670585632 8.09858512878418 1.141607046127319 8.111934661865234 1.139269709587097 C 8.107259750366211 1.14015257358551 8.104766845703125 1.14051616191864 8.106117248535156 1.140308499336243 Z M 7.449549674987793 0.4598522186279297 C 7.504713535308838 0.3478105664253235 7.694098949432373 0.3190859854221344 7.811334609985352 0.5210413932800293 C 7.901248455047607 0.6759881377220154 7.875744342803955 0.794834315776825 7.854498863220215 0.9027204513549805 C 7.833202362060547 1.010606646537781 7.785933494567871 1.065250873565674 7.740171432495117 1.097455978393555 C 7.726562976837158 1.107065320014954 7.686669826507568 1.114389419555664 7.694305896759033 1.049148678779602 C 7.700902938842773 0.9926342964172363 7.561539649963379 0.855504035949707 7.503881931304932 0.77410888671875 C 7.446120738983154 0.6927657723426819 7.394385814666748 0.5718938112258911 7.449549198150635 0.4598521590232849 Z M 5.672311305999756 3.103141307830811 C 5.675635814666748 2.995410680770874 5.742226600646973 2.925962924957275 5.83910083770752 2.970062494277954 C 5.935922622680664 3.014110326766968 5.989528179168701 3.173108816146851 5.977477550506592 3.291435480117798 C 5.963660717010498 3.427526950836182 6.034667015075684 3.529803037643433 6.110296726226807 3.553333520889282 C 6.186705112457275 3.577071666717529 6.242388725280762 3.509909391403198 6.252205371856689 3.387998104095459 C 6.257607936859131 3.320056676864624 6.203275203704834 3.152435302734375 6.094194889068604 2.995099306106567 C 5.9936842918396 2.850073575973511 5.855151653289795 2.886485815048218 5.804402828216553 2.687699317932129 C 5.719371318817139 2.354742765426636 5.837750434875488 2.316460609436035 5.851567268371582 2.182862758636475 C 5.863306045532227 2.069470405578613 5.913015842437744 1.887980580329895 6.020331382751465 1.879202246665955 C 6.102349758148193 1.872397541999817 6.21381950378418 1.950260639190674 6.200729846954346 2.141567707061768 C 6.174083232879639 2.530622720718384 6.229038715362549 2.251635313034058 6.253868103027344 2.200315475463867 C 6.296928882598877 2.111336469650269 6.338951587677002 2.051705837249756 6.351624965667725 1.986621022224426 C 6.37157154083252 1.884448528289795 6.339834213256836 1.753187894821167 6.242700099945068 1.668156743049622 C 6.15824031829834 1.594189524650574 6.172005653381348 1.478927373886108 6.174446582794189 1.419919729232788 C 6.177667140960693 1.340602517127991 6.225506782531738 1.327045321464539 6.298642635345459 1.282425999641418 C 6.381544589996338 1.231781363487244 6.369441986083984 1.173864603042603 6.311057090759277 1.15859317779541 C 6.276203632354736 1.149399399757385 6.231843948364258 1.185136318206787 6.184419631958008 1.204563140869141 C 6.09144115447998 1.2425856590271 6.11154317855835 1.011749625205994 6.108582496643066 0.9210047721862793 C 6.103855133056641 0.7781088352203369 6.193250179290771 0.7138550281524658 6.296305179595947 0.6637297868728638 C 6.437071800231934 0.5954763293266296 6.473172187805176 0.6406669020652771 6.556800842285156 0.6618078351020813 C 6.642039775848389 0.6833643317222595 6.719590663909912 0.6639375686645508 6.779637336730957 0.5994759798049927 C 6.831112861633301 0.544208288192749 6.853085994720459 0.4734615981578827 6.956140518188477 0.4570475518703461 C 7.029484272003174 0.4454122483730316 7.088699817657471 0.4735654592514038 7.229465961456299 0.5739198923110962 C 7.389502048492432 0.6878834366798401 7.427992820739746 0.8297924399375916 7.483416080474854 0.9443273544311523 C 7.535826683044434 1.052629113197327 7.542163372039795 1.106026768684387 7.517387390136719 1.161865830421448 C 7.507309913635254 1.184616923332214 7.427888870239258 1.208406925201416 7.385502815246582 1.142335176467896 C 7.356310844421387 1.09704065322876 7.306444644927979 1.021774888038635 7.240009784698486 0.9475478529930115 C 7.181262493133545 0.8818396329879761 7.153213024139404 0.7934321761131287 7.047975540161133 0.7730703949928284 C 6.917441844940186 0.7476181983947754 6.911364555358887 0.7139070630073547 7.01244592666626 0.8136900663375854 C 7.034107208251953 0.8350386619567871 7.201051712036133 0.9990236163139343 7.241983413696289 1.104001045227051 C 7.282966613769531 1.208978295326233 7.209155559539795 1.191421508789063 7.184274673461914 1.191733121871948 C 7.159394264221191 1.192044734954834 7.055039882659912 1.097144484519958 7.003148555755615 1.018606066703796 C 6.95115327835083 0.9399639964103699 6.865654468536377 0.8957603573799133 6.792103290557861 0.9024090766906738 C 6.718499183654785 0.909005880355835 6.646297931671143 1.017515301704407 6.571655750274658 1.024164199829102 C 6.496909618377686 1.030761003494263 6.453588962554932 0.9973094463348389 6.403878688812256 1.032007575035095 C 6.354169368743896 1.066601753234863 6.53986644744873 1.103793144226074 6.573473453521729 1.160255432128906 C 6.606976985931396 1.216665863990784 6.580849647521973 1.205238223075867 6.491454601287842 1.296970129013062 C 6.401957035064697 1.388753890991211 6.571707725524902 1.375248670578003 6.64515495300293 1.362938165664673 C 6.718602657318115 1.350731372833252 6.773819446563721 1.236715912818909 6.784623146057129 1.196979403495789 C 6.795426368713379 1.157138824462891 6.742704391479492 1.021982550621033 6.776363849639893 0.9932059049606323 C 6.809919357299805 0.9644292593002319 6.907936096191406 1.099118232727051 6.931311130523682 1.155684471130371 C 6.954685211181641 1.212198734283447 6.973696231842041 1.370002508163452 6.934479236602783 1.398882865905762 C 6.895158290863037 1.427711486816406 6.559657096862793 1.754798412322998 6.488390445709229 1.936911225318909 C 6.41712474822998 2.119076251983643 6.487143993377686 2.276672124862671 6.493948936462402 2.368092060089111 C 6.500805854797363 2.459512233734131 6.355779647827148 2.629470825195313 6.31718635559082 2.714865446090698 C 6.278696060180664 2.800364017486572 6.265190601348877 3.07228684425354 6.311991691589355 3.190613985061646 C 6.358792781829834 3.308888912200928 6.46501636505127 3.483054399490356 6.506675243377686 3.578837871551514 C 6.553320407867432 3.685997009277344 6.514674186706543 3.779286861419678 6.452706336975098 3.840735912322998 C 6.326796054840088 3.965607404708862 6.352871417999268 3.725525856018066 6.29349946975708 3.869253158569336 C 6.240933418273926 3.996358156204224 6.040484428405762 4.149798393249512 5.915560722351074 4.161277770996094 C 5.748406887054443 4.176496982574463 5.718020439147949 4.110009670257568 5.677971839904785 4.065183162689209 C 5.637924194335938 4.020407676696777 5.715994358062744 3.956413984298706 5.788922786712646 3.90452241897583 C 5.861903667449951 3.852631092071533 5.849956512451172 3.782248020172119 5.853800773620605 3.703553676605225 C 5.857384204864502 3.6293785572052 5.765653133392334 3.571410179138184 5.69854211807251 3.49043083190918 C 5.642443656921387 3.422748565673828 5.669142246246338 3.206041574478149 5.672311305999756 3.10314154624939 Z M 5.650286674499512 5.67485237121582 C 5.751887798309326 5.648050308227539 5.77230167388916 6.467455387115479 5.617302894592285 6.535604953765869 C 5.560009956359863 6.560849189758301 5.561723709106445 6.705718517303467 5.576112270355225 6.839473247528076 C 5.59055233001709 6.973175048828125 5.479393482208252 6.912920475006104 5.399245262145996 7.083398342132568 C 5.336341857910156 7.217204570770264 5.339406490325928 7.375319957733154 5.263984680175781 7.327584266662598 C 5.188510894775391 7.279951572418213 5.227779865264893 7.156795024871826 5.230585098266602 7.029741287231445 C 5.233441829681396 6.902636051177979 5.197653293609619 6.797607421875 5.087013721466064 6.59232759475708 C 5.00167179107666 6.433900833129883 5.099117279052734 6.401279926300049 5.209028720855713 6.413071155548096 C 5.32408332824707 6.425382137298584 5.392595767974854 6.785661220550537 5.439449310302734 6.682605266571045 C 5.46412181854248 6.628168106079102 5.466563701629639 6.527658462524414 5.451344013214111 6.378165245056152 C 5.445266723632813 6.318690299987793 5.389894962310791 6.312145233154297 5.297332286834717 6.201817989349365 C 5.244350433349609 6.138758659362793 5.255050659179688 5.977215766906738 5.275100708007813 5.865121841430664 C 5.295150279998779 5.752664089202881 5.206067562103271 5.8036208152771 5.165136814117432 5.587692737579346 C 5.147787570953369 5.496324062347412 5.264763832092285 5.439809799194336 5.30102014541626 5.47352123260498 C 5.340237617492676 5.510037899017334 5.314109802246094 5.583277225494385 5.404803276062012 5.635584354400635 C 5.503339290618896 5.692358493804932 5.534609317779541 5.722485542297363 5.533154487609863 5.811256408691406 C 5.530765056610107 5.952438831329346 5.587799072265625 5.985682487487793 5.587799072265625 5.985682487487793 C 5.633872985839844 5.939816474914551 5.56847620010376 5.696462154388428 5.650286674499512 5.674854278564453 Z M 5.60042142868042 5.451807975769043 C 5.602395534515381 5.48920726776123 5.469420433044434 5.481831550598145 5.42890453338623 5.303770065307617 C 5.384493350982666 5.108774662017822 5.236818790435791 5.222063541412354 5.200302124023438 5.027535438537598 C 5.172305107116699 4.878665924072266 5.269491195678711 4.792128562927246 5.322836399078369 4.736237049102783 C 5.385324954986572 4.670789241790771 5.513156890869141 4.916480541229248 5.560685157775879 5.077504634857178 C 5.619328498840332 5.276135921478271 5.597253322601318 5.392592906951904 5.60042142868042 5.451807975769043 Z M 5.562191009521484 4.605807781219482 C 5.537673950195313 4.680398464202881 5.424593448638916 4.715459823608398 5.420542240142822 4.654374599456787 C 5.416906356811523 4.600353717803955 5.450513362884521 4.511686325073242 5.353794574737549 4.421616554260254 C 5.284970283508301 4.357570648193359 5.281074047088623 4.247555255889893 5.208821296691895 4.215401649475098 C 5.060730934143066 4.1493821144104 5.031486988067627 4.073441028594971 5.06956148147583 4.028198719024658 C 5.109297752380371 3.980982542037964 5.266685962677002 4.03697681427002 5.37306547164917 3.939323902130127 C 5.489782810211182 3.832164764404297 5.435606002807617 3.71383810043335 5.464953422546387 3.655765771865845 C 5.489782333374023 3.606575489044189 5.519805431365967 3.607717990875244 5.53507661819458 3.657012224197388 C 5.560009956359863 3.737939834594727 5.585097789764404 3.888886690139771 5.539284229278564 3.981813430786133 C 5.492379188537598 4.076661586761475 5.417996883392334 4.129851818084717 5.507235527038574 4.242672443389893 C 5.584578990936279 4.340482234954834 5.593876838684082 4.509453296661377 5.562191009521484 4.605807781219482 Z M 5.007384777069092 2.442786693572998 C 5.15365743637085 2.426476716995239 5.282944679260254 2.487821340560913 5.359819889068604 2.57835841178894 C 5.534453868865967 2.784209966659546 5.552997589111328 2.992969512939453 5.502248764038086 2.920508623123169 C 5.424385070800781 2.809246301651001 5.290579319000244 2.787378072738647 5.164097785949707 2.71683931350708 C 5.093558788299561 2.677362442016602 5.119010925292969 2.600382089614868 5.093974113464355 2.55202317237854 C 5.069093704223633 2.503923654556274 4.976790428161621 2.44621467590332 5.007384777069092 2.44278621673584 Z M 4.265219688415527 2.338744163513184 C 4.409777641296387 2.263114929199219 4.955857276916504 2.545426607131958 4.871397495269775 2.580436229705811 C 4.786937713623047 2.615498304367065 4.404324054718018 2.665519237518311 4.310877799987793 2.587708234786987 C 4.255402565002441 2.541478872299194 4.209120750427246 2.368040323257446 4.265219688415527 2.338744163513184 Z M 4.193642139434814 3.37693452835083 C 4.303242206573486 3.475366830825806 4.277478218078613 3.702722787857056 4.498756885528564 3.734563827514648 C 4.557037353515625 3.742926836013794 4.663780212402344 3.701372385025024 4.71458101272583 3.756743907928467 C 4.751253128051758 3.796584129333496 5.022604465484619 3.81808876991272 5.082079410552979 3.76115870475769 C 5.134490489959717 3.710981607437134 5.051537036895752 3.542166233062744 4.891915321350098 3.510220766067505 C 4.73006010055542 3.47786021232605 4.492315292358398 3.537179470062256 4.332329750061035 3.424047470092773 C 4.17234468460083 3.310914754867554 4.201641082763672 3.11571192741394 4.248077869415283 3.047146797180176 C 4.294619560241699 2.978633880615234 4.16148853302002 2.890018224716187 4.310565948486328 2.780002593994141 C 4.515274047851563 2.629003524780273 4.83316707611084 2.742603302001953 5.005878448486328 2.810441255569458 C 5.178174495697021 2.878071546554565 5.458720207214355 3.124074459075928 5.505416393280029 3.17347264289856 C 5.61112117767334 3.285358428955078 5.571072578430176 3.469289541244507 5.534868717193604 3.540243864059448 C 5.49009370803833 3.627871990203857 5.361690044403076 3.55307412147522 5.312655448913574 3.37532377243042 C 5.274736404418945 3.237725973129272 5.129815101623535 3.038368225097656 5.042031288146973 2.966945886611938 C 4.98930835723877 2.924092769622803 4.865216255187988 2.924612045288086 4.863450050354004 2.954323530197144 C 4.861320018768311 2.989489316940308 5.027486324310303 3.11446475982666 5.096103668212891 3.210352182388306 C 5.267879486083984 3.450537443161011 5.386622905731201 3.779286861419678 5.174901962280273 3.902028560638428 C 5.097090721130371 3.94716739654541 4.820284366607666 3.871382236480713 4.890979290008545 3.932882785797119 C 4.970348358154297 4.001915454864502 4.920691013336182 4.100296020507813 4.985360145568848 4.148862838745117 C 5.133814334869385 4.260385036468506 5.210690498352051 4.355597019195557 5.176667213439941 4.551163196563721 C 5.15142297744751 4.696240901947021 5.039173126220703 4.757274627685547 4.893057346343994 4.757845401763916 C 4.818674564361572 4.758209228515625 4.96245288848877 4.373620986938477 4.812077522277832 4.388580799102783 C 4.670584201812744 4.402657508850098 4.414244174957275 4.337988376617432 4.352431774139404 4.162783622741699 C 4.301734924316406 4.019004344940186 4.232962131500244 4.062169075012207 4.180862903594971 4.029029846191406 C 4.130011081695557 3.996669054031372 4.109960079193115 3.944414377212524 4.153385162353516 3.876472473144531 C 4.209587574005127 3.788740396499634 4.240390300750732 3.59343409538269 4.144191265106201 3.492300033569336 C 4.062432289123535 3.4062819480896 4.095156669616699 3.288474798202515 4.193641185760498 3.376934051513672 Z M 2.515874624252319 2.362326383590698 C 2.686092615127563 2.389388799667358 2.721050262451172 2.633625984191895 2.754346132278442 2.416139602661133 C 2.767228126525879 2.332251310348511 2.622825622558594 2.259063243865967 2.567090749740601 2.221508026123047 C 2.525847911834717 2.193770408630371 2.565532445907593 2.121569395065308 2.614619016647339 2.116894483566284 C 2.753203392028809 2.10380482673645 2.835169792175293 2.294852018356323 2.925187349319458 2.262959003448486 C 3.191968202590942 2.168473958969116 3.274609804153442 1.921535730361938 3.614682197570801 1.944702625274658 C 3.954755067825317 1.967817187309265 3.909668445587158 2.193354845046997 3.919589519500732 2.317291498184204 C 3.924939632415771 2.383103609085083 4.097183704376221 2.31479811668396 4.091261863708496 2.671181201934814 C 4.086431503295898 2.957959890365601 4.187824726104736 2.752731800079346 4.152035713195801 2.997436761856079 C 4.147152900695801 3.030576467514038 4.073393821716309 3.020291805267334 4.087677955627441 3.054886102676392 C 4.178215503692627 3.274554252624512 4.018385887145996 3.302811145782471 3.951690196990967 3.321770906448364 C 3.871490001678467 3.344573497772217 3.848011493682861 3.404828310012817 3.882346153259277 3.434071779251099 C 4.00597095489502 3.539568662643433 4.08560037612915 3.63389778137207 4.000413417816162 3.697995662689209 C 3.937354326248169 3.745575666427612 3.638524532318115 3.65877890586853 3.788952350616455 3.766561031341553 C 3.983947277069092 3.9063401222229 4.119103908538818 4.332222461700439 3.928160429000854 4.456522941589355 C 3.806405305862427 4.535736560821533 3.689325332641602 4.296381950378418 3.50632905960083 4.266878128051758 C 3.434906959533691 4.255294322967529 3.435270309448242 4.333832740783691 3.523366212844849 4.411280155181885 C 3.627097368240356 4.50249195098877 3.861569166183472 4.623468399047852 3.873152256011963 4.859187126159668 C 3.882658004760742 5.05303955078125 3.760903120040894 5.304341316223145 3.6620032787323 5.337013244628906 C 3.501290559768677 5.390047550201416 3.533443450927734 5.256397247314453 3.584295988082886 5.16435432434082 C 3.612708568572998 5.112825870513916 3.671976089477539 5.067635536193848 3.61187744140625 5.01460075378418 C 3.581490755081177 4.98779821395874 3.596450567245483 4.912896156311035 3.537962675094604 4.882457256317139 C 3.403117656707764 4.812334060668945 3.260169744491577 4.911545276641846 3.096808195114136 4.75862455368042 C 3.020399808883667 4.687098503112793 3.012763977050781 4.515114307403564 3.085016965866089 4.503998756408691 C 3.140077352523804 4.495479583740234 3.204746246337891 4.600301265716553 3.294192552566528 4.586224555969238 C 3.38514518737793 4.571940422058105 3.404468297958374 4.318820476531982 3.329670190811157 4.271240711212158 C 3.158205032348633 4.162056446075439 3.07649827003479 4.190832614898682 2.981026887893677 4.17618465423584 C 2.91474723815918 4.166055202484131 2.861660957336426 4.066220760345459 2.909552812576294 4.066688060760498 C 3.045436382293701 4.068142414093018 3.41174054145813 3.988046169281006 3.522743225097656 3.703033447265625 C 3.57728385925293 3.562994241714478 3.517756462097168 3.216896533966064 3.391014814376831 3.037017107009888 C 3.314450263977051 2.928247451782227 3.249781131744385 2.865656137466431 3.144076347351074 2.823633670806885 C 3.06455135345459 2.792000293731689 2.930330038070679 2.811427354812622 2.963573694229126 2.817452669143677 C 3.450957298278809 2.906691312789917 3.52082085609436 3.549229383468628 3.264325141906738 3.745730876922607 C 2.918694734573364 4.010537147521973 2.734088182449341 3.867641448974609 2.836104869842529 3.804322481155396 C 3.04263162612915 3.676386594772339 3.125325202941895 3.509700536727905 3.121637344360352 3.386595010757446 C 3.118468523025513 3.281929016113281 2.912201881408691 3.122930765151978 2.661263942718506 3.086778163909912 C 2.431519269943237 3.053638458251953 2.243121147155762 2.982320547103882 2.201722145080566 2.736992359161377 C 2.160427093505859 2.492962837219238 2.345656871795654 2.335315227508545 2.515875101089478 2.362325429916382 Z M 0.7346880435943604 5.812190532684326 C 0.7120408415794373 5.806424617767334 0.6729794144630432 5.677865505218506 0.7870988249778748 5.526658058166504 C 0.8558716773986816 5.435550212860107 0.9651084542274475 5.323559761047363 0.8790903687477112 5.354207038879395 C 0.790371298789978 5.385788440704346 0.6706939339637756 5.439186096191406 0.6424368619918823 5.505828857421875 C 0.5605742335319519 5.699265956878662 0.5122150778770447 5.595327377319336 0.553250253200531 5.484323978424072 C 0.5943374037742615 5.373425483703613 0.7400382161140442 5.209596157073975 0.819199800491333 5.157497406005859 C 0.8990885615348816 5.104774475097656 1.049568176269531 5.095580577850342 1.167791128158569 5.050130367279053 C 1.286169767379761 5.004679679870605 1.485735893249512 4.815450668334961 1.562663912773132 4.800750732421875 C 1.639539957046509 4.786050796508789 1.655850172042847 4.830202579498291 1.639643907546997 4.889885425567627 C 1.623385548591614 4.949516296386719 1.585934638977051 4.968838691711426 1.50230598449707 5.068257808685303 C 1.418625235557556 5.167730331420898 1.263055205345154 5.372645854949951 1.230486750602722 5.437782764434814 C 1.199580550193787 5.4995436668396 1.114705085754395 5.509621143341064 1.01481831073761 5.510919094085693 C 0.9468764066696167 5.511801719665527 0.9147754907608032 5.548785209655762 0.8591961860656738 5.630440711975098 C 0.787254810333252 5.736301422119141 0.7558290958404541 5.817592144012451 0.7346882224082947 5.81218957901001 Z M 1.681302428245544 5.589821338653564 C 1.621255993843079 5.643063068389893 1.457634687423706 5.756974697113037 1.381122350692749 5.789439678192139 C 1.328971266746521 5.811619281768799 1.301493167877197 5.73521089553833 1.312193512916565 5.715524673461914 C 1.350891351699829 5.64425802230835 1.563598990440369 5.550812721252441 1.61943793296814 5.527229785919189 C 1.664628624916077 5.508218765258789 1.696158170700073 5.576680183410645 1.681302428245544 5.589822292327881 Z M 1.734959840774536 5.916440963745117 C 1.746751070022583 5.950255870819092 1.705715775489807 6.005004405975342 1.645253777503967 5.985836505889893 C 1.589466691017151 5.968176364898682 1.536224961280823 5.935036659240723 1.537263631820679 5.89561128616333 C 1.538094878196716 5.867146968841553 1.578558683395386 5.822423458099365 1.608997464179993 5.816137790679932 C 1.641409993171692 5.809489727020264 1.723220705986023 5.882625102996826 1.734959840774536 5.916440963745117 Z M 1.309960126876831 5.615013599395752 C 1.259575009346008 5.696149349212646 1.172102451324463 5.603482246398926 1.225396275520325 5.560214042663574 C 1.277599215507507 5.517879962921143 1.435662746429443 5.365167140960693 1.501215100288391 5.354414463043213 C 1.521005511283875 5.351142406463623 1.571702241897583 5.377633571624756 1.559755206108093 5.39498233795166 C 1.524329900741577 5.446094036102295 1.381381988525391 5.500219345092773 1.309960126876831 5.615013599395752 Z M 0.9088021516799927 5.8691725730896 C 0.900958776473999 5.805386066436768 0.9598624110221863 5.589768886566162 0.9943007826805115 5.567070007324219 C 1.018610239028931 5.551071643829346 1.103589415550232 5.549513339996338 1.10722541809082 5.557512283325195 C 1.129976511001587 5.60753345489502 1.07211172580719 5.664619922637939 1.055438041687012 5.701499938964844 C 1.034764409065247 5.747572898864746 0.9213724136352539 5.97144889831543 0.9088021516799927 5.8691725730896 Z M 1.171738862991333 6.4842848777771 C 1.119068503379822 6.426939487457275 1.346164584159851 6.382943153381348 1.191165685653687 6.343881607055664 C 1.068735480308533 6.312975406646729 0.9463571906089783 6.078035831451416 1.010247468948364 6.034715175628662 C 1.061515331268311 5.999964714050293 1.1465984582901 6.326065063476563 1.250692844390869 6.203531265258789 C 1.301337480545044 6.143795967102051 1.11818540096283 6.026351928710938 1.103433728218079 5.924595355987549 C 1.092681288719177 5.850523948669434 1.115744113922119 5.763051986694336 1.20950174331665 5.790685653686523 C 1.303311347961426 5.818423271179199 1.403561949729919 6.018923759460449 1.383771538734436 6.135329246520996 C 1.350631594657898 6.33079195022583 1.481996178627014 6.183999538421631 1.44854474067688 6.213191986083984 C 1.428130984306335 6.230905055999756 1.400185585021973 5.947398662567139 1.460803270339966 5.986251831054688 C 1.491138339042664 6.005730628967285 1.540848016738892 6.187376022338867 1.541471242904663 6.229086399078369 C 1.542250275611877 6.278224945068359 1.66016161441803 6.128992557525635 1.715636968612671 6.103799819946289 C 1.826587915420532 6.053414344787598 1.977067470550537 6.032221794128418 2.043918371200562 5.946411609649658 C 2.110821008682251 5.86060094833374 2.121885299682617 5.736456871032715 2.061578989028931 5.670956134796143 C 2.012752532958984 5.617870330810547 1.860298991203308 5.541098117828369 1.799889206886292 5.465416431427002 C 1.739375114440918 5.389734745025635 1.823782920837402 5.346155166625977 1.755321741104126 5.304600238800049 C 1.68686044216156 5.262993335723877 1.669251561164856 5.159263610839844 1.762178182601929 5.177079677581787 C 1.855832099914551 5.195104122161865 2.054670572280884 5.46209192276001 2.106717824935913 5.552681922912598 C 2.158920764923096 5.643218517303467 2.349136829376221 5.908441066741943 2.324723482131958 5.985213279724121 C 2.300206184387207 6.061985015869141 1.969327807426453 6.091696739196777 1.884868025779724 6.128784656524658 C 1.800460338592529 6.165872097015381 1.860714316368103 6.229034900665283 1.759321093559265 6.26944637298584 C 1.681302428245544 6.300508499145508 1.625671029090881 6.3399338722229 1.582817792892456 6.364243030548096 C 1.555495738983154 6.379826068878174 1.583908677101135 6.44756031036377 1.447557687759399 6.461532592773438 C 1.434104204177856 6.462935447692871 1.409223437309265 6.467091083526611 1.392653584480286 6.469947814941406 C 1.44475269317627 6.465688705444336 1.240719556808472 6.559445858001709 1.171738862991333 6.484283924102783 Z M 1.807628393173218 5.64940071105957 C 1.834535360336304 5.637921333312988 1.923410058021545 5.715524673461914 1.938317775726318 5.74835205078125 C 1.959926128387451 5.795984268188477 1.988858461380005 5.871976852416992 1.940655112266541 5.89561128616333 C 1.906840085983276 5.912233829498291 1.777033686637878 5.781231880187988 1.765190839767456 5.738898754119873 C 1.755061984062195 5.702850341796875 1.78596818447113 5.658698558807373 1.807628393173218 5.64940071105957 Z M 1.442103743553162 6.724262714385986 C 1.356397390365601 6.666138172149658 1.860974311828613 6.250332355499268 1.915203094482422 6.22913932800293 C 2.000182151794434 6.196051597595215 2.119080305099487 6.198025703430176 2.174555540084839 6.199635982513428 C 2.206812381744385 6.200570583343506 2.297297477722168 6.207842826843262 2.299583196640015 6.231996536254883 C 2.30379056930542 6.277239322662354 2.236108303070068 6.319313049316406 2.131806373596191 6.306586742401123 C 2.024751424789429 6.293549060821533 1.937019228935242 6.372139453887939 1.885491609573364 6.404032230377197 C 1.776930212974548 6.47124719619751 1.50339686870575 6.765868663787842 1.442103862762451 6.724262714385986 Z M 2.280416250228882 6.789244174957275 C 2.149207353591919 7.125213623046875 2.208786249160767 6.748364448547363 2.178503274917603 6.756675720214844 C 2.088174104690552 6.781556606292725 2.065059185028076 6.958059787750244 2.009376049041748 7.016339778900146 C 1.953693032264709 7.074515819549561 1.766489624977112 7.094722270965576 1.681925654411316 7.075554847717285 C 1.609413027763367 7.059140682220459 1.663122296333313 6.821656227111816 1.685094475746155 6.773661136627197 C 1.780098438262939 6.565628528594971 1.816978454589844 6.513580322265625 1.889750838279724 6.513580322265625 C 2.029685735702515 6.513580322265625 2.14603853225708 6.503607749938965 2.220629215240479 6.476493358612061 C 2.264988899230957 6.460339546203613 2.279013395309448 6.377177715301514 2.35204553604126 6.315053462982178 C 2.453126907348633 6.229087829589844 2.288934469223022 6.169508457183838 2.326853036880493 6.149406433105469 C 2.42481803894043 6.097514629364014 2.433284997940063 6.016379833221436 2.462425231933594 5.904233932495117 C 2.492188692092896 5.789491176605225 2.436713218688965 5.666126251220703 2.339579105377197 5.600054264068604 C 2.25221061706543 5.540579319000244 2.030412912368774 5.336078643798828 2.017790555953979 5.236140251159668 C 2.005168437957764 5.136200904846191 1.726077198982239 4.87066650390625 1.865077614784241 4.949776172637939 C 1.983248591423035 5.016990661621094 2.197878122329712 5.152407169342041 2.419415950775146 4.981773376464844 C 2.549793481826782 4.881367206573486 2.594152927398682 4.820852756500244 2.615605592727661 4.727822780609131 C 2.637110233306885 4.634740352630615 2.552234888076782 4.612144947052002 2.528289318084717 4.646323680877686 C 2.464866399765015 4.736964225769043 2.402222633361816 4.872588634490967 2.106042385101318 4.832955837249756 C 1.959458827972412 4.813321113586426 1.963770031929016 4.800855159759521 2.065526723861694 4.765533447265625 C 2.150090456008911 4.736185550689697 2.196060419082642 4.70439624786377 2.143545389175415 4.668243885040283 C 2.080278635025024 4.624819278717041 1.630502104759216 4.618222713470459 1.448440909385681 4.693540096282959 C 1.368656039237976 4.72657585144043 1.175374984741211 4.895236015319824 1.068164229393005 4.922766208648682 C 0.9913399815559387 4.942452430725098 0.8619493246078491 4.965930938720703 0.9851588010787964 4.855915069580078 C 1.1083163022995 4.745846748352051 1.186750650405884 4.683463096618652 1.254121065139771 4.637285709381104 C 1.321491479873657 4.591107845306396 1.260717868804932 4.337521076202393 1.30580472946167 4.251554489135742 C 1.33639931678772 4.193118095397949 1.398938894271851 4.041028499603271 1.838223218917847 4.041028499603271 C 1.922475099563599 4.041080474853516 1.763061285018921 3.829308271408081 1.645825266838074 3.836580276489258 C 1.589259147644043 3.840112447738647 1.540380477905273 3.636858463287354 1.320504665374756 3.639767169952393 C 1.22705864906311 3.641014099121094 1.09283721446991 3.737005233764648 1.039751052856445 3.821776390075684 C 0.9710820913314819 3.93132472038269 0.9511359333992004 4.1817946434021 1.052788853645325 4.175509452819824 C 1.16877818107605 4.168393611907959 1.203995704650879 4.265319347381592 1.205502152442932 4.380529403686523 C 1.207527875900269 4.541605472564697 1.133872270584106 4.660036087036133 0.9842756390571594 4.695980548858643 C 0.8627802729606628 4.72512149810791 0.7479337453842163 4.858407497406006 0.7375451326370239 4.980837821960449 C 0.7276759743690491 5.096982955932617 0.6905364990234375 5.172872543334961 0.6272695660591125 5.217231750488281 C 0.4589213728904724 5.335507392883301 0.2481356412172318 5.263773918151855 0.217748835682869 5.072465896606445 C 0.1961404234170914 4.93684196472168 0.3886421620845795 4.620247840881348 0.5560553669929504 4.524464130401611 C 0.6572928428649902 4.46654748916626 0.6981721520423889 4.565187454223633 0.70476895570755 4.414968013763428 C 0.708924412727356 4.318665027618408 0.7778012156486511 4.153225421905518 0.8624168038368225 4.12704610824585 C 0.8976863026618958 4.116086483001709 0.8471453785896301 3.783805370330811 0.8875054121017456 3.703397274017334 C 0.9674980044364929 3.543827533721924 1.254692435264587 3.368830442428589 1.356293439865112 3.344884872436523 C 1.457946538925171 3.3209388256073 1.66333019733429 3.298343658447266 1.758334398269653 3.198196887969971 C 1.845754742622375 3.106049537658691 1.866947770118713 2.928040027618408 1.945485949516296 2.926741361618042 C 2.095446109771729 2.924092292785645 2.147597074508667 3.136695861816406 2.291427850723267 3.202767610549927 C 2.43520712852478 3.268839836120605 2.687079668045044 3.350857973098755 2.745100498199463 3.463055372238159 C 2.878386974334717 3.720797777175903 2.594672679901123 3.730355501174927 2.567714214324951 3.759339809417725 C 2.338696479797363 4.006018161773682 1.985741853713989 3.8604736328125 1.969483852386475 3.914494276046753 C 1.945693731307983 3.993500232696533 1.962055802345276 3.990799188613892 1.981794238090515 3.993604183197021 C 2.109470844268799 4.011784076690674 2.355058670043945 3.954802513122559 2.491773128509521 4.020977973937988 C 2.628487825393677 4.087153911590576 2.754190683364868 4.170470714569092 2.780058145523071 4.419279098510742 C 2.788472890853882 4.500674247741699 3.017179250717163 4.347701072692871 2.836624383926392 4.658321857452393 C 2.792732238769531 4.733847618103027 2.774915933609009 4.861108303070068 2.772059202194214 4.900741100311279 C 2.75870943069458 5.090541839599609 2.722920417785645 5.259512901306152 2.83880615234375 5.463286876678467 C 2.954639673233032 5.667060375213623 2.879685163497925 5.713653564453125 2.786966800689697 5.834785461425781 C 2.628435850143433 6.041727066040039 2.83781909942627 6.424341201782227 2.718245983123779 6.441638469696045 C 2.371057271957397 6.491971492767334 2.326853513717651 6.670344829559326 2.280416250228882 6.789242744445801 Z M 1.192308664321899 3.924052953720093 C 1.218955516815186 3.863851070404053 1.422573328018188 3.864993333816528 1.465426325798035 3.898445129394531 C 1.508383393287659 3.931844472885132 1.526148080825806 3.999423265457153 1.466880798339844 4.008824825286865 C 1.291676163673401 4.036561965942383 1.31910228729248 3.968828439712524 1.27946937084198 3.965919733047485 C 1.232460737228394 3.962491273880005 1.18243932723999 3.946337223052979 1.192308664321899 3.92405366897583 Z M 2.313607931137085 9.077136993408203 C 2.372407674789429 9.025402069091797 2.501590490341187 9.159675598144531 2.502577543258667 9.235616683959961 C 2.503564357757568 9.311609268188477 2.54491114616394 9.475439071655273 2.653472423553467 9.45512866973877 C 2.750917911529541 9.436896324157715 2.934225797653198 9.258419036865234 2.755748748779297 9.10700511932373 C 2.605425119400024 8.979588508605957 2.796524047851563 8.977093696594238 2.482994794845581 8.705483436584473 C 2.378744840621948 8.615154266357422 2.311789751052856 8.270977020263672 2.455672740936279 8.234462738037109 C 2.599607467651367 8.197945594787598 2.729413509368896 8.45506477355957 2.773409605026245 8.503994941711426 C 2.820054531097412 8.555938720703125 2.821976900100708 8.644346237182617 3.000505447387695 8.613128662109375 C 3.05712366104126 8.603259086608887 3.076030969619751 8.440832138061523 2.957911968231201 8.329882621765137 C 2.847169160842896 8.225838661193848 2.682197570800781 8.014897346496582 2.637629985809326 7.854081153869629 C 2.59306263923645 7.693264961242676 2.685365676879883 7.628335952758789 2.766916513442993 7.669527053833008 C 2.831845760345459 7.702406883239746 2.995363235473633 7.928464412689209 3.119611263275146 7.926853656768799 C 3.258559703826904 7.92503547668457 3.220017671585083 7.852366924285889 3.248015403747559 7.760168075561523 C 3.272324800491333 7.680279731750488 3.00362229347229 7.530838012695313 2.901501893997192 7.434535026550293 C 2.821405172348022 7.359114170074463 2.766033411026001 7.267122268676758 2.77263069152832 7.123135566711426 C 2.780318021774292 6.956969261169434 2.887165307998657 6.781297206878662 2.9544837474823 6.735795021057129 C 3.021905899047852 6.690344333648682 3.142102956771851 6.790127277374268 3.159763813018799 6.840875625610352 C 3.177372455596924 6.891624450683594 3.288634538650513 6.958111763000488 3.288634538650513 6.958111763000488 C 3.288634538650513 6.958111763000488 3.305412530899048 7.042364120483398 3.232380390167236 7.029326438903809 C 3.107820272445679 7.007094860076904 3.081744909286499 7.050051212310791 3.082264423370361 7.092385292053223 C 3.083043575286865 7.149938583374023 3.155452251434326 7.262032508850098 3.216693639755249 7.308521747589111 C 3.273467302322388 7.351582527160645 3.422856569290161 7.44985818862915 3.499992370605469 7.528916358947754 C 3.562583684921265 7.593223094940186 3.537131309509277 7.869768142700195 3.508666515350342 7.881143569946289 C 3.402962207794189 7.923270225524902 3.4796302318573 7.991938591003418 3.366186857223511 8.035882949829102 C 3.330241680145264 8.049856185913086 3.167451620101929 8.102110862731934 3.001389265060425 8.066061973571777 C 2.95157527923584 8.055310249328613 3.137895822525024 8.228695869445801 3.211863040924072 8.249526023864746 C 3.343954801559448 8.286767959594727 3.418960809707642 8.502386093139648 3.391482830047607 8.622062683105469 C 3.364004850387573 8.741791725158691 3.334812641143799 8.612297058105469 3.290349245071411 8.759921073913574 C 3.258092641830444 8.867079734802246 2.934901475906372 8.836588859558105 2.818860292434692 8.730935096740723 C 2.787486791610718 8.702366828918457 2.700169801712036 8.749427795410156 2.812211751937866 8.872793197631836 C 2.924253463745117 8.996157646179199 3.129117488861084 9.075163841247559 3.136078119277954 9.201541900634766 C 3.14309024810791 9.327868461608887 3.048969507217407 9.449934005737305 2.973183870315552 9.496838569641113 C 2.897294759750366 9.54364013671875 2.769721984863281 9.530031204223633 2.745464563369751 9.62482738494873 C 2.7212073802948 9.719623565673828 2.857817888259888 9.775152206420898 2.858597040176392 9.834054946899414 C 2.859376192092896 9.893010139465332 2.66645884513855 10.08343410491943 2.59856915473938 10.08852481842041 C 2.53067946434021 10.09366703033447 2.540081024169922 10.01912879943848 2.63051438331604 9.930980682373047 C 2.748009920120239 9.81660270690918 2.628332853317261 9.761125564575195 2.559040307998657 9.658954620361328 C 2.489799976348877 9.556729316711426 2.311063289642334 9.527381896972656 2.258652448654175 9.412899017333984 C 2.206034183502197 9.298313140869141 2.254808664321899 9.128872871398926 2.313608407974243 9.077136993408203 Z M 2.449439525604248 10.60998249053955 C 2.525224685668945 10.55803966522217 2.521692514419556 10.50287628173828 2.506421327590942 10.41670227050781 C 2.487410068511963 10.30928421020508 2.277767181396484 10.16243934631348 2.257872819900513 10.02634906768799 C 2.244315624237061 9.933110237121582 2.193151473999023 9.789435386657715 2.242549657821655 9.800032615661621 C 2.377861738204956 9.82901668548584 2.40243124961853 10.03580284118652 2.539613246917725 10.13594913482666 C 2.676795244216919 10.23609447479248 2.810445547103882 10.45088195800781 2.730244874954224 10.57123470306396 C 2.584855794906616 10.78939628601074 2.30940055847168 10.70597553253174 2.449439764022827 10.60998439788818 Z M 3.250768184661865 11.27558326721191 C 3.225783586502075 11.30778789520264 3.290504693984985 11.501953125 3.237990140914917 11.6048526763916 C 3.205837249755859 11.6679630279541 3.107872247695923 11.78171825408936 2.967936992645264 11.73803520202637 C 2.882646322250366 11.71138763427734 3.108080148696899 11.62308406829834 3.121065616607666 11.53846836090088 C 3.136648893356323 11.4362964630127 3.083978176116943 11.32009887695313 2.979001045227051 11.27906322479248 C 2.805458545684814 11.21122646331787 2.732373952865601 11.03389167785645 2.73164701461792 10.98101329803467 C 2.730659961700439 10.90922737121582 2.806653261184692 10.87156963348389 2.88451623916626 10.97904014587402 C 2.962327241897583 11.08651161193848 3.086731433868408 11.14281749725342 3.175450086593628 11.14697170257568 C 3.317151546478271 11.1536226272583 3.387118816375732 11.08687496185303 3.40062403678894 11.04516315460205 C 3.452411651611328 10.88580131530762 3.266818284988403 10.82139205932617 3.182151079177856 10.76077365875244 C 3.098885774612427 10.70124816894531 3.046267032623291 10.57102489471436 3.028242588043213 10.49487495422363 C 3.010322332382202 10.41867542266846 2.972092151641846 10.29224491119385 3.016555547714233 10.24580764770508 C 3.117637157440186 10.1402063369751 3.220173597335815 10.29473876953125 3.221835136413574 10.35364246368408 C 3.222926378250122 10.39260005950928 3.187345027923584 10.47929382324219 3.240846633911133 10.509108543396 C 3.411947727203369 10.60457992553711 3.501965522766113 10.73630714416504 3.579361200332642 10.86149120330811 C 3.692233562469482 11.04401874542236 3.577387094497681 11.19117546081543 3.501549959182739 11.24098873138428 C 3.425868511199951 11.29085445404053 3.275856256484985 11.24337863922119 3.250768184661865 11.27558326721191 Z M 3.50877046585083 12.61499214172363 C 3.331332445144653 12.64558792114258 3.281207084655762 12.53453350067139 3.348266124725342 12.46420192718506 C 3.415324687957764 12.39386940002441 3.48134446144104 12.39937591552734 3.483993768692017 12.32623958587646 C 3.488305330276489 12.2077054977417 3.404883861541748 12.19934368133545 3.394079923629761 12.06158924102783 C 3.387275457382202 11.97489547729492 3.523418426513672 11.98959541320801 3.523418426513672 11.98959541320801 C 3.639823198318481 12.02803421020508 3.642628192901611 12.23996162414551 3.64480996131897 12.41153049468994 C 3.646368026733398 12.53390884399414 3.549753665924072 12.60792922973633 3.508769989013672 12.61499214172363 Z M 3.689169406890869 10.57694721221924 C 3.722620487213135 10.50401782989502 3.806249380111694 10.27204036712646 3.68054723739624 10.18711185455322 C 3.61250114440918 10.14114284515381 3.493810892105103 10.05122947692871 3.372939109802246 10.04457950592041 C 3.279441118240356 10.03938484191895 3.201266527175903 9.909891128540039 3.164178848266602 9.830625534057617 C 3.092081785202026 9.676509857177734 3.21877121925354 9.488995552062988 3.302192449569702 9.501824378967285 C 3.468150854110718 9.527277946472168 3.416831254959106 9.768294334411621 3.575569629669189 9.789227485656738 C 3.73441219329834 9.810055732727051 3.761162757873535 9.546547889709473 3.717167139053345 9.461256980895996 C 3.638784408569336 9.309219360351563 3.32068395614624 9.228396415710449 3.36187481880188 8.933305740356445 C 3.380730390548706 8.798201560974121 3.445295572280884 8.807759284973145 3.506900310516357 8.810615539550781 C 3.635252237319946 8.816640853881836 3.698155641555786 8.949823379516602 3.801262855529785 8.956056594848633 C 3.917407989501953 8.963068962097168 3.95735239982605 8.822303771972656 3.939588069915771 8.702314376831055 C 3.924888134002686 8.603414535522461 3.516146421432495 8.358606338500977 3.469813108444214 8.280847549438477 C 3.423531770706177 8.203088760375977 3.582218408584595 8.009859085083008 3.675300598144531 7.968512058258057 C 3.768331050872803 7.927268981933594 3.818975687026978 8.129692077636719 3.944159030914307 8.178154945373535 C 4.069342613220215 8.226566314697266 4.086276054382324 8.187764167785645 4.119052410125732 8.12714672088623 C 4.218523502349854 7.942748069763184 3.801419258117676 7.866080284118652 3.678469181060791 7.553433418273926 C 3.628032207489014 7.425082206726074 3.828429460525513 7.283432483673096 3.951690912246704 7.224269390106201 C 4.030436515808105 7.186453819274902 4.161385536193848 7.396512508392334 4.256649494171143 7.378903865814209 C 4.312852382659912 7.368515968322754 4.358303070068359 7.243955135345459 4.316592216491699 7.196946144104004 C 4.187305450439453 7.051298141479492 4.008932590484619 7.053635597229004 3.96992301940918 6.991043567657471 C 3.874243259429932 6.837654590606689 3.777733325958252 6.408603668212891 3.962339162826538 6.404084205627441 C 4.028774738311768 6.402370452880859 4.18263053894043 6.691849231719971 4.398766994476318 6.672111511230469 C 4.488680362701416 6.663956642150879 4.519742965698242 6.702602863311768 4.520884990692139 6.792256355285645 C 4.522027969360352 6.881859302520752 4.617291927337646 6.974629402160645 4.677338600158691 7.070516586303711 C 4.737384796142578 7.166403770446777 4.693336963653564 7.406278133392334 4.541350841522217 7.50543737411499 C 4.395390033721924 7.600701808929443 4.206160545349121 7.495620727539063 4.126012325286865 7.452403545379639 C 4.098690032958984 7.437703609466553 4.06742000579834 7.558835029602051 4.257013320922852 7.630880832672119 C 4.459072589874268 7.707549095153809 4.621135711669922 8.07868480682373 4.426036357879639 8.220438003540039 C 4.224288940429688 8.367021560668945 4.014905452728271 8.293366432189941 3.974545478820801 8.340114593505859 C 3.92504358291626 8.397408485412598 4.014333724975586 8.397304534912109 4.074848175048828 8.431638717651367 C 4.11801290512085 8.456103324890137 4.121388912200928 8.509917259216309 4.164294242858887 8.560769081115723 C 4.23259973526001 8.641749382019043 4.385209083557129 8.627775192260742 4.292386531829834 8.866766929626465 C 4.191408634185791 9.126640319824219 3.82094931602478 9.126172065734863 3.873463869094849 9.186373710632324 C 4.030332565307617 9.366564750671387 4.095781326293945 9.393991470336914 4.091521739959717 9.504890441894531 C 4.087574005126953 9.607686996459961 3.98540186882019 9.834261894226074 3.790458679199219 9.867350578308105 C 3.6715087890625 9.887556076049805 3.578374147415161 9.890517234802246 3.747293472290039 10.00131225585938 C 3.838350057601929 10.06099414825439 4.090378761291504 10.11023616790771 3.978285312652588 10.38216018676758 C 3.860218286514282 10.66821193695068 3.655665874481201 10.64992713928223 3.689168930053711 10.57694721221924 Z M 3.813054323196411 14.2588415145874 C 3.805626392364502 14.17339515686035 3.77768087387085 14.110595703125 3.744073629379272 13.83482837677002 C 3.705739498138428 13.52010440826416 3.683663368225098 12.71316623687744 3.796432495117188 12.67207813262939 C 3.888216257095337 12.63857460021973 4.07573127746582 13.19239521026611 4.079263687133789 13.32199382781982 C 4.086068153381348 13.56825637817383 4.031631469726563 13.65006732940674 4.03807258605957 13.70102405548096 C 4.044357776641846 13.75182342529297 4.08206844329834 14.48754787445068 4.044045925140381 14.60691356658936 C 4.005971431732178 14.72628021240234 4.004828929901123 14.81525802612305 3.933873891830444 14.81795883178711 C 3.865932464599609 14.82050514221191 3.827702283859253 14.42812538146973 3.813054323196411 14.2588415145874 Z M 3.819027662277222 18.23670959472656 C 4.061395168304443 18.28428840637207 4.159308433532715 18.19692230224609 4.248027324676514 18.13204193115234 C 4.35134220123291 18.0564136505127 4.401467800140381 17.95735740661621 4.447073936462402 17.75862312316895 C 4.494446277618408 17.55178451538086 4.49506950378418 17.34188079833984 4.500264167785645 17.27383613586426 C 4.505509853363037 17.20579147338867 4.434503555297852 17.24417686462402 4.420635223388672 17.46451950073242 C 4.409675121307373 17.63852882385254 4.369574546813965 17.70782089233398 4.298568248748779 17.79726791381836 C 4.252494812011719 17.8553409576416 4.212342262268066 17.93039703369141 4.163723945617676 17.85414695739746 C 4.080925941467285 17.7241325378418 4.213173866271973 17.54845809936523 4.263558387756348 17.35595893859863 C 4.296698570251465 17.22968482971191 4.204135417938232 16.93558311462402 4.133284568786621 17.17831039428711 C 4.077238082885742 17.3703441619873 4.127674579620361 17.78916549682617 3.96213173866272 17.86983108520508 C 3.889307022094727 17.90531158447266 3.766357421875 17.84957313537598 3.838973999023438 17.67868232727051 C 3.91153883934021 17.50794219970703 3.933510541915894 17.3776683807373 3.949405193328857 17.31777954101563 C 3.981714010238647 17.19586944580078 4.02820348739624 17.02289772033691 4.036670207977295 16.95422744750977 C 4.039838314056396 16.92888069152832 4.044876575469971 16.82094192504883 3.974857568740845 16.82094192504883 C 3.92395281791687 16.82094192504883 3.917616367340088 16.97048568725586 3.908681631088257 17.05499839782715 C 3.885930299758911 17.26827812194824 3.861101388931274 17.53635787963867 3.792329072952271 17.4664421081543 C 3.759137153625488 17.43278121948242 3.776174783706665 17.17415428161621 3.828065872192383 16.8883113861084 C 3.848427534103394 16.77606201171875 3.885255575180054 16.64501190185547 3.918550968170166 16.50273704528809 C 3.949509143829346 16.37080001831055 3.920421123504639 16.20318031311035 3.958546876907349 16.08880233764648 C 3.985713720321655 16.00704383850098 4.072978019714355 15.87157249450684 4.094171047210693 15.72867679595947 C 4.115779399871826 15.58401489257813 4.18543529510498 15.47368812561035 4.220601081848145 15.3376989364624 C 4.321058750152588 14.94931983947754 4.356640338897705 14.64778804779053 4.27368688583374 14.18216991424561 C 4.217536449432373 13.86697769165039 4.105287075042725 12.83907222747803 4.183877468109131 12.70261764526367 C 4.219199180603027 12.64127254486084 4.426192760467529 12.62683200836182 4.510028839111328 12.56112480163574 C 4.578230857849121 12.50772666931152 4.614902019500732 12.34659862518311 4.64315938949585 12.31164169311523 C 4.724295139312744 12.21133899688721 4.871658325195313 12.17539310455322 5.044785022735596 11.989333152771 C 5.098442077636719 11.93172740936279 5.054290771484375 11.62552261352539 5.200303554534912 11.60422515869141 C 5.34106969833374 11.58370685577393 5.40324592590332 11.85833168029785 5.335148811340332 11.96616649627686 C 5.294684886932373 12.03021335601807 5.573776245117188 12.23029899597168 5.59694242477417 12.38638782501221 C 5.620109081268311 12.54242515563965 5.534142971038818 12.46435451507568 5.552426815032959 12.78120899200439 C 5.567230701446533 13.03884696960449 5.607071399688721 13.72901725769043 5.704568862915039 14.26278591156006 C 5.73542308807373 14.43191337585449 5.790431022644043 14.59558582305908 5.836192607879639 14.81317615509033 C 5.886162281036377 15.05040073394775 5.735786437988281 15.11782360076904 5.784665584564209 15.42532920837402 C 5.805338859558105 15.55518531799316 5.78175687789917 15.63777637481689 5.708568572998047 15.7349100112915 C 5.57242488861084 15.91541290283203 5.459604263305664 15.99072933197021 5.438775539398193 16.26494026184082 C 5.409790992736816 16.64776229858398 5.196044445037842 17.01489639282227 5.227159023284912 16.70126342773438 C 5.236040592193604 16.61062240600586 5.247416019439697 16.31781768798828 5.196044445037842 16.38638114929199 C 5.144828319549561 16.45500183105469 5.140620708465576 16.81647300720215 5.020736217498779 17.01790809631348 C 4.901837825775146 17.21757698059082 4.96235179901123 17.30177688598633 4.957053661346436 17.5452880859375 C 4.954041004180908 17.6813793182373 4.699571132659912 17.78074645996094 4.750112056732178 17.9641056060791 C 4.784809589385986 18.09017181396484 4.504472255706787 18.42354393005371 4.320281028747559 18.60659217834473 C 4.242730140686035 18.68383026123047 4.315190315246582 18.71198463439941 4.443594455718994 18.65105438232422 C 4.528729438781738 18.61074447631836 4.674637794494629 18.47366714477539 4.68710470199585 18.4931468963623 C 4.718945980072021 18.5433235168457 4.580725193023682 18.79826164245605 4.387028694152832 18.8344669342041 C 4.317736148834229 18.84745216369629 4.167152404785156 18.84282875061035 4.110846042633057 18.88111114501953 C 4.02981424331665 18.93627548217773 3.981611251831055 18.95928764343262 3.894450187683105 19.03044891357422 C 3.849727153778076 19.0670166015625 3.791031360626221 19.10696029663086 3.657952547073364 19.110595703125 C 3.604243278503418 19.11205291748047 3.536041498184204 19.26372337341309 3.492409467697144 19.17448806762695 C 3.478125095367432 19.14524459838867 3.54222297668457 18.93399047851563 3.539314270019531 18.9139404296875 C 3.52430248260498 18.8110408782959 3.4550621509552 18.78626251220703 3.439115762710571 18.82745552062988 C 3.425038814544678 18.86360740661621 3.447478532791138 19.03408622741699 3.340008020401001 19.03247451782227 C 3.241575479507446 19.03096771240234 3.204020738601685 18.82480621337891 3.296375751495361 18.73868370056152 C 3.388731002807617 18.65261268615723 3.417091846466064 18.65785980224609 3.514433860778809 18.67157173156738 C 3.592244386672974 18.68263816833496 3.651252269744873 18.62045860290527 3.551520824432373 18.54571342468262 C 3.440050363540649 18.46224021911621 3.439531326293945 18.28371238708496 3.496461153030396 18.22361373901367 C 3.593854904174805 18.12066268920898 3.589127779006958 18.19161796569824 3.819028854370117 18.23670387268066 Z M 3.19243597984314 19.5726375579834 C 3.204175233840942 19.65652656555176 2.946224689483643 19.65652656555176 2.937705993652344 19.60136413574219 C 2.920513153076172 19.49025535583496 3.07494044303894 19.30975341796875 3.121429681777954 19.29224967956543 C 3.159088611602783 19.27801704406738 3.26837682723999 19.25334358215332 3.265572071075439 19.29224967956543 C 3.263390302658081 19.32284355163574 3.178359508514404 19.47160911560059 3.19243597984314 19.57263946533203 Z M 3.014530181884766 18.20455551147461 C 3.093172550201416 18.05734634399414 3.184333086013794 18.01106643676758 3.243132591247559 18.00961303710938 C 3.36748480796814 18.00649642944336 3.378860473632813 18.0530891418457 3.459735870361328 18.14778137207031 C 3.474072217941284 18.16461181640625 3.423531770706177 18.17775344848633 3.346292018890381 18.24273490905762 C 3.243132591247559 18.32942771911621 3.392417669296265 18.52811050415039 3.336526393890381 18.5855598449707 C 3.280635833740234 18.64300918579102 3.056500434875488 18.86719703674316 3.04055380821228 18.72336769104004 C 3.031567811965942 18.64295768737793 2.984403133392334 18.50510215759277 2.948873996734619 18.38100814819336 C 2.930278539657593 18.31613159179688 2.955886363983154 18.3144702911377 3.014530181884766 18.20455932617188 Z M 3.081796646118164 19.08774566650391 C 3.038995265960693 19.2397346496582 2.901086091995239 19.30876541137695 2.801978588104248 19.28882026672363 C 2.717051267623901 19.27178192138672 2.862544059753418 19.14711761474609 2.897709846496582 19.05829620361328 C 2.943991184234619 18.9414234161377 2.752684116363525 18.76710319519043 2.738088130950928 18.94407272338867 C 2.722037315368652 19.13953399658203 2.622981786727905 18.99944305419922 2.66422438621521 18.84896469116211 C 2.68739128112793 18.76408767700195 2.781927824020386 18.72190856933594 2.886645793914795 18.77473831176758 C 2.99141526222229 18.82777214050293 3.134675025939941 18.90023231506348 3.081796407699585 19.08774948120117 Z M 2.743905782699585 19.58681869506836 C 2.768786668777466 19.67143249511719 2.751801013946533 19.6915340423584 2.646200656890869 19.6915340423584 C 2.538470268249512 19.6915340423584 2.464503049850464 19.59793281555176 2.560701847076416 19.4792423248291 C 2.605061531066895 19.42444229125977 2.654459476470947 19.32600975036621 2.828625202178955 19.32637405395508 C 2.879529714584351 19.32647895812988 2.929966688156128 19.42953109741211 2.875789642333984 19.43841552734375 C 2.771747589111328 19.45545387268066 2.725414037704468 19.52422714233398 2.743905782699585 19.58681869506836 Z M 2.463516235351563 18.94771003723145 C 2.540392160415649 18.92755508422852 2.58636212348938 19.03741455078125 2.595711469650269 19.09891510009766 C 2.611190795898438 19.20062065124512 2.517329454421997 19.16223335266113 2.531925439834595 19.20171165466309 C 2.546625375747681 19.24123954772949 2.556598424911499 19.35317802429199 2.510524749755859 19.37364387512207 C 2.450893878936768 19.40008354187012 2.301661014556885 19.4128589630127 2.25989842414856 19.35245132446289 C 2.198449611663818 19.26352500915527 2.246912717819214 19.25708389282227 2.344306468963623 19.23251533508301 C 2.403573513031006 19.21745109558105 2.413495063781738 19.08863258361816 2.413495063781738 19.08863258361816 C 2.413495063781738 19.08863258361816 2.39583420753479 18.96542167663574 2.463516235351563 18.94771003723145 Z M 2.22223973274231 18.65095520019531 C 2.314439058303833 18.55636787414551 2.411832809448242 18.67105865478516 2.49603271484375 18.61324310302734 C 2.5624680519104 18.5676383972168 2.621371507644653 18.45029830932617 2.676950931549072 18.15229988098145 C 2.732530355453491 17.85430145263672 2.851844072341919 17.87019729614258 2.869452953338623 17.92899513244629 C 2.887165307998657 17.9881591796875 2.819742918014526 18.10757446289063 2.822080612182617 18.20985412597656 C 2.823898553848267 18.28813171386719 2.810964822769165 18.34064674377441 2.798498630523682 18.39009857177734 C 2.784421682357788 18.44598770141602 2.712376594543457 18.53418731689453 2.665627717971802 18.59407806396484 C 2.627968788146973 18.64238548278809 2.60916543006897 18.82418632507324 2.490786790847778 18.86808013916016 C 2.372459888458252 18.91212463378906 2.130040884017944 18.74554443359375 2.222239971160889 18.65095520019531 Z M 2.204111576080322 18.87857055664063 C 2.233719110488892 18.84797668457031 2.322438478469849 18.8748836517334 2.322905778884888 18.90885353088379 C 2.323321104049683 18.94272041320801 2.26576828956604 18.95975875854492 2.291739940643311 19.0224552154541 C 2.308517694473267 19.06281471252441 2.281818628311157 19.13958549499512 2.244575500488281 19.08432006835938 C 2.219850301742554 19.04775047302246 2.179542303085327 18.90392112731934 2.204111576080322 18.87857246398926 Z M 2.201774120330811 19.63964462280273 C 2.244575500488281 19.45545387268066 2.188528776168823 19.46075248718262 2.365343332290649 19.44251823425293 C 2.441803932189941 19.43462181091309 2.34596848487854 19.50890350341797 2.340254783630371 19.58546829223633 C 2.334644556045532 19.65948677062988 2.407832860946655 19.72550773620605 2.340254783630371 19.72550773620605 C 2.20005989074707 19.72550773620605 2.180373430252075 19.73189544677734 2.201774120330811 19.63964462280273 Z M 2.423520088195801 22.50758743286133 C 2.308673620223999 22.50088691711426 2.254912137985229 22.54669952392578 2.226603031158447 22.46743583679199 C 2.208215236663818 22.41617012023926 2.319685459136963 22.20714950561523 2.376615285873413 22.15603637695313 C 2.454010963439941 22.0865364074707 2.679548501968384 22.10388565063477 2.679548501968384 22.10388565063477 L 2.664277315139771 22.19577407836914 C 2.664277315139771 22.19577407836914 2.627189636230469 22.19987869262695 2.577635765075684 22.20984840393066 C 2.545950412750244 22.2162914276123 2.512291193008423 22.27218246459961 2.513174295425415 22.32002258300781 C 2.515355825424194 22.42936325073242 2.538055181503296 22.51428985595703 2.423520088195801 22.50758743286133 Z M 2.452088832855225 22.0484619140625 C 2.346020698547363 22.10186195373535 2.279481410980225 21.10278511047363 2.346020698547363 21.10148429870605 C 2.411780595779419 21.10008239746094 2.654147863388062 21.37730407714844 2.654147863388062 21.43475151062012 C 2.654147863388062 21.49204444885254 2.558156967163086 21.99496269226074 2.452088832855225 22.0484619140625 Z M 2.068851470947266 20.2382926940918 C 2.10157585144043 20.13372993469238 2.427363872528076 22.01968383789063 2.346020698547363 22.10186195373535 C 2.2569899559021 22.1917724609375 2.150194406509399 22.35981178283691 2.150194406509399 22.35981178283691 C 2.150194406509399 22.35981178283691 2.01867413520813 20.39859008789063 2.068851232528687 20.2382926940918 Z M 1.158701658248901 22.11209487915039 C 1.193451642990112 22.00088310241699 1.18903648853302 21.8190803527832 1.133820772171021 21.65166854858398 C 1.113510966300964 21.58990669250488 1.318635106086731 21.70734977722168 1.318635106086731 21.88411331176758 C 1.318635106086731 22.0864315032959 1.133457183837891 22.1927604675293 1.158701658248901 22.11209487915039 Z M 1.392342448234558 22.90614891052246 C 1.378785490989685 22.90625381469727 1.405120611190796 22.04861831665039 1.409795641899109 21.80079460144043 C 1.414002895355225 21.58097457885742 1.383200526237488 20.60298347473145 1.409795641899109 20.56433868408203 C 1.452337145805359 20.50263023376465 1.514876842498779 21.34042167663574 1.516071438789368 21.53697776794434 C 1.517266273498535 21.73326873779297 1.515707731246948 22.90563011169434 1.392342448234558 22.90614891052246 Z M 1.613724827766418 23.45399475097656 C 1.55424976348877 23.555908203125 1.556431412696838 23.51321029663086 1.571287155151367 23.44973564147949 C 1.586091041564941 23.38641548156738 1.728363752365112 22.98271369934082 1.719896793365479 22.59163093566895 C 1.712468862533569 22.24813079833984 1.702911376953125 21.26422309875488 1.685926079750061 21.14246940612793 C 1.668940544128418 21.02076721191406 1.638345956802368 20.61534690856934 1.537264227867126 20.3938102722168 C 1.510150074958801 20.33438682556152 1.406367301940918 20.1982421875 1.409899353981018 20.15019607543945 C 1.418729782104492 20.03046607971191 1.486048221588135 20.04724502563477 1.562768459320068 20.13326454162598 C 1.70711886882782 20.29511833190918 1.779319882392883 20.90519142150879 1.79635751247406 21.14252090454102 C 1.810693860054016 21.34302139282227 1.855832695960999 22.20128059387207 1.830328464508057 22.5916862487793 C 1.803941130638123 22.9945068359375 1.651747465133667 23.3889102935791 1.613724946975708 23.4539966583252 Z M 1.800564885139465 23.92200469970703 C 1.78903329372406 23.89639472961426 1.85863733291626 23.73080062866211 1.867311954498291 23.67870330810547 C 1.898270130157471 23.49217414855957 1.90252947807312 23.11288261413574 1.919462919235229 22.90609741210938 C 1.936448454856873 22.69941520690918 1.935929179191589 21.9888858795166 1.929384231567383 21.7186222076416 C 1.9264235496521 21.59634971618652 1.890063047409058 20.82275772094727 1.861442565917969 20.60942459106445 C 1.85011887550354 20.52522659301758 1.822848677635193 20.22234535217285 1.837964177131653 20.13450813293457 C 1.856040477752686 20.02890777587891 1.978938341140747 20.45162391662598 2.016648769378662 20.73497200012207 C 2.039451837539673 20.90649223327637 2.04807448387146 21.61463165283203 2.048282623291016 21.75965690612793 C 2.048697948455811 22.04971122741699 2.131755352020264 23.34356307983398 1.96081018447876 23.73225593566895 C 1.924449920654297 23.81500053405762 1.822641015052795 23.97134971618652 1.800565123558044 23.92200469970703 Z M 2.280416488647461 22.90614891052246 C 2.232005596160889 22.99388122558594 2.228940725326538 23.3994026184082 2.208215236663818 23.63662528991699 C 2.18702244758606 23.87982749938965 1.95457661151886 23.92465209960938 2.004390001296997 23.87016296386719 C 2.097784042358398 23.76825141906738 2.110510110855103 23.63953590393066 2.121885776519775 23.43560600280762 C 2.133261442184448 23.23178100585938 2.062618494033813 22.72543716430664 2.144584894180298 22.60882759094238 C 2.184217691421509 22.5523624420166 2.305816888809204 22.61833000183105 2.359058856964111 22.61381340026855 C 2.484294176101685 22.60332107543945 2.552651643753052 22.57521629333496 2.552235841751099 22.71100044250488 C 2.551976203918457 22.77997970581055 2.335113286972046 22.80704116821289 2.280416965484619 22.90614891052246 Z M 2.741828441619873 23.96132469177246 C 2.733361721038818 23.96895980834961 2.637110710144043 24.07539176940918 2.611606597900391 24.09237670898438 C 2.586154460906982 24.10936164855957 2.753204345703125 24.20841789245605 2.716376066207886 24.2197437286377 C 2.679600238800049 24.23106575012207 2.614463329315186 24.2396354675293 2.586206197738647 24.2197437286377 C 2.557897329330444 24.199951171875 2.450270891189575 24.08666229248047 2.455984592437744 24.04422760009766 C 2.461698532104492 24.00184059143066 2.61586594581604 23.93353462219238 2.659809827804565 23.91971969604492 C 2.69570255279541 23.90855026245117 2.750347137451172 23.9537410736084 2.741828203201294 23.96132469177246 Z M 2.691962718963623 23.84403800964355 C 2.570623397827148 23.82357025146484 2.418429851531982 23.65568923950195 2.394483804702759 23.5540885925293 C 2.370537996292114 23.45248985290527 2.338281154632568 23.3708324432373 2.373914241790771 23.27977561950684 C 2.385030269622803 23.2512092590332 2.38487434387207 23.2512092590332 2.38487434387207 23.2512092590332 C 2.38487434387207 23.2512092590332 2.423935413360596 23.2054443359375 2.372511863708496 23.16934776306152 C 2.348877429962158 23.15267181396484 2.322230815887451 23.00577926635742 2.383939504623413 22.96541595458984 C 2.445751905441284 22.92495346069336 2.549534559249878 22.84683036804199 2.617268562316895 22.82896041870117 C 2.685002565383911 22.81098937988281 2.764111995697021 22.80190086364746 2.809147119522095 22.75722694396973 C 2.834858894348145 22.73182678222656 2.850389719009399 22.69037628173828 2.835690021514893 22.64523887634277 C 2.819016218185425 22.59412384033203 2.764008522033691 22.57267189025879 2.720427989959717 22.48821258544922 C 2.685054302215576 22.41964721679688 2.681678056716919 22.12071418762207 2.753983020782471 22.01781272888184 C 2.794758558273315 21.95979499816895 2.876777172088623 21.87445068359375 2.898852825164795 21.83466339111328 C 2.92098069190979 21.79471778869629 2.898956775665283 21.84032440185547 2.92098069190979 21.79471778869629 C 2.943108558654785 21.74911117553711 2.959055423736572 21.66974067687988 2.868621826171875 21.67930030822754 C 2.778344869613647 21.68901443481445 2.739646673202515 21.67472839355469 2.74764609336853 21.51947021484375 C 2.750139474868774 21.47137260437012 2.747074842453003 21.34738349914551 2.798862218856812 21.3206844329834 C 2.860726594924927 21.28878974914551 2.805459022521973 21.15509033203125 2.838287353515625 21.08236503601074 C 2.876828908920288 20.99686813354492 2.903424263000488 20.86072540283203 2.857609987258911 20.82155990600586 C 2.805562973022461 20.77709770202637 2.809822559356689 20.54745674133301 2.813250780105591 20.49089050292969 C 2.818289279937744 20.40882110595703 2.715285778045654 20.32524490356445 2.667393922805786 20.34555435180664 C 2.62672233581543 20.36290168762207 2.667134046554565 20.44330978393555 2.667134046554565 20.44330978393555 C 2.667134046554565 20.44330978393555 2.641162633895874 20.40996170043945 2.596023797988892 20.39448356628418 C 2.664069652557373 20.42320823669434 2.774916648864746 20.53353500366211 2.77678656578064 20.68105316162109 C 2.779799222946167 20.91043281555176 2.727336645126343 20.80862808227539 2.672120809555054 20.92887306213379 C 2.625631332397461 21.02990341186523 2.679548740386963 21.10158729553223 2.626670598983765 21.14178848266602 C 2.550989151000977 21.1992359161377 2.435103893280029 21.01754188537598 2.417443037033081 20.95115852355957 C 2.405651807785034 20.90679550170898 2.408976554870605 20.77766609191895 2.458582162857056 20.74462890625 C 2.508136034011841 20.7114372253418 2.496189117431641 20.66853332519531 2.486579656600952 20.59129333496094 C 2.471879482269287 20.47395515441895 2.481177568435669 20.3925609588623 2.55955982208252 20.38736534118652 C 2.556339263916016 20.38715744018555 2.553430557250977 20.38648223876953 2.550158262252808 20.38648223876953 C 2.550158262252808 20.38648223876953 2.50886344909668 20.19190216064453 2.56262469291687 20.15715217590332 C 2.616437911987305 20.12255859375 2.637318849563599 20.08329010009766 2.636695623397827 20.03243637084961 C 2.636020421981812 19.98147964477539 2.652486324310303 19.92839431762695 2.677522897720337 19.90803337097168 C 2.694715976715088 19.8940601348877 2.803121566772461 19.86216735839844 2.815900087356567 19.83588218688965 C 2.835274934768677 19.79604148864746 2.891529321670532 19.75043678283691 2.96025013923645 19.74965667724609 C 3.036035299301147 19.74861907958984 3.059773683547974 19.76643562316895 3.135506868362427 19.76939582824707 C 3.193423509597778 19.77162933349609 3.277052164077759 19.75479888916016 3.325723171234131 19.80757331848145 C 3.350292444229126 19.83427238464355 3.375381231307983 19.90169334411621 3.3194899559021 19.94776916503906 C 3.26354718208313 19.99378967285156 3.286817789077759 20.1424503326416 3.30816650390625 20.14302444458008 C 3.354811668395996 20.14432144165039 3.322347164154053 20.04116439819336 3.413091897964478 19.98189735412598 C 3.437297344207764 19.96615791320801 3.479994535446167 19.91691589355469 3.497863054275513 19.91655158996582 C 3.558896541595459 19.91546058654785 3.545287132263184 20.10578155517578 3.528976678848267 20.16000938415527 C 3.512718200683594 20.21439361572266 3.567155361175537 20.07633018493652 3.627461433410645 20.07258796691895 C 3.695403099060059 20.06864166259766 3.694675922393799 20.22525024414063 3.665068387985229 20.24545669555664 C 3.638733148574829 20.26332473754883 3.594945192337036 20.34996604919434 3.591257095336914 20.37235450744629 C 3.577128648757935 20.45733261108398 3.599776029586792 20.49686050415039 3.661796092987061 20.3728199005127 C 3.683093070983887 20.33012580871582 3.745113134384155 20.38004302978516 3.749788045883179 20.39349365234375 C 3.765942335128784 20.44003677368164 3.766825675964355 20.4941577911377 3.71311616897583 20.53015899658203 C 3.692338705062866 20.5440788269043 3.671924829483032 20.55670166015625 3.643044710159302 20.60931777954102 C 3.612138271331787 20.66562652587891 3.651407718658447 20.74322891235352 3.697896718978882 20.72052764892578 C 3.719245433807373 20.7101936340332 3.737789154052734 20.61742401123047 3.765007495880127 20.60028076171875 C 3.803030014038086 20.57622909545898 3.829728841781616 20.6259937286377 3.844324827194214 20.65866470336914 C 3.863076448440552 20.70073890686035 3.850401878356934 20.72011375427246 3.817781686782837 20.73980140686035 C 3.767916202545166 20.76987648010254 3.696597814559937 20.86591911315918 3.75285267829895 20.85926818847656 C 3.779031991958618 20.85625648498535 3.906500816345215 20.81646728515625 3.914084196090698 20.82810211181641 C 3.938341856002808 20.86591720581055 3.951015949249268 20.91593933105469 3.863231897354126 20.9748420715332 C 3.816898584365845 21.00601196289063 3.793576002120972 21.0179557800293 3.75285267829895 21.06319808959961 C 3.727711915969849 21.09109115600586 3.742256164550781 21.12044143676758 3.773941516876221 21.12469863891602 C 3.908370733261108 21.14235877990723 3.937250852584839 21.04725074768066 3.999011754989624 21.08013153076172 C 4.041760921478271 21.10288238525391 4.003998279571533 21.22136497497559 3.981454849243164 21.24312782287598 C 3.92826509475708 21.2942943572998 3.791342496871948 21.36109352111816 3.846142530441284 21.36888313293457 C 3.900319337844849 21.37667465209961 4.025554656982422 21.32073211669922 4.061291217803955 21.29813385009766 C 4.115053176879883 21.26421737670898 4.090691566467285 21.38747787475586 4.05843448638916 21.41926765441895 C 4.009088516235352 21.46809577941895 3.886242628097534 21.45282363891602 3.863127946853638 21.48788642883301 C 3.845155239105225 21.51494979858398 3.930342197418213 21.58865547180176 4.055317878723145 21.5414924621582 C 4.080769538879395 21.53188323974609 4.151828765869141 21.54040145874023 4.174319744110107 21.54850578308105 C 4.231197357177734 21.56897163391113 4.285374641418457 21.61203002929688 4.349264621734619 21.6142635345459 C 4.372171401977539 21.61493873596191 4.465357780456543 21.59634399414063 4.526287078857422 21.56387901306152 C 4.593086242675781 21.52840042114258 4.688246250152588 21.51811790466309 4.763615608215332 21.52170181274414 C 4.826155662536621 21.52486991882324 5.021461963653564 21.53754425048828 5.135321617126465 21.644287109375 C 5.19708251953125 21.7022533416748 5.342575073242188 21.71856689453125 5.410101890563965 21.70874786376953 C 5.462616443634033 21.70116424560547 5.633873462677002 21.67612838745117 5.692569732666016 21.54881286621094 C 5.744201183319092 21.43697929382324 5.749499320983887 21.27237319946289 5.687582492828369 21.15872001647949 C 5.620160579681396 21.03504180908203 5.566035747528076 20.83620071411133 5.699010372161865 20.73034477233887 C 5.820921421051025 20.63326263427734 5.791365146636963 20.55960845947266 5.805961608886719 20.45925140380859 C 5.818739891052246 20.37126159667969 6.019552230834961 20.22727394104004 6.070093154907227 20.19257545471191 C 6.120633602142334 20.15792846679688 6.16790246963501 20.10432434082031 6.172109603881836 20.04515838623047 C 6.176368713378906 19.98594284057617 6.255063056945801 19.9397144317627 6.32331657409668 19.9613208770752 C 6.383570671081543 19.98033142089844 6.403516292572021 20.03388786315918 6.353392124176025 20.09408950805664 C 6.303162097930908 20.15423774719238 6.238441467285156 20.2396354675293 6.20639181137085 20.2514762878418 C 6.174343585968018 20.26337242126465 6.062509059906006 20.3115234375 6.074508190155029 20.37084197998047 C 6.081312656402588 20.40460586547852 6.160110950469971 20.4273567199707 6.209716320037842 20.50812911987305 C 6.262178897857666 20.59357643127441 6.229610443115234 20.65866088867188 6.193042755126953 20.67091751098633 C 6.144683361053467 20.68707466125488 6.090143203735352 20.71226692199707 6.061418056488037 20.72473335266113 C 6.028278827667236 20.73886299133301 6.012384414672852 20.77096557617188 6.02417516708374 20.78389739990234 C 6.07378101348877 20.83854103088379 6.110867977142334 20.82763290405273 6.121101379394531 20.8544864654541 C 6.138553619384766 20.8998851776123 6.097311019897461 20.92907905578613 6.04355001449585 20.92985725402832 C 6.020798683166504 20.93011665344238 5.982516765594482 20.97858047485352 6.036537647247314 21.00657653808594 C 6.132217407226563 21.05607986450195 6.088948249816895 21.16064071655273 6.044173717498779 21.17710494995117 C 5.999345779418945 21.19357109069824 5.985165596008301 21.22032165527344 5.976542949676514 21.25237274169922 C 5.970725536346436 21.27392768859863 5.978724479675293 21.31314659118652 6.018097400665283 21.31865310668945 C 6.059184551239014 21.32452011108398 6.053886890411377 21.40622901916504 6.032901763916016 21.42882347106934 C 6.003657341003418 21.46025085449219 5.978776931762695 21.47801399230957 5.985321521759033 21.5272045135498 C 5.996489524841309 21.61015701293945 6.029317855834961 21.6428337097168 5.962258815765381 21.71009635925293 C 5.895148277282715 21.77741432189941 5.85655403137207 21.80525588989258 5.756147861480713 21.82338523864746 C 5.667169094085693 21.83943367004395 5.645924091339111 21.87901878356934 5.544374942779541 21.87605476379395 C 5.429476261138916 21.87257766723633 5.270062923431396 21.94374084472656 5.179317474365234 21.92405128479004 C 5.091949462890625 21.90519714355469 5.130699157714844 21.95843887329102 5.176772117614746 22.00207138061523 C 5.356599807739258 22.17239570617676 5.214639186859131 22.36323356628418 5.291099071502686 22.46286010742188 C 5.459967136383057 22.68314933776855 5.593097686767578 22.91170310974121 5.695322036743164 22.93486976623535 C 5.797545909881592 22.95803642272949 5.974880695343018 23.02104568481445 6.007033348083496 23.04935264587402 C 6.056430816650391 23.0925178527832 6.008071899414063 23.17718505859375 5.985788822174072 23.20528793334961 C 5.963504791259766 23.2333869934082 5.936182498931885 23.31161499023438 5.991554260253906 23.32782173156738 C 6.074715614318848 23.35228729248047 6.118555545806885 23.29431915283203 6.163278579711914 23.35867691040039 C 6.196678161621094 23.40662002563477 6.25636100769043 23.55289459228516 6.308096885681152 23.61428833007813 C 6.359832286834717 23.67558097839355 6.318745136260986 23.89633941650391 6.286851406097412 23.90620803833008 C 6.232882499694824 23.92293357849121 6.111958980560303 23.98739624023438 6.041679859161377 23.94963455200195 C 5.948078155517578 23.89940452575684 6.108479022979736 23.80808639526367 6.096635341644287 23.73630142211914 C 6.085935115814209 23.67194557189941 6.01430606842041 23.55185317993164 5.951090812683105 23.4791316986084 C 5.887823104858398 23.40635871887207 5.755628108978271 23.18881988525391 5.662493705749512 23.16362953186035 C 5.515442371368408 23.12373542785645 5.240143299102783 22.87908554077148 5.126646518707275 22.88744735717773 C 4.894668102264404 22.90453720092773 4.504730224609375 22.75577163696289 4.25550651550293 22.5140266418457 C 4.173020839691162 22.43403244018555 4.194524765014648 22.52223205566406 4.192447662353516 22.64279556274414 C 4.191096782684326 22.71816444396973 4.111572265625 22.81181907653809 3.999322414398193 22.79514312744141 C 3.841882467269897 22.77177047729492 3.780069828033447 22.63297653198242 3.724698305130005 22.57573699951172 C 3.660548210144043 22.5095100402832 3.611098289489746 22.49481010437012 3.538637638092041 22.4762134552002 C 3.436361074447632 22.44987869262695 3.352472543716431 22.17935943603516 3.330864429473877 22.17094421386719 C 3.282245397567749 22.15203475952148 3.392676830291748 22.52680778503418 3.330500364303589 22.5855541229248 C 3.281310319900513 22.63209342956543 3.112858295440674 22.88240814208984 2.968923568725586 22.91669273376465 C 2.871633768081665 22.93996429443359 2.723387479782104 22.97923469543457 2.630045413970947 22.98697090148926 C 2.549273729324341 22.99346351623535 2.468658208847046 23.14077568054199 2.562934637069702 23.1884593963623 C 2.625786066055298 23.22024726867676 2.547975301742554 23.53730964660645 2.582309484481812 23.56520462036133 C 2.616696119308472 23.59299278259277 2.726763963699341 23.59730339050293 2.768994092941284 23.6058235168457 C 2.805250406265259 23.61335372924805 2.816885471343994 23.68249320983887 2.838701486587524 23.74103355407715 C 2.856258392333984 23.78835296630859 2.905500650405884 23.82102584838867 2.885138988494873 23.83925437927246 C 2.870439052581787 23.8521900177002 2.84389591217041 23.86948776245117 2.691962003707886 23.84403419494629 Z M 3.056137323379517 24.04708099365234 C 3.007985830307007 24.0640697479248 2.981442928314209 24.14338684082031 3.044294118881226 24.19148445129395 C 3.107041835784912 24.23968696594238 3.033489942550659 24.2613468170166 2.940044164657593 24.25189590454102 C 2.846597909927368 24.24238586425781 2.81262731552124 24.14052581787109 2.840884447097778 24.08957290649414 C 2.869245290756226 24.03861618041992 2.931473016738892 23.96906280517578 3.010790824890137 23.96132469177246 C 3.064448356628418 23.9562873840332 3.104288578033447 24.03009796142578 3.056137323379517 24.04708099365234 Z M 3.367485046386719 24.05560111999512 C 3.33642315864563 24.07539176940918 3.257157564163208 24.12079238891602 3.276948213577271 24.15476036071777 C 3.296790361404419 24.18868064880371 3.367485046386719 24.22831153869629 3.322242498397827 24.23724937438965 C 3.276948213577271 24.24612998962402 3.262819528579712 24.26509094238281 3.218927383422852 24.23724937438965 C 3.17503547668457 24.20924949645996 3.12968921661377 24.09809303283691 3.146674871444702 24.0640697479248 C 3.163660049438477 24.03009796142578 3.252846479415894 23.97747993469238 3.29107666015625 23.98199844360352 C 3.33922815322876 23.98766136169434 3.398703336715698 24.03581237792969 3.367485046386719 24.05560111999512 Z M 3.581231594085693 24.79761123657227 C 3.549858093261719 24.79714584350586 3.505498170852661 24.81033897399902 3.52596378326416 24.77008056640625 C 3.533547878265381 24.7550163269043 3.533807516098022 24.73091506958008 3.565181016921997 24.73091506958008 C 3.596450567245483 24.73091506958008 3.639511585235596 24.72229194641113 3.639511585235596 24.74135589599609 C 3.639511585235596 24.76052093505859 3.621643304824829 24.79818153381348 3.581231117248535 24.79761123657227 Z M 3.659146308898926 24.20145797729492 C 3.653484582901001 24.21138191223145 3.622370719909668 24.24238967895508 3.585542917251587 24.23636627197266 C 3.54876708984375 24.23039054870605 3.449711561203003 24.1320629119873 3.412831783294678 24.08100318908691 C 3.376055717468262 24.03009796142578 3.561389446258545 23.98412895202637 3.608242273330688 23.98199844360352 C 3.670521974563599 23.97919273376465 3.763916492462158 24.01596832275391 3.741268873214722 24.03861618041992 C 3.718621730804443 24.06126403808594 3.619565725326538 24.10094833374023 3.59972357749939 24.10962295532227 C 3.579829216003418 24.11834907531738 3.66480827331543 24.19148445129395 3.659146308898926 24.20145797729492 Z M 3.786563396453857 24.8027515411377 C 3.739399194717407 24.80223274230957 3.672548055648804 24.81714248657227 3.70335054397583 24.77138137817383 C 3.714829921722412 24.75439262390137 3.715193271636963 24.72707176208496 3.762462139129639 24.72707176208496 C 3.809574365615845 24.72707176208496 3.874295711517334 24.71730804443359 3.874295711517334 24.73891448974609 C 3.874347925186157 24.76062774658203 3.84744119644165 24.80337524414063 3.786563396453857 24.8027515411377 Z M 4.091470718383789 25.07467460632324 C 4.074484825134277 25.15965270996094 4.059577465057373 25.26977348327637 4.052616596221924 25.29558944702148 C 4.041293144226074 25.3377685546875 3.946548938751221 25.32114791870117 3.920317649841309 25.24182891845703 C 3.894138336181641 25.16256332397461 3.857310771942139 24.98704719543457 3.976208448410034 24.9926586151123 C 4.013970851898193 24.99447441101074 4.108455657958984 24.98974800109863 4.091470718383789 25.07467460632324 Z M 4.023633003234863 24.8073787689209 C 3.970079183578491 24.80670166015625 3.894294023513794 24.82441520690918 3.929303646087646 24.77018547058105 C 3.942341327667236 24.74992561340332 3.942705392837524 24.71735954284668 3.996310710906982 24.71735954284668 C 4.049759864807129 24.71735954284668 4.123208045959473 24.70587730407715 4.123208045959473 24.73148727416992 C 4.123208045959473 24.75730133056641 4.092665672302246 24.80815505981445 4.023633003234863 24.8073787689209 Z M 4.00166130065918 24.35287284851074 C 3.928057193756104 24.34991264343262 3.732698440551758 24.16883659362793 3.766773223876953 24.12354278564453 C 3.800692558288574 24.07819557189941 4.049240589141846 23.9819450378418 4.10648250579834 23.9819450378418 C 4.182942867279053 23.9819450378418 4.281998157501221 23.99046325683594 4.230626583099365 24.02619934082031 C 4.17925500869751 24.06193733215332 4.069706439971924 24.11507415771484 4.030074119567871 24.14904403686523 C 3.990441083908081 24.18301582336426 4.140453338623047 24.27635765075684 4.131986141204834 24.30471992492676 C 4.123415470123291 24.33302879333496 4.075263977050781 24.35572814941406 4.001660346984863 24.35287094116211 Z M 4.273999214172363 24.80535125732422 C 4.220446109771729 24.80472755432129 4.144608497619629 24.82321739196777 4.179618358612061 24.76639366149902 C 4.19265604019165 24.7452507019043 4.193019866943359 24.71122932434082 4.246572971343994 24.71122932434082 C 4.300075054168701 24.71122932434082 4.373470783233643 24.69912528991699 4.373470783233643 24.72592926025391 C 4.373470783233643 24.75293731689453 4.343031883239746 24.80618095397949 4.273999214172363 24.80534934997559 Z M 4.573555946350098 25.30130577087402 C 4.580827713012695 25.3387565612793 4.533923149108887 25.36000061035156 4.471643447875977 25.30130577087402 C 4.395650863647461 25.22962188720703 4.355186939239502 24.97987937927246 4.44047737121582 24.96637344360352 C 4.497927188873291 24.95728492736816 4.576412677764893 24.94840049743652 4.59334659576416 25.01535797119141 C 4.615941524505615 25.10475158691406 4.559272289276123 25.22790908813477 4.573556423187256 25.30130577087402 Z M 4.52228832244873 24.81579208374023 C 4.468786716461182 24.81506538391113 4.392897605895996 24.83552932739258 4.42790699005127 24.77267837524414 C 4.440944671630859 24.74920082092285 4.441308498382568 24.7115421295166 4.494862079620361 24.7115421295166 C 4.548363208770752 24.7115421295166 4.62186336517334 24.69803810119629 4.62186336517334 24.72779846191406 C 4.62186336517334 24.75777053833008 4.591320991516113 24.81682968139648 4.52228832244873 24.81579208374023 Z M 4.451852798461914 24.16032028198242 C 4.457462787628174 24.20281028747559 4.551220417022705 24.31895446777344 4.538338661193848 24.34155082702637 C 4.525404453277588 24.3641471862793 4.414661884307861 24.38970184326172 4.363861083984375 24.3641471862793 C 4.313112258911133 24.3387451171875 4.211199283599854 24.20681190490723 4.233846664428711 24.17512321472168 C 4.256494045257568 24.14338874816895 4.44047737121582 23.98698425292969 4.516937732696533 23.97743034362793 C 4.582697868347168 23.9692211151123 4.639055728912354 24.01093292236328 4.621915340423584 24.02614974975586 C 4.604722023010254 24.04147529602051 4.44619083404541 24.11793327331543 4.451852798461914 24.16032028198242 Z M 4.624512195587158 24.20057487487793 C 4.644354343414307 24.15185356140137 4.76044750213623 24.03300666809082 4.853841781616211 24.00750350952148 C 4.873216152191162 24.00225639343262 4.981258392333984 24.00812530517578 4.958611011505127 24.02620124816895 C 4.936015605926514 24.04427719116211 4.81992244720459 24.12354278564453 4.81992244720459 24.15476036071777 C 4.81992244720459 24.18577003479004 4.916484832763672 24.36414527893066 4.890877246856689 24.37551879882813 C 4.865269184112549 24.38689422607422 4.757694721221924 24.41801071166992 4.729333400726318 24.37551879882813 C 4.700921058654785 24.33303260803223 4.604669570922852 24.24935150146484 4.624512195587158 24.20057487487793 Z M 4.726112842559814 24.77221298217773 C 4.740865230560303 24.74691581726074 4.741229057312012 24.70645332336426 4.801535129547119 24.70645332336426 C 4.861841201782227 24.70645332336426 4.944378852844238 24.69206619262695 4.944378852844238 24.72406005859375 C 4.944378852844238 24.75621223449707 4.910148620605469 24.81953239440918 4.832337379455566 24.81854629516602 C 4.772082805633545 24.81781768798828 4.686688423156738 24.8397388458252 4.726113796234131 24.77221298217773 Z M 5.077457427978516 25.33875846862793 C 4.924484729766846 25.42768478393555 4.87648868560791 25.25886917114258 4.86797046661377 25.13706398010254 C 4.859451770782471 25.01535987854004 4.836233139038086 24.96668815612793 4.887760639190674 24.96024894714355 C 4.949832916259766 24.95245742797852 5.000789642333984 24.97775268554688 5.030552864074707 25.01743698120117 C 5.06031608581543 25.05702018737793 5.190745830535889 25.27289581298828 5.077457427978516 25.33875846862793 Z M 5.136309146881104 24.83152961730957 C 5.072731018066406 24.83059692382813 4.982816696166992 24.85480308532715 5.024319648742676 24.78057479858398 C 5.039851188659668 24.75273513793945 5.040266513824463 24.70827102661133 5.103845119476318 24.70827102661133 C 5.167319774627686 24.70827102661133 5.254480361938477 24.69237518310547 5.254480361938477 24.72754096984863 C 5.254480361938477 24.76291275024414 5.218328475952148 24.83257102966309 5.136309146881104 24.83153343200684 Z M 5.298268795013428 24.04999351501465 C 5.252974033355713 24.09528923034668 5.145399570465088 24.12640190124512 5.173760414123535 24.17450141906738 C 5.2254958152771 24.26254463195801 5.335044384002686 24.38409233093262 5.281334400177002 24.40388298034668 C 5.227520942687988 24.42362213134766 5.131218433380127 24.42928314208984 5.068990707397461 24.41795921325684 C 5.006710529327393 24.40658187866211 4.944430828094482 24.26503753662109 4.944430828094482 24.22259902954102 C 4.944430828094482 24.18011283874512 5.03507137298584 24.02152824401855 5.173812389373779 23.98189544677734 C 5.239104747772217 23.96330070495605 5.343510627746582 24.00464630126953 5.298268795013428 24.04999351501465 Z M 5.564425468444824 24.02729415893555 C 5.608889102935791 24.01804542541504 5.703114032745361 24.06978225708008 5.674805164337158 24.08396339416504 C 5.646547794342041 24.09809303283691 5.519546985626221 24.12920570373535 5.522195816040039 24.1943416595459 C 5.524793148040771 24.25947952270508 5.564114093780518 24.38118171691895 5.601097106933594 24.41229629516602 C 5.638029098510742 24.44351577758789 5.521987915039063 24.46045112609863 5.459707736968994 24.4321403503418 C 5.39737606048584 24.40388298034668 5.321175098419189 24.2599983215332 5.320967197418213 24.22270393371582 C 5.320655345916748 24.1772518157959 5.456851005554199 24.04998970031738 5.564424991607666 24.02729415893555 Z M 5.332551002502441 24.78462409973145 C 5.349536895751953 24.75621223449707 5.350055694580078 24.71086502075195 5.419867515563965 24.71086502075195 C 5.489679336547852 24.71086502075195 5.585358619689941 24.69465827941895 5.585358619689941 24.73060417175293 C 5.585358619689941 24.7666015625 5.5456223487854 24.8376579284668 5.455604076385498 24.83662033081055 C 5.385740756988525 24.83568382263184 5.286892890930176 24.8603572845459 5.332550048828125 24.78462409973145 Z M 5.439813613891602 25.3387565612793 C 5.360600471496582 25.30696678161621 5.295879364013672 24.97021675109863 5.377585887908936 24.96024513244629 C 5.422621250152588 24.95463752746582 5.522611618041992 24.93723487854004 5.563179492950439 24.97707557678223 C 5.614083766937256 25.02735710144043 5.623797416687012 25.30348777770996 5.644834041595459 25.33771705627441 C 5.662234783172607 25.36602592468262 5.519079208374023 25.37049674987793 5.439813613891602 25.3387565612793 Z M 5.656468868255615 24.78041839599609 C 5.673506736755371 24.74987411499023 5.673973560333252 24.70099830627441 5.743785381317139 24.70099830627441 C 5.813597202301025 24.70099830627441 5.909224987030029 24.68343925476074 5.909224987030029 24.72219085693359 C 5.909224987030029 24.76104354858398 5.869540214538574 24.83750534057617 5.779470920562744 24.83625602722168 C 5.709659576416016 24.83532333374023 5.61081075668335 24.86186790466309 5.656468868255615 24.78041839599609 Z M 5.920912742614746 25.34083366394043 C 5.830479621887207 25.32390213012695 5.799417018890381 25.07036399841309 5.821960926055908 25.01094245910645 C 5.844659805297852 24.951416015625 5.922834396362305 24.95505142211914 5.991867065429688 24.95863723754883 C 6.049836158752441 24.96159744262695 6.099338054656982 25.20183563232422 6.170292377471924 25.27860641479492 C 6.232520580291748 25.34597587585449 6.011345863342285 25.35782051086426 5.920912742614746 25.34083366394043 Z M 6.0829758644104 24.8387508392334 C 6.013164043426514 24.8377628326416 5.914368152618408 24.86638641357422 5.95997428894043 24.77855110168457 C 5.977012157440186 24.74577140808105 5.977478981018066 24.69315338134766 6.047343254089355 24.69315338134766 C 6.11710262298584 24.69315338134766 6.21278190612793 24.67435073852539 6.21278190612793 24.71595764160156 C 6.212729930877686 24.75771903991699 6.173045635223389 24.84010314941406 6.0829758644104 24.8387508392334 Z M 6.278022289276123 24.78545570373535 C 6.295008182525635 24.75268173217773 6.29552698135376 24.70001029968262 6.365338802337646 24.70001029968262 C 6.435099124908447 24.70001029968262 6.530830383300781 24.68120765686035 6.530830383300781 24.72286796569824 C 6.530830383300781 24.7645263671875 6.49109411239624 24.84696006774902 6.401075839996338 24.84560966491699 C 6.331160545349121 24.8446216583252 6.232364654541016 24.87324333190918 6.278021812438965 24.78545951843262 Z M 6.59492826461792 25.34784889221191 C 6.4961838722229 25.35532760620117 6.306123733520508 25.39469909667969 6.297657489776611 25.2164306640625 C 6.289138317108154 25.03800582885742 6.246700286865234 24.9806079864502 6.325965881347656 24.963623046875 C 6.370325565338135 24.95416831970215 6.489327907562256 24.94305229187012 6.530778408050537 24.9870491027832 C 6.572281360626221 25.03094100952148 6.707853317260742 25.33927536010742 6.59492826461792 25.34784889221191 Z M 6.586981296539307 24.7789134979248 C 6.60396671295166 24.74520111083984 6.604485988616943 24.69102478027344 6.674298286437988 24.69102478027344 C 6.744058132171631 24.69102478027344 6.839737892150879 24.67154693603516 6.839737892150879 24.71450424194336 C 6.839737892150879 24.75751495361328 6.800052165985107 24.84223175048828 6.709982872009277 24.84082984924316 C 6.640171051025391 24.8397388458252 6.541322708129883 24.86929512023926 6.586981296539307 24.7789134979248 Z M 7.104440212249756 25.37688255310059 C 7.015824794769287 25.40456962585449 6.842594146728516 25.38763427734375 6.827011108398438 25.33246994018555 C 6.811531543731689 25.2772045135498 6.707593441009521 24.9898509979248 6.768677711486816 24.97858238220215 C 6.839268684387207 24.96544075012207 6.934481143951416 24.96891975402832 7.04740571975708 25.01385116577148 C 7.143500804901123 25.05208206176758 7.155863285064697 25.36088562011719 7.104440212249756 25.37688255310059 Z M 7.050782203674316 24.85672187805176 C 6.952972888946533 24.85552597045898 6.814440250396729 24.88809776306152 6.878434658050537 24.78836441040039 C 6.902224540710449 24.75117301940918 6.902951717376709 24.69154357910156 7.000709533691406 24.69154357910156 C 7.098570823669434 24.69154357910156 7.232635498046875 24.67014122009277 7.232635498046875 24.7174072265625 C 7.232635498046875 24.76473045349121 7.176951885223389 24.85807037353516 7.050782203674316 24.85671997070313 Z M 7.294188499450684 24.79033851623535 C 7.31803035736084 24.75101852416992 7.3187575340271 24.68780326843262 7.416567325592041 24.68780326843262 C 7.514375686645508 24.68780326843262 7.648442268371582 24.66510391235352 7.648442268371582 24.7152271270752 C 7.648442268371582 24.7652530670166 7.59281063079834 24.86430549621582 7.466588497161865 24.86280059814453 C 7.368779182434082 24.86160659790039 7.230246067047119 24.89594078063965 7.294188499450684 24.79034042358398 Z M 7.59706974029541 25.39724349975586 C 7.541438102722168 25.4185905456543 7.347949028015137 25.41459465026855 7.321094512939453 25.38191795349121 C 7.298447132110596 25.35449028015137 7.325354099273682 25.01821327209473 7.428668975830078 25.03234100341797 C 7.514531135559082 25.04408073425293 7.648441314697266 25.03260040283203 7.688333034515381 25.04937934875488 C 7.731861591339111 25.06771278381348 7.65275239944458 25.37605094909668 7.597068309783936 25.39724349975586 Z M 8.058897018432617 25.36072731018066 C 7.959010124206543 25.38997077941895 7.822139739990234 25.38997077941895 7.789571762084961 25.35672760009766 C 7.763235569000244 25.32977104187012 7.726200103759766 25.07025909423828 7.79918098449707 25.0500545501709 C 7.853306293487549 25.03504180908203 7.993449211120605 25.03738021850586 8.075520515441895 25.05499076843262 C 8.115152359008789 25.06340408325195 8.146266937255859 25.33506965637207 8.058897018432617 25.36072731018066 Z M 8.449199676513672 25.35782051086426 C 8.378505706787109 25.37771224975586 8.262931823730469 25.38836097717285 8.251347541809082 25.34805488586426 C 8.230206489562988 25.27408599853516 8.247763633728027 25.14059257507324 8.260385513305664 25.06236457824707 C 8.268436431884766 25.01306915283203 8.545917510986328 25.02387619018555 8.545450210571289 25.06060028076172 C 8.545086860656738 25.09508895874023 8.56129264831543 25.3262882232666 8.449199676513672 25.35782051086426 Z M 8.89326286315918 25.34774017333984 C 8.881783485412598 25.38815498352051 8.766209602355957 25.3774528503418 8.695463180541992 25.35761260986328 C 8.583368301391602 25.32602882385254 8.599523544311523 25.09472465515137 8.599160194396973 25.06033897399902 C 8.598692893981934 25.02350997924805 8.876276969909668 25.01276016235352 8.884276390075684 25.06205368041992 C 8.896949768066406 25.14033126831055 8.914454460144043 25.27382469177246 8.89326286315918 25.34774017333984 Z M 9.021718978881836 24.67772674560547 C 8.985774040222168 24.67372703552246 9.312705039978027 24.68266105651855 9.312705039978027 24.68266105651855 C 9.314834594726563 24.70754051208496 9.244763374328613 24.86207389831543 9.223570823669434 24.87828063964844 C 9.202274322509766 24.89448547363281 8.977150917053223 24.87999153137207 8.953985214233398 24.88019943237305 C 8.930869102478027 24.88030433654785 9.021718978881836 24.6777229309082 9.021718978881836 24.6777229309082 Z M 9.355091094970703 25.35646820068359 C 9.322573661804199 25.3896598815918 9.185651779174805 25.3896598815918 9.085816383361816 25.36041450500488 C 8.998395919799805 25.33485794067383 8.967386245727539 25.04865074157715 9.006914138793945 25.04013442993164 C 9.08903694152832 25.02257537841797 9.291355133056641 25.03473091125488 9.345481872558594 25.0497932434082 C 9.41840934753418 25.06999969482422 9.381425857543945 25.32950973510742 9.355091094970703 25.35646820068359 Z M 9.344182968139648 24.72598075866699 C 9.362258911132813 24.68432235717773 9.478714942932129 24.70380020141602 9.569563865661621 24.70421409606934 C 9.660361289978027 24.70462989807129 9.645401954650879 24.75621032714844 9.646232604980469 24.78986740112305 C 9.648726463317871 24.88144493103027 9.545825958251953 24.85713577270508 9.454977035522461 24.86731719970703 C 9.323300361633301 24.88186264038086 9.326053619384766 24.76753425598145 9.344182968139648 24.72597694396973 Z M 9.823721885681152 25.3816089630127 C 9.796710968017578 25.41422843933105 9.603327751159668 25.41822814941406 9.547695159912109 25.39703559875488 C 9.491960525512695 25.3758430480957 9.412851333618164 25.06745719909668 9.456327438354492 25.04917144775391 C 9.49616813659668 25.0323429107666 9.646648406982422 25.02886199951172 9.716044425964355 25.03208160400391 C 9.82024097442627 25.03680801391602 9.84626579284668 25.35423469543457 9.823721885681152 25.3816089630127 Z M 9.722640037536621 24.73449897766113 C 9.725342750549316 24.69154357910156 9.856446266174316 24.71356391906738 9.947295188903809 24.71398162841797 C 10.03840351104736 24.71444892883301 10.02489852905273 24.76280784606934 10.02609348297119 24.79506492614746 C 10.02941799163818 24.88586235046387 9.948125839233398 24.86856651306152 9.847667694091797 24.86856651306152 C 9.731056213378906 24.86856651306152 9.717082977294922 24.82347869873047 9.722640037536621 24.73450088500977 Z M 10.26175975799561 25.34758758544922 C 10.24622917175293 25.40280151367188 10.11481285095215 25.42196846008301 10.02619647979736 25.39423179626465 C 9.974772453308105 25.37812805175781 9.847616195678711 25.03660011291504 9.948125839233398 25.01239395141602 C 10.06338691711426 24.98481369018555 10.1466007232666 24.99514961242676 10.21719074249268 25.0081901550293 C 10.27843284606934 25.01951026916504 10.27723789215088 25.29231643676758 10.26175975799561 25.34758758544922 Z M 10.40065574645996 25.39423179626465 C 10.37156867980957 25.38192176818848 10.31515884399414 25.04532814025879 10.35666084289551 25.00138664245605 C 10.39816188812256 24.95744132995605 10.53685092926025 24.98538589477539 10.58105659484863 24.99489212036133 C 10.66042518615723 25.01187705993652 10.58708095550537 25.12734603881836 10.66411399841309 25.28847694396973 C 10.73641777038574 25.43947601318359 10.49186897277832 25.43282508850098 10.40065574645996 25.39423370361328 Z M 10.53794288635254 24.86856651306152 C 10.45374298095703 24.86918830871582 10.48033809661865 24.77392578125 10.47446823120117 24.73756408691406 C 10.46849346160889 24.7011547088623 10.57134342193604 24.7194881439209 10.63616752624512 24.71990585327148 C 10.70109748840332 24.72016334533691 10.68302059173584 24.76275825500488 10.68717670440674 24.78945541381836 C 10.69876003265381 24.86051368713379 10.6031322479248 24.86794281005859 10.53794288635254 24.86856651306152 Z M 11.03259754180908 25.38192176818848 C 10.9434118270874 25.40487861633301 10.77350521087646 25.41765785217285 10.7804651260376 25.3468074798584 C 10.79064655303955 25.24276542663574 10.64754199981689 25.0318775177002 10.70561599731445 25.02886199951172 C 10.77454376220703 25.02522659301758 11.05950546264648 24.99110221862793 11.08220386505127 25.0505199432373 C 11.10474872589111 25.11005020141602 11.10474872589111 25.36327171325684 11.03259754180908 25.38192176818848 Z M 11.05659580230713 24.74156379699707 C 11.0706729888916 24.70894241333008 11.16089725494385 24.7146053314209 11.22577571868896 24.71496963500977 C 11.29065322875977 24.7152271270752 11.27049827575684 24.7638988494873 11.26987552642822 24.79184532165527 C 11.2683687210083 24.86991500854492 11.20650482177734 24.86581230163574 11.14126396179199 24.86628150939941 C 11.056960105896 24.86690521240234 11.04220867156982 24.77444648742676 11.05659580230713 24.7415657043457 Z M 11.4912052154541 25.36327171325684 C 11.41178417205811 25.39511489868164 11.29008293151855 25.40487861633301 11.29148387908936 25.38186836242676 C 11.29413223266602 25.34181976318359 11.18957138061523 25.08163642883301 11.24063110351563 25.03140830993652 C 11.28109550476074 24.99135780334473 11.49702262878418 25.01904296875 11.54200553894043 25.02449798583984 C 11.62371349334717 25.03468132019043 11.57047080993652 25.33153533935547 11.4912052154541 25.36327171325684 Z M 11.63446521759033 24.75595283508301 C 11.64610004425049 24.70795822143555 11.72775554656982 24.72805976867676 11.79268455505371 24.72831916809082 C 11.85745716094971 24.72868156433105 11.84483623504639 24.77719688415527 11.85080909729004 24.79953193664551 C 11.867431640625 24.85926628112793 11.78395843505859 24.83952903747559 11.71876907348633 24.83994674682617 C 11.63488006591797 24.84020805358887 11.62714099884033 24.78597640991211 11.63446521759033 24.75595283508301 Z M 11.78842449188232 25.38192176818848 C 11.71721076965332 25.3887767791748 11.73793601989746 25.30597877502441 11.74276638031006 25.20240592956543 C 11.74655914306641 25.11612510681152 11.71201705932617 25.0281867980957 11.72557544708252 25.01011085510254 C 11.75518226623535 24.97052955627441 11.87662506103516 24.98720550537109 11.93869781494141 24.99494361877441 C 11.99012184143066 25.00138664245605 12.01572895050049 25.19580841064453 12.01770305633545 25.31782341003418 C 12.01894950866699 25.39423370361328 11.97058963775635 25.36457252502441 11.78842449188232 25.38192176818848 Z M 12.0173397064209 24.83734703063965 C 11.94061851501465 24.83781433105469 11.93085384368896 24.78285789489746 11.94290447235107 24.75506782531738 C 11.95500755310059 24.72748374938965 12.03058528900146 24.7403678894043 12.0894889831543 24.74052429199219 C 12.14875602722168 24.74088668823242 12.13384914398193 24.77579307556152 12.13873100280762 24.79781913757324 C 12.15192413330078 24.85640907287598 12.07655429840088 24.8369312286377 12.0173397064209 24.83734512329102 Z M 12.15789794921875 24.40943717956543 C 12.1323413848877 24.45187377929688 12.07717800140381 24.5580997467041 12.00928783416748 24.57072257995605 C 11.94124221801758 24.58349990844727 11.83226585388184 24.57924270629883 11.84343338012695 24.52714347839355 C 11.85641956329346 24.46621322631836 11.88743019104004 24.41650390625 11.85215950012207 24.36731338500977 C 11.81169605255127 24.31095504760742 11.63171195983887 24.20675849914551 11.72895050048828 24.18011093139648 C 11.79039859771729 24.16333198547363 11.83517360687256 24.16031837463379 11.937087059021 24.19429206848145 C 12.03900051116943 24.22826194763184 12.18329906463623 24.3669490814209 12.15789890289307 24.4094409942627 Z M 12.25960159301758 23.63356018066406 C 12.26983547210693 23.66171264648438 12.21196937561035 23.68093109130859 12.19306182861328 23.65537643432617 C 12.16766262054443 23.62140655517578 12.16979122161865 23.51866340637207 12.21903419494629 23.47918510437012 C 12.26141929626465 23.44526672363281 12.25980949401855 23.39784049987793 12.27767753601074 23.39134979248047 C 12.30957126617432 23.37945556640625 12.31762218475342 23.51814270019531 12.27944374084473 23.52738761901855 C 12.24131774902344 23.5366325378418 12.24573230743408 23.59574699401855 12.25960159301758 23.63356018066406 Z M 12.35751533508301 24.2226505279541 C 12.42535305023193 24.27355575561523 12.4783353805542 24.45182228088379 12.46233654022217 24.52444076538086 C 12.45090866088867 24.57612419128418 12.37876033782959 24.576904296875 12.32354354858398 24.57082366943359 C 12.27269077301025 24.56542205810547 12.35304737091064 24.50402641296387 12.32354354858398 24.40954208374023 C 12.2796516418457 24.26950073242188 12.18189525604248 24.24976539611816 12.14091110229492 24.21418380737305 C 12.11493968963623 24.19179344177246 12.16064929962158 24.15876007080078 12.17695999145508 24.15834617614746 C 12.23726558685303 24.15652656555176 12.28941631317139 24.17164039611816 12.35751533508301 24.2226505279541 Z M 12.3040657043457 24.8286190032959 C 12.23160362243652 24.82898139953613 12.2213716506958 24.77895927429199 12.23238277435303 24.75382041931152 C 12.24339485168457 24.72873306274414 12.3151798248291 24.74031448364258 12.37112236022949 24.74067687988281 C 12.42722225189209 24.74093818664551 12.41376876831055 24.77272987365723 12.41880702972412 24.79267501831055 C 12.43220806121826 24.84586524963379 12.36042308807373 24.82830810546875 12.3040657043457 24.8286190032959 Z M 12.60305023193359 25.31782150268555 C 12.57074165344238 25.34046936035156 12.45454502105713 25.36955642700195 12.42046928405762 25.35225677490234 C 12.35330677032471 25.31782150268555 12.46519184112549 25.155029296875 12.4482593536377 25.06397438049316 C 12.43574142456055 24.99608421325684 12.58575248718262 25.03265190124512 12.63982677459717 25.0542106628418 C 12.75919246673584 25.10163497924805 12.68849754333496 25.25798225402832 12.60305118560791 25.31782341003418 Z M 12.53084850311279 24.7581844329834 C 12.54097747802734 24.73486137390137 12.60445213317871 24.74576950073242 12.65426540374756 24.7459774017334 C 12.70407962799072 24.74629211425781 12.69166564941406 24.77589797973633 12.69566440582275 24.79444313049316 C 12.70667743682861 24.84394264221191 12.64304637908936 24.82758140563965 12.59328460693359 24.82794570922852 C 12.52872085571289 24.82830810546875 12.5205135345459 24.78176689147949 12.53084945678711 24.75818824768066 Z M 12.68449687957764 24.43489074707031 C 12.64626693725586 24.39250373840332 12.51999187469482 24.21397590637207 12.58954429626465 24.19143104553223 C 12.6460075378418 24.17309379577637 12.7301549911499 24.19101715087891 12.76095676422119 24.20981788635254 C 12.80194091796875 24.23485374450684 12.85242938995361 24.35588455200195 12.84157371520996 24.43483924865723 C 12.83165264129639 24.50714302062988 12.84302711486816 24.56282615661621 12.7495288848877 24.56230926513672 C 12.65088939666748 24.56194305419922 12.72262191772461 24.47743034362793 12.68449687957764 24.43489074707031 Z M 12.99766254425049 23.49160003662109 L 12.99766254425049 23.34807968139648 L 12.88016700744629 23.34807968139648 C 12.90982723236084 23.22705459594727 12.95023822784424 23.09553146362305 12.99013137817383 22.9421443939209 C 12.99013137817383 22.9421443939209 13.38043308258057 23.0709114074707 13.77608585357666 22.89180946350098 C 13.84356021881104 22.8613224029541 13.86205101013184 22.91996383666992 13.84356021881104 22.9421443939209 C 13.80060291290283 22.99341201782227 13.67967891693115 22.99507331848145 13.56675338745117 23.1109619140625 L 13.56675338745117 23.05351066589355 L 13.44110298156738 23.05351066589355 L 13.44110298156738 23.13838577270508 L 13.54176712036133 23.13838577270508 C 13.48894214630127 23.20186042785645 13.43923187255859 23.29354095458984 13.40203952789307 23.43186569213867 C 13.36220073699951 23.5798511505127 13.27493572235107 23.72617721557617 13.19473457336426 23.83873558044434 L 13.19473457336426 23.82762336730957 L 13.06913566589355 23.82762336730957 L 13.06913566589355 23.94085693359375 L 13.11754703521729 23.94085693359375 C 13.0665397644043 24.00422859191895 13.02950382232666 24.04303359985352 13.02950382232666 24.04303359985352 C 13.02950382232666 24.04303359985352 12.96306800842285 24.02786445617676 12.90790462493896 23.94085693359375 L 12.96202945709229 23.94085693359375 L 12.96202945709229 23.82762336730957 L 12.85964965820313 23.82762336730957 C 12.85393524169922 23.80663871765137 12.84874153137207 23.78414535522461 12.84479427337646 23.75890159606934 C 12.84333992004395 23.74923896789551 12.84318351745605 23.73968124389648 12.84219741821289 23.73002052307129 L 12.93486309051514 23.73002052307129 L 12.93486309051514 23.58982467651367 L 12.83897686004639 23.58982467651367 C 12.84354782104492 23.52250862121582 12.85528659820557 23.4536304473877 12.87206363677979 23.38070297241211 L 12.87206363677979 23.49165153503418 L 12.99766254425049 23.49165153503418 Z M 12.82754898071289 24.82077598571777 C 12.76313877105713 24.82108879089355 12.75290775299072 24.77911567687988 12.76215267181396 24.75787353515625 C 12.77134609222412 24.73678398132324 12.83539199829102 24.7465991973877 12.88504886627197 24.74686050415039 C 12.93486309051514 24.74706649780273 12.92359161376953 24.77392196655273 12.92836952209473 24.79059791564941 C 12.94161510467529 24.83521842956543 12.87741374969482 24.8205680847168 12.82754898071289 24.82077598571777 Z M 12.94551277160645 24.18852233886719 C 12.98571491241455 24.1647834777832 13.13307952880859 24.1838493347168 13.13884544372559 24.2055606842041 C 13.15530967712402 24.26841163635254 13.2237720489502 24.44060134887695 13.19125556945801 24.46330070495605 C 13.13687133789063 24.50137519836426 13.08212280273438 24.52444076538086 13.04970932006836 24.49862289428711 C 12.9943380355835 24.45467948913574 12.91439914703369 24.2070140838623 12.94551277160645 24.18852233886719 Z M 13.05947494506836 24.82347869873047 C 12.99496173858643 24.82383918762207 12.98410606384277 24.78368949890137 12.99283218383789 24.76337623596191 C 13.00161075592041 24.74322319030762 13.06591606140137 24.75262451171875 13.11578273773193 24.75293731689453 C 13.16543865203857 24.75319862365723 13.15453243255615 24.77875328063965 13.15988159179688 24.79469871520996 C 13.17374992370605 24.83739852905273 13.1095495223999 24.82321739196777 13.05947494506836 24.8234748840332 Z M 13.19821548461914 25.2024040222168 C 13.08679676055908 25.35516929626465 12.97184753417969 25.34763526916504 12.96047210693359 25.30550956726074 C 12.95361614227295 25.27969360351563 13.06919002532959 25.19757270812988 13.07609748840332 25.11441040039063 C 13.08295345306396 25.0280818939209 13.0715274810791 24.95053100585938 13.10918617248535 24.94876480102539 C 13.22797966003418 24.94310188293457 13.27467632293701 25.09732055664063 13.19821548461914 25.2024040222168 Z M 13.28142929077148 24.82093238830566 C 13.22455215454102 24.82108879089355 13.21405982971191 24.78737831115723 13.22174644470215 24.77033996582031 C 13.22901916503906 24.75335311889648 13.28584480285645 24.7613525390625 13.32963371276855 24.76156234741211 C 13.37347221374512 24.76177024841309 13.36443614959717 24.78316879272461 13.36942005157471 24.79662322998047 C 13.38230133056641 24.83267211914063 13.32542514801025 24.82067108154297 13.28142833709717 24.8209285736084 Z M 13.35238456726074 24.48163986206055 C 13.31784152984619 24.43489074707031 13.2214879989624 24.18405342102051 13.26335430145264 24.15751457214355 C 13.29877853393555 24.13491630554199 13.34682559967041 24.14193153381348 13.36807155609131 24.1801586151123 C 13.38931655883789 24.21844100952148 13.4605827331543 24.35001564025879 13.43606567382813 24.39016723632813 C 13.4119119644165 24.42948722839355 13.36807155609131 24.50288581848145 13.35238456726074 24.48163986206055 Z M 13.47393226623535 24.81781578063965 C 13.43616962432861 24.81807327270508 13.43227291107178 24.78841400146484 13.43887138366699 24.77330017089844 C 13.44546890258789 24.75839233398438 13.48250293731689 24.76535224914551 13.5115385055542 24.76556015014648 C 13.54073238372803 24.76571464538574 13.53268051147461 24.78457069396973 13.53460121154785 24.79651832580566 C 13.54000282287598 24.82810211181641 13.50333213806152 24.81755638122559 13.47393226623535 24.81781768798828 Z M 13.63142395019531 24.43914794921875 C 13.58254528045654 24.39084053039551 13.54774475097656 24.23573875427246 13.53553676605225 24.19444274902344 C 13.52270698547363 24.15008354187012 13.56820964813232 24.14561462402344 13.5958948135376 24.14468193054199 C 13.66747188568115 24.14224052429199 13.74746513366699 24.32861137390137 13.74746513366699 24.36144065856934 C 13.74751663208008 24.3941650390625 13.64269542694092 24.45026397705078 13.63142395019531 24.43914794921875 Z M 13.61755657196045 23.87509346008301 C 13.59142875671387 23.93342781066895 13.49190330505371 23.91971397399902 13.32927131652832 23.92553329467773 C 13.27982139587402 23.92734909057617 13.30501270294189 23.71448707580566 13.35041236877441 23.68009948730469 C 13.52696800231934 23.54644966125488 13.41347122192383 23.48671531677246 13.51574897766113 23.40760612487793 C 13.55938148498535 23.37384223937988 13.70284843444824 23.12794494628906 13.89041614532471 22.97554206848145 C 13.94355487823486 22.93232345581055 13.9010648727417 22.91596221923828 13.9010648727417 22.91596221923828 C 13.9010648727417 22.91596221923828 13.88179302215576 22.67588043212891 13.91456985473633 22.66601181030273 C 13.97124004364014 22.64887237548828 14.03263759613037 22.48098945617676 14.02401447296143 22.4641056060791 C 14.01518249511719 22.44727897644043 13.96329212188721 22.53765869140625 13.83265495300293 22.66481781005859 C 13.67048835754395 22.82256889343262 13.19697380065918 22.87887573242188 13.02483367919922 22.71483993530273 C 12.96322822570801 22.65619468688965 13.04644203186035 22.68829727172852 13.15998935699463 22.48369216918945 C 13.23468494415283 22.34905433654785 13.25177383422852 22.19099044799805 13.24470996856689 22.08352088928223 C 13.23561859130859 21.94441604614258 13.1750020980835 21.79726219177246 13.14466762542725 21.79170227050781 C 13.13173294067383 21.78936386108398 13.19011878967285 22.05380821228027 13.0623893737793 22.29471969604492 C 12.98691463470459 22.43704414367676 12.93543910980225 22.52924537658691 12.82838439941406 22.62398719787598 C 12.78890705108643 22.65904808044434 12.82131958007813 22.75898742675781 12.8766393661499 22.74652099609375 C 12.95003509521484 22.73005867004395 12.8873929977417 23.07906341552734 12.8475513458252 23.12202262878418 C 12.79082870483398 23.18325996398926 12.75337791442871 23.26221656799316 12.74184703826904 23.35150337219238 C 12.73026371002197 23.4409008026123 12.69681167602539 23.51185607910156 12.70647239685059 23.60514450073242 C 12.71613502502441 23.69853973388672 12.76984405517578 23.78497314453125 12.72870540618896 23.79312705993652 C 12.67515182495117 23.80377578735352 12.66684055328369 23.92553329467773 12.67567157745361 23.95425605773926 C 12.69026756286621 24.00240707397461 12.36229705810547 24.02936363220215 12.31492519378662 23.97482299804688 C 12.26755142211914 23.9201774597168 12.3734130859375 23.89545440673828 12.40270805358887 23.86532783508301 C 12.43200397491455 23.8351993560791 12.42831707000732 23.59231376647949 12.39190483093262 23.57532691955566 C 12.35923290252686 23.56016159057617 12.32308006286621 23.48053169250488 12.36214160919189 23.46375465393066 C 12.44384860992432 23.42874336242676 12.44436836242676 23.54031753540039 12.46524906158447 23.56015968322754 C 12.48389625549316 23.57776641845703 12.53137302398682 23.55512046813965 12.54981422424316 23.52805709838867 C 12.58045959472656 23.48260688781738 12.57926464080811 23.40578460693359 12.55537033081055 23.30132675170898 C 12.51714038848877 23.1350040435791 12.32536602020264 23.02410316467285 12.34868812561035 22.96920204162598 C 12.36271286010742 22.93637466430664 12.40203285217285 22.82760238647461 12.37637424468994 22.80817413330078 C 12.37637424468994 22.80817413330078 12.30604362487793 22.9525260925293 12.25363159179688 22.96774291992188 C 12.21576499938965 22.97849655151367 12.30827713012695 23.13167762756348 12.26625347137451 23.16201210021973 C 12.22418117523193 23.19234848022461 12.17841815948486 23.26506805419922 12.1959753036499 23.31581497192383 C 12.21353149414063 23.36656379699707 12.12283897399902 23.57163619995117 12.06834983825684 23.62326622009277 C 12.01386165618896 23.67490196228027 11.89075469970703 24.01622009277344 11.77590942382813 24.00505065917969 C 11.66111469268799 23.99372863769531 11.46638011932373 24.04296875 11.47832679748535 23.97918319702148 C 11.49027252197266 23.91529273986816 11.68812561035156 23.78107261657715 11.71705722808838 23.71697616577148 C 11.74593830108643 23.65287780761719 11.90706634521484 23.30257225036621 11.9064416885376 23.25161552429199 C 11.9057149887085 23.20076179504395 11.87906837463379 23.10762977600098 11.93298530578613 23.00499153137207 C 11.98695468902588 22.90224838256836 12.11120319366455 22.99132919311523 12.21150588989258 22.86760139465332 C 12.21721839904785 22.8604850769043 12.42275810241699 22.62689399719238 12.48628520965576 22.45049667358398 C 12.51765918731689 22.36328506469727 12.56887340545654 22.09323120117188 12.59957218170166 22.00876998901367 C 12.65691947937012 21.85112190246582 12.51760673522949 22.09260940551758 12.4752721786499 22.18304252624512 C 12.44073009490967 22.25679969787598 12.41325187683105 22.36743927001953 12.37876033782959 22.45891189575195 C 12.34089469909668 22.55947494506836 12.26277256011963 22.69364356994629 12.20386791229248 22.75145530700684 C 12.12117481231689 22.83264350891113 11.99438095092773 22.83980941772461 11.99656295776367 22.74491119384766 C 11.99697875976563 22.73047065734863 12.02939033508301 22.68948745727539 12.05785655975342 22.64273643493652 C 12.07141304016113 22.62055587768555 12.18226051330566 22.40011024475098 12.28817272186279 22.21238708496094 C 12.36468505859375 22.07691955566406 12.55256366729736 21.78816604614258 12.56991386413574 21.74048233032227 C 12.58336639404297 21.70370674133301 12.35315322875977 22.00471687316895 12.25991439819336 22.15229034423828 C 12.15576839447021 22.31741523742676 12.04382991790771 22.49953079223633 12.01567840576172 22.54310989379883 C 11.99235439300537 22.57915878295898 11.93714046478271 22.58975601196289 11.89039134979248 22.57064056396484 C 11.82733154296875 22.54482460021973 11.77445316314697 22.46031379699707 11.79928112030029 22.41055107116699 C 11.80629444122314 22.39647483825684 11.90514183044434 22.30297660827637 11.94721698760986 22.26168251037598 C 11.99469375610352 22.21472549438477 12.1348352432251 22.09421539306641 12.22791957855225 21.97407341003418 C 12.26796627044678 21.92259788513184 12.48820686340332 21.56107139587402 12.48067474365234 21.54512596130371 C 12.47766208648682 21.53852653503418 12.21690654754639 21.89984703063965 12.15109539031982 21.96731948852539 C 12.05900001525879 22.06154632568359 11.92134952545166 22.18485832214355 11.86971759796143 22.20745277404785 C 11.80130767822266 22.23726844787598 11.74598979949951 22.22028350830078 11.72572994232178 22.18511772155762 C 11.69908428192139 22.13919830322266 11.79626941680908 22.13244819641113 11.84073257446289 22.09987831115723 C 11.90072822570801 22.0561408996582 12.04736423492432 21.90613174438477 12.07733535766602 21.87839126586914 C 12.10642242431641 21.85153770446777 12.20251846313477 21.75570297241211 12.25362968444824 21.69794273376465 C 12.35408878326416 21.58408355712891 12.4539737701416 21.38181495666504 12.41584777832031 21.42638206481934 C 12.40769290924072 21.43583679199219 12.33040046691895 21.55348777770996 12.28001689910889 21.60906791687012 C 12.21789264678955 21.67711067199707 12.11229228973389 21.77705192565918 12.00544452667236 21.88088607788086 C 11.97916126251221 21.9063892364502 11.86114597320557 22.00648498535156 11.82296848297119 22.02575874328613 C 11.77907562255859 22.04793548583984 11.73643112182617 22.06071472167969 11.70967960357666 22.04377937316895 C 11.66100883483887 22.01277160644531 11.69487476348877 21.9867992401123 11.72006702423096 21.95984077453613 C 11.74520874023438 21.93283081054688 11.95319080352783 21.82255363464355 11.96981143951416 21.78561973571777 C 11.98617362976074 21.74853515625 11.80909824371338 21.84062957763672 11.74110507965088 21.84146118164063 C 11.67466926574707 21.84239768981934 11.65248966217041 21.78120803833008 11.72292423248291 21.74630165100098 C 11.77388191223145 21.7210578918457 11.89584445953369 21.65695762634277 11.92498397827148 21.61010360717773 C 11.98383522033691 21.51530838012695 11.97048568725586 21.48980331420898 11.87776756286621 21.52803611755371 C 11.82655239105225 21.54912567138672 11.82125377655029 21.56719970703125 11.75461006164551 21.57026481628418 C 11.69752407073975 21.57301902770996 11.64345169067383 21.51187896728516 11.69690132141113 21.4734935760498 C 11.76255798339844 21.42601776123047 11.86358833312988 21.37334823608398 11.92197132110596 21.38331985473633 C 11.97318649291992 21.39194297790527 12.12314796447754 21.36472511291504 12.12532806396484 21.33345603942871 C 12.128342628479 21.29018592834473 12.0115213394165 21.2265567779541 11.91807556152344 21.22868537902832 C 11.85802745819092 21.23003768920898 11.86166477203369 21.24801063537598 11.80800724029541 21.31200408935547 C 11.70791149139404 21.43126678466797 11.4766092300415 21.33626365661621 11.4701681137085 21.27351379394531 C 11.46653079986572 21.23756980895996 11.72791004180908 21.37272644042969 11.78182697296143 21.23237609863281 C 11.82260417938232 21.12651634216309 11.75834846496582 21.0799732208252 11.70516014099121 21.06028938293457 C 11.67591571807861 21.04948234558105 11.58340454101563 21.03192710876465 11.55390167236328 21.04813385009766 C 11.46450614929199 21.09706115722656 11.54340744018555 20.99229431152344 11.64059352874756 20.96943855285645 C 11.69040679931641 20.95769882202148 11.77372455596924 20.91946792602539 11.73440361022949 20.88274383544922 C 11.71352291107178 20.86326599121094 11.66926765441895 20.8721981048584 11.64189338684082 20.83391571044922 C 11.62412929534912 20.80898284912109 11.56532764434814 20.49696159362793 11.72656059265137 20.40034866333008 C 11.80478668212891 20.35339164733887 11.81574630737305 20.33245849609375 11.81756591796875 20.28986358642578 C 11.82073497772217 20.21054458618164 11.73725986480713 20.16410827636719 11.71076965332031 20.14400672912598 C 11.68043518066406 20.12099456787109 11.67461681365967 20.06068801879883 11.70365238189697 20.02235412597656 C 11.72650909423828 19.99191665649414 11.78613948822021 20.0197582244873 11.7627649307251 19.978515625 C 11.73424816131592 19.92844009399414 11.76214218139648 19.85130500793457 11.77969932556152 19.82871055603027 C 11.81107234954834 19.78798675537109 11.91210174560547 19.72092819213867 11.96726608276367 19.72020149230957 C 11.98425102233887 19.71999359130859 11.91397190093994 19.88138008117676 11.90628528594971 19.93046760559082 C 11.90083122253418 19.96589469909668 11.89096260070801 20.06022262573242 11.93828201293945 20.1147632598877 C 11.96446132659912 20.14488792419434 12.00731468200684 20.1811466217041 12.08652877807617 20.20701599121094 C 12.14501667022705 20.22602653503418 12.22324275970459 20.22301292419434 12.26905632019043 20.19901657104492 C 12.29471683502197 20.18566703796387 12.34749126434326 20.13133430480957 12.35621738433838 20.11580276489258 C 12.43356037139893 19.97893333435059 12.3391284942627 19.90652275085449 12.37195587158203 19.82102584838867 C 12.37969493865967 19.80123329162598 12.45418167114258 19.82149124145508 12.4887752532959 19.86772155761719 C 12.52336978912354 19.91410636901855 12.56617164611816 19.97363471984863 12.54903030395508 20.08775329589844 C 12.52736949920654 20.23241424560547 12.5700159072876 20.16925239562988 12.60507678985596 20.19345664978027 C 12.65473365783691 20.22794723510742 12.66948699951172 20.24269866943359 12.67255115509033 20.28788948059082 C 12.67587471008301 20.33806610107422 12.63260650634766 20.32492446899414 12.62793159484863 20.35001373291016 C 12.61910152435303 20.39852905273438 12.65686416625977 20.46673011779785 12.62684059143066 20.4803409576416 C 12.54555034637451 20.51711654663086 12.59562301635742 20.59799194335938 12.66169548034668 20.57887840270996 C 12.71286010742188 20.56402206420898 12.69473171234131 20.61934089660645 12.66257762908936 20.64682006835938 C 12.61536312103271 20.6871280670166 12.67426490783691 20.8590087890625 12.59884357452393 20.94487190246582 C 12.55967807769775 20.98959350585938 12.49386692047119 21.07109260559082 12.42820930480957 21.10599899291992 C 12.34671211242676 21.14921379089355 12.21825504302979 21.10381698608398 12.1791410446167 21.12417602539063 C 12.13088703155518 21.14921379089355 12.11317348480225 21.18661499023438 12.18584251403809 21.18256187438965 C 12.24168109893799 21.17939376831055 12.27061462402344 21.2269229888916 12.27643203735352 21.25164604187012 C 12.28770351409912 21.29865646362305 12.28022289276123 21.34680557250977 12.25155162811279 21.37303733825684 C 12.20059394836426 21.41957855224609 12.20490550994873 21.45682334899902 12.2409553527832 21.43879890441895 C 12.34291839599609 21.38784027099609 12.32473945617676 21.34321975708008 12.40416049957275 21.27870750427246 C 12.42530059814453 21.26140975952148 12.48186683654785 21.24671363830566 12.53708362579346 21.20063972473145 C 12.57443141937256 21.1693172454834 12.60570049285889 21.1497859954834 12.70309448242188 21.11358261108398 C 12.78184032440186 21.08428573608398 12.76760673522949 20.92591094970703 12.91403579711914 20.86451148986816 C 13.03044033050537 20.8156852722168 13.14227390289307 20.84440994262695 13.19260692596436 20.86949920654297 C 13.26080894470215 20.90326309204102 13.40079593658447 20.99691772460938 13.3235559463501 21.14801979064941 C 13.25504302978516 21.28182411193848 13.2019567489624 21.33309364318848 13.15484523773193 21.36233711242676 C 13.09168148040771 21.40139961242676 13.0976037979126 21.52611541748047 13.15946769714355 21.59410858154297 C 13.1897497177124 21.62750816345215 13.21671104431152 21.70355415344238 13.26834106445313 21.74173164367676 C 13.34542369842529 21.79876708984375 13.35659217834473 21.78219604492188 13.47471141815186 21.72209739685059 C 13.55101585388184 21.68324661254883 13.5927267074585 21.64330101013184 13.69822406768799 21.6452751159668 C 13.84537887573242 21.64807891845703 13.97477149963379 21.67835998535156 14.10701656341553 21.73809432983398 C 14.16031169891357 21.76214790344238 14.24975681304932 21.82676315307617 14.30190944671631 21.92805480957031 C 14.32601070404053 21.97459411621094 14.32107543945313 22.02809715270996 14.33795738220215 22.0833625793457 C 14.3579568862915 22.14850044250488 14.39810752868652 22.21654510498047 14.39992523193359 22.28916358947754 C 14.40382194519043 22.44197845458984 14.33104991912842 22.48130226135254 14.34387874603271 22.5446720123291 C 14.36517524719238 22.64923286437988 14.3162956237793 22.81685447692871 14.27526092529297 22.82168579101563 C 14.21651172637939 22.82843971252441 14.14426040649414 22.86542320251465 14.14924716949463 22.93362426757813 C 14.15366077423096 22.99465560913086 14.14348125457764 23.05091094970703 14.11106967926025 23.09272384643555 C 14.07860469818115 23.13474464416504 13.99570274353027 23.1921443939209 13.91607475280762 23.28922462463379 C 13.86402606964111 23.35259628295898 13.86974048614502 23.42832946777344 13.84195041656494 23.47279357910156 C 13.80174732208252 23.53699493408203 13.74923229217529 23.62820816040039 13.7515697479248 23.7075252532959 C 13.75380325317383 23.79427146911621 13.63999557495117 23.82450103759766 13.61755752563477 23.87509346008301 Z M 11.67659091949463 21.17654037475586 C 11.74463748931885 21.17944717407227 11.73606777191162 21.22754669189453 11.71056270599365 21.2415714263916 C 11.68511009216309 21.25570106506348 11.63145351409912 21.24448204040527 11.60864925384521 21.22458648681641 C 11.5860013961792 21.20484733581543 11.64984035491943 21.17534446716309 11.67659091949463 21.17654228210449 Z M 13.93674659729004 23.71957778930664 C 13.94329166412354 23.78170204162598 13.95757579803467 23.9029369354248 13.93020057678223 23.92626190185547 C 13.91347503662109 23.94054222106934 13.88989353179932 23.91509246826172 13.86776638031006 23.85701751708984 C 13.85514354705811 23.82351684570313 13.82247066497803 23.63901329040527 13.86381816864014 23.54780006408691 C 13.89555644989014 23.47757339477539 13.92054176330566 23.44359970092773 13.98401546478271 23.43295478820801 C 14.04021835327148 23.42344665527344 14.06395626068115 23.48006820678711 14.04203605651855 23.54265975952148 C 14.02027034759521 23.60519981384277 13.93020057678223 23.65729904174805 13.93674659729004 23.71957778930664 Z M 13.96261310577393 24.34767723083496 C 13.95341968536377 24.35806465148926 13.91035747528076 24.39297294616699 13.90038585662842 24.31505584716797 C 13.89275074005127 24.25511360168457 13.7165584564209 24.12021636962891 13.79712200164795 24.1074390411377 C 13.79712200164795 24.1074390411377 13.88459396362305 24.09486770629883 13.91435718536377 24.12509918212891 C 13.94396591186523 24.15527725219727 14.04567050933838 24.26347732543945 14.04748725891113 24.28420066833496 C 14.04915046691895 24.30497741699219 13.99118137359619 24.31505393981934 13.96261215209961 24.3476734161377 Z M 14.26263809204102 24.26726913452148 C 14.24871730804443 24.27672004699707 14.19578838348389 24.28996849060059 14.17454147338867 24.27292823791504 C 14.15334892272949 24.25599670410156 14.14238929748535 24.22400093078613 14.13818073272705 24.20425987243652 C 14.13392162322998 24.18447113037109 14.02213859558105 24.09237670898438 14.02780151367188 24.08100128173828 C 14.03346252441406 24.06978034973145 14.07434177398682 24.04313278198242 14.07434177398682 24.04313278198242 C 14.11054706573486 24.0402774810791 14.23157501220703 24.15190315246582 14.24575424194336 24.19008255004883 C 14.2598819732666 24.22831153869629 14.2810230255127 24.25448989868164 14.26263523101807 24.26726913452148 Z M 14.46900844573975 24.1850414276123 C 14.42501163482666 24.21786880493164 14.38766479492188 24.23480224609375 14.37415981292725 24.21651649475098 C 14.3446044921875 24.17652320861816 14.35343551635742 24.14535713195801 14.33068466186523 24.104736328125 C 14.3079833984375 24.06416893005371 14.25037956237793 23.99887657165527 14.28959655761719 23.99337005615234 C 14.35042190551758 23.9848518371582 14.40023612976074 24.02250862121582 14.4411153793335 24.08671188354492 C 14.47030735015869 24.13278388977051 14.51284885406494 24.15216064453125 14.46900844573975 24.18503952026367 Z M 14.65750980377197 23.78258514404297 C 14.60535907745361 23.92205238342285 14.52739238739014 21.7223072052002 14.52749729156494 21.54518127441406 C 14.52749729156494 21.40851593017578 14.45836067199707 20.1760082244873 14.56328582763672 20.1005859375 C 14.60385417938232 20.0713939666748 14.70857048034668 20.44039916992188 14.73178768157959 21.08864974975586 C 14.7511625289917 21.63036727905273 14.77765464782715 23.46084976196289 14.65750980377197 23.78258514404297 Z M 14.71719169616699 19.00458526611328 C 14.75443553924561 18.99933815002441 14.78788757324219 19.05014038085938 14.78788757324219 19.13522338867188 C 14.78788757324219 19.22035789489746 14.79074287414551 19.30803680419922 14.77090167999268 19.31515312194824 C 14.7511625289917 19.3222713470459 14.73116397857666 19.23723983764648 14.71719169616699 19.18067359924316 C 14.70301151275635 19.12400245666504 14.66052150726318 19.01253318786621 14.71719169616699 19.00458526611328 Z M 15.01420307159424 22.81285858154297 C 15.00303554534912 23.14119148254395 14.93826198577881 23.65600204467773 14.90912246704102 23.78108024597168 C 14.89421463012695 23.84564781188965 14.81333827972412 21.86593246459961 14.81401348114014 21.72703552246094 C 14.81427383422852 21.63862800598145 14.81297492980957 20.15310287475586 14.85265827178955 20.17481422424316 C 14.98604869842529 20.24789810180664 14.98604869842529 20.95001602172852 14.98604869842529 21.24790954589844 C 14.98604869842529 21.42140007019043 15.0266170501709 22.44992828369141 15.01420211791992 22.8128547668457 Z M 14.94371700286865 19.79105949401855 C 14.90631771087646 19.86861038208008 14.78513431549072 19.85723495483398 14.78788757324219 19.75812721252441 C 14.79115867614746 19.64447593688965 14.70825862884521 19.53518676757813 14.74856567382813 19.5344066619873 C 14.80201530456543 19.53347015380859 14.84990787506104 19.55154609680176 14.88985157012939 19.58463668823242 C 14.95566368103027 19.63933372497559 14.96356010437012 19.74971389770508 14.94371700286865 19.79105949401855 Z M 14.17329406738281 18.04373931884766 C 14.23006725311279 18.05438613891602 14.29593086242676 18.10108375549316 14.32444858551025 18.13235282897949 C 14.3704195022583 18.1826343536377 14.33317565917969 18.48182678222656 14.34948539733887 18.53122520446777 C 14.36714553833008 18.5847282409668 14.45960426330566 18.65225410461426 14.87452793121338 18.8585205078125 C 14.89478588104248 18.86854553222656 14.94875431060791 18.98458671569824 14.94132804870605 19.07595443725586 C 14.93701553344727 19.13070297241211 14.92667961120605 19.27115821838379 14.86995792388916 19.27115821838379 C 14.82788372039795 19.27115821838379 14.81676959991455 19.2329273223877 14.84528350830078 19.10992431640625 C 14.86995792388916 19.00463485717773 14.79936599731445 18.92438316345215 14.78222560882568 18.9145679473877 C 14.73656749725342 18.8884391784668 14.66820907592773 18.8957633972168 14.63787651062012 18.9145679473877 C 14.58427047729492 18.94786262512207 14.59325695037842 19.03543853759766 14.60941028594971 19.14950752258301 C 14.6207332611084 19.22835731506348 14.70851802825928 19.24856376647949 14.66613292694092 19.35707092285156 C 14.65885925292969 19.37545967102051 14.52900314331055 19.40984535217285 14.4962272644043 19.3334903717041 C 14.47934436798096 19.29406547546387 14.52489948272705 19.22851181030273 14.52905368804932 19.20389175415039 C 14.55289745330811 19.06089210510254 14.52822399139404 18.92869567871094 14.52048301696777 18.92521667480469 C 14.47394275665283 18.90381622314453 14.24684619903564 18.69401741027832 14.24892520904541 18.6373462677002 C 14.25084590911865 18.5806770324707 14.22934150695801 18.43928718566895 14.14768600463867 18.40084838867188 C 14.13381862640381 18.3944091796875 14.12114429473877 18.16897392272949 13.95856189727783 18.08768463134766 C 13.94677066802979 18.03537750244141 14.11651992797852 18.03314399719238 14.17329502105713 18.04373931884766 Z M 13.55283164978027 18.16066360473633 C 13.64471912384033 18.1220703125 13.77405738830566 18.18388175964355 13.83768844604492 18.20652961730957 C 13.98380374908447 18.25836753845215 14.04998111724854 18.3010139465332 14.05886268615723 18.37944984436035 C 14.0646276473999 18.43134117126465 14.03242301940918 18.71588516235352 14.0646276473999 18.7955150604248 C 14.09756088256836 18.8774299621582 14.12083053588867 18.96640968322754 14.1342830657959 19.0405330657959 C 14.14685344696045 19.10940933227539 14.13386917114258 19.18992233276367 14.12909030914307 19.24991607666016 C 14.12607574462891 19.28632736206055 14.05865573883057 19.28087425231934 14.0136194229126 19.27110862731934 C 13.98349285125732 19.26456260681152 14.06026649475098 19.06733322143555 14.01138687133789 18.87831115722656 C 14.00053024291992 18.83639335632324 13.92432975769043 18.76154518127441 13.8458423614502 18.71697616577148 C 13.70798587799072 18.63875007629395 13.58555603027344 18.38936996459961 13.56976413726807 18.32844161987305 C 13.55283164978027 18.26294136047363 13.48717498779297 18.18840026855469 13.55283164978027 18.16066360473633 Z M 13.36090087890625 18.39248657226563 C 13.38765144348145 18.5345516204834 13.3814172744751 18.66108512878418 13.45019054412842 18.72689628601074 C 13.51891040802002 18.79265594482422 13.68435096740723 18.89976501464844 13.77997875213623 18.94209861755371 C 13.85212802886963 18.97393989562988 13.84267425537109 19.08582496643066 13.82189559936523 19.14763832092285 C 13.77997875213623 19.27204322814941 13.66762542724609 19.37026786804199 13.68180656433105 19.09159278869629 C 13.68663597106934 18.99845695495605 13.4926290512085 18.96017646789551 13.44536018371582 19.00198745727539 C 13.37237930297852 19.06650352478027 13.40183162689209 19.18238639831543 13.34365463256836 19.19469833374023 C 13.25213146209717 19.21412467956543 13.25820827484131 18.98417091369629 13.32147598266602 18.94796562194824 C 13.36001777648926 18.92599487304688 13.26480484008789 18.5109691619873 13.11931324005127 18.42536544799805 C 13.02415180206299 18.36942291259766 13.1650218963623 18.67531776428223 13.12414264678955 18.79551315307617 C 13.08071804046631 18.92324256896973 13.12793445587158 19.1461296081543 12.95423698425293 19.12400245666504 C 12.6522388458252 19.08535766601563 12.46716499328613 18.5376148223877 12.36031723022461 18.48546600341797 C 12.29918003082275 18.4556999206543 12.36088848114014 18.2270450592041 12.05411148071289 17.90505027770996 C 11.99603939056396 17.84417152404785 12.08491325378418 17.41870498657227 11.9762487411499 17.38686370849609 C 11.86540126800537 17.35429382324219 11.99131202697754 16.95703315734863 11.87677764892578 16.91667175292969 C 11.74868488311768 16.87163734436035 11.83595085144043 16.60932540893555 11.64609813690186 16.49078750610352 C 11.61529636383057 16.47146606445313 11.54958724975586 16.36524391174316 11.50673389434814 16.21221733093262 C 11.47484111785889 16.09872055053711 11.47338771820068 15.94491672515869 11.41458797454834 15.85713195800781 C 11.21226787567139 15.55476951599121 11.23829078674316 15.15402793884277 11.29168796539307 15.07694435119629 C 11.33698272705078 15.01144409179688 11.38445854187012 14.91882991790771 11.34498310089111 14.73219680786133 C 11.29511737823486 14.49569988250732 11.3443078994751 14.2413854598999 11.41536712646484 14.15552425384521 C 11.4803991317749 14.07698631286621 11.35563182830811 13.31155014038086 11.5047082901001 13.02669239044189 C 11.53686141967773 12.96503639221191 11.48678779602051 12.88385009765625 11.50273418426514 12.87746047973633 C 11.57800006866455 12.84785175323486 11.55244445800781 12.73710918426514 11.50039863586426 12.69919013977051 C 11.40528964996338 12.62979412078857 11.44481754302979 12.50861072540283 11.42814445495605 12.42207336425781 C 11.41131401062012 12.33553409576416 11.34051704406738 12.17861461639404 11.42861270904541 12.13098239898682 C 11.55504131317139 12.06246948242188 11.51115036010742 12.28167057037354 11.60573863983154 12.3335599899292 C 11.72318172454834 12.39807415008545 11.92202091217041 12.52917957305908 11.97427558898926 12.62189769744873 C 12.02637577056885 12.71461582183838 12.04413986206055 12.77180671691895 12.18978786468506 12.86862850189209 C 12.371018409729 12.98908615112305 12.41594886779785 13.0508975982666 12.46586608886719 13.20158576965332 C 12.59946537017822 13.60508060455322 12.57276630401611 14.01195240020752 12.59489440917969 14.32117176055908 C 12.61717700958252 14.63230991363525 12.67291355133057 14.76601314544678 12.57198715209961 14.84803104400635 C 12.491943359375 14.91322040557861 12.62922954559326 15.32289791107178 12.57068920135498 15.40865421295166 C 12.51246070861816 15.49425792694092 12.482177734375 16.7433910369873 12.54762649536133 16.9037914276123 C 12.62206077575684 17.08658027648926 12.63785076141357 17.57390975952148 12.68506908416748 17.68766593933105 C 12.73228454589844 17.80142402648926 12.79149913787842 18.03371238708496 12.94525146484375 18.10035705566406 C 13.02062225341797 18.13302803039551 13.09952259063721 18.20891761779785 13.20517635345459 18.16513061523438 C 13.2762336730957 18.13578224182129 13.34183883666992 18.29088592529297 13.36090183258057 18.39248657226563 Z M 12.53998851776123 12.80713081359863 C 12.56580448150635 12.78837966918945 12.64964199066162 12.74630546569824 12.66745758056641 12.80552005767822 C 12.68517017364502 12.86473560333252 12.6861572265625 12.94119548797607 12.60564517974854 12.95065021514893 C 12.52502822875977 12.96025943756104 12.43786811828613 12.88130474090576 12.53998756408691 12.80713081359863 Z M 13.0799388885498 14.88216018676758 C 13.08487415313721 15.08775234222412 12.83642959594727 16.13856506347656 12.85029792785645 16.33080863952637 C 12.86401081085205 16.5232048034668 13.12274074554443 17.0450267791748 13.10378170013428 17.21820640563965 C 13.08679676055908 17.37180328369141 13.32989025115967 17.7237720489502 13.34266948699951 17.83679962158203 C 13.35544776916504 17.94988059997559 13.23582172393799 17.85134506225586 13.15837383270264 17.71509742736816 C 13.09095096588135 17.5965633392334 12.99225902557373 17.43787574768066 12.9577169418335 17.42281341552734 C 12.89548969268799 17.39559364318848 12.9996862411499 17.72553634643555 13.04534530639648 17.81212615966797 C 13.08788681030273 17.8930549621582 13.31285285949707 18.11822700500488 13.27898597717285 18.12882423400879 C 13.24522399902344 18.13936996459961 12.92649936676025 17.8930549621582 12.83803939819336 17.71161651611328 C 12.78775882720947 17.60876655578613 12.69561100006104 17.24189186096191 12.64688873291016 17.0214958190918 C 12.63385009765625 16.96285247802734 12.59359455108643 16.66994476318359 12.61281299591064 16.30000495910645 C 12.65306949615479 15.52651691436768 12.80100440979004 14.81110095977783 12.78734302520752 14.63574123382568 C 12.77326679229736 14.45414733886719 12.86416721343994 13.69847679138184 12.79378414154053 13.60087490081787 C 12.75150299072266 13.54212760925293 12.7007007598877 13.29207229614258 12.78053855895996 13.23155784606934 C 12.8443775177002 13.18319892883301 12.94685935974121 13.26963233947754 12.98571395874023 13.33082103729248 C 13.16777515411377 13.61734104156494 13.07552433013916 14.69474792480469 13.0799388885498 14.88215923309326 Z M 13.30428218841553 12.46700572967529 C 13.2388858795166 12.54611492156982 13.13770008087158 12.65841770172119 13.11094951629639 12.72900867462158 C 13.08290004730225 12.80297660827637 13.13915538787842 12.82588386535645 13.17515087127686 12.86972236633301 C 13.23581981658936 12.94369029998779 13.24174118041992 13.01469707489014 13.19992828369141 13.03926467895508 C 13.12611675262451 13.08274269104004 12.9148120880127 12.96560955047607 12.89699554443359 12.81668758392334 C 12.8814640045166 12.68667507171631 13.05879878997803 12.59946060180664 12.9957389831543 12.56060791015625 C 12.93278408050537 12.52170372009277 12.72719287872314 12.60366821289063 12.60471057891846 12.54866218566895 C 12.51692581176758 12.50918483734131 12.44498538970947 12.44877433776855 12.43179225921631 12.30733394622803 C 12.41854476928711 12.16594409942627 12.50098037719727 11.98372745513916 12.64984893798828 11.87989234924316 C 12.71404933929443 11.8350133895874 12.81154918670654 11.90040969848633 12.77311038970947 11.99151706695557 C 12.73456859588623 12.08262729644775 12.55396175384521 12.12459659576416 12.52747058868408 12.26650714874268 C 12.50596618652344 12.38114452362061 12.60948944091797 12.47230434417725 12.73659420013428 12.45937156677246 C 12.86375141143799 12.44638538360596 12.88993072509766 12.37506675720215 13.07723808288574 12.36135482788086 C 13.26459789276123 12.34764099121094 13.36962604522705 12.38789749145508 13.30428218841553 12.46700668334961 Z M 13.76818752288818 11.4436731338501 C 13.73982715606689 11.54594802856445 13.67609119415283 11.64240741729736 13.55070018768311 11.75631904602051 C 13.4875373840332 11.81356048583984 13.33596706390381 11.91791343688965 13.56051731109619 12.08761215209961 C 13.63240814208984 12.14184188842773 13.53688526153564 12.27481651306152 13.37372970581055 12.13508892059326 C 13.30937099456787 12.08002853393555 13.26418113708496 11.87911319732666 13.32677268981934 11.72037410736084 C 13.37217140197754 11.60490417480469 13.44676113128662 11.54548072814941 13.60233116149902 11.44580173492432 C 13.73234558105469 11.36258888244629 13.67048168182373 11.21174621582031 13.76761531829834 11.21444702148438 C 13.82293605804443 11.21590232849121 13.80226135253906 11.32119083404541 13.76818561553955 11.4436731338501 Z M 13.798264503479 10.47498226165771 C 13.79987335205078 10.60239887237549 13.76101970672607 10.88315296173096 13.76101970672607 10.88315296173096 C 13.76101970672607 10.88315296173096 13.5363130569458 10.58027172088623 13.6011905670166 10.34585094451904 C 13.66617202758789 10.11148357391357 13.71780300140381 10.07377147674561 13.77785015106201 9.991129875183105 C 13.84454345703125 9.899398803710938 13.87373733520508 9.780916213989258 13.91695404052734 9.802472114562988 C 13.98182964324951 9.83493709564209 14.00364780426025 9.937265396118164 14.02234649658203 10.07288837432861 C 14.0411491394043 10.20851230621338 13.79659938812256 10.34756469726563 13.798264503479 10.47498226165771 Z M 14.11210346221924 10.87863254547119 C 14.08213329315186 10.97244262695313 14.22289943695068 11.06126499176025 14.2883996963501 11.12832450866699 C 14.3539514541626 11.19543552398682 14.2504301071167 11.19943523406982 14.13895797729492 11.20951175689697 C 14.10488319396973 11.21262836456299 13.98577690124512 11.11803913116455 13.9690523147583 10.97103977203369 C 13.95206737518311 10.82404041290283 14.02208614349365 10.57346630096436 14.20357704162598 10.43856906890869 C 14.34299182891846 10.33494281768799 14.32309913635254 10.26102638244629 14.29582786560059 10.19677257537842 C 14.2493896484375 10.08696556091309 14.4764347076416 10.20472049713135 14.4795503616333 10.38693714141846 C 14.48469352722168 10.70114326477051 14.14207458496094 10.78477096557617 14.11210346221924 10.87863254547119 Z M 14.56266117095947 8.939071655273438 C 14.51570320129395 9.049449920654297 14.30071067810059 9.268028259277344 14.25079345703125 9.345111846923828 C 14.20082378387451 9.422195434570313 14.29800987243652 9.56259822845459 14.35784816741943 9.524888038635254 C 14.40298748016357 9.496474266052246 14.57398509979248 9.162530899047852 14.71501159667969 9.12108039855957 C 14.82165145874023 9.089810371398926 14.85603713989258 9.205280303955078 14.83396244049072 9.340436935424805 C 14.79999160766602 9.550339698791504 14.57616710662842 9.544730186462402 14.50147247314453 9.712973594665527 C 14.45529365539551 9.817017555236816 14.48698139190674 9.864752769470215 14.48770809173584 9.930928230285645 C 14.48812198638916 9.964900016784668 14.39815616607666 9.917474746704102 14.3654842376709 9.898516654968262 C 14.31333446502686 9.868285179138184 14.35883617401123 9.715156555175781 14.32018947601318 9.69526195526123 C 14.01398372650146 9.53709602355957 13.95923614501953 9.348800659179688 13.97237682342529 9.269378662109375 C 13.98551750183105 9.190165519714355 14.19666862487793 8.861572265625 14.29437351226807 8.775399208068848 C 14.39223384857178 8.689225196838379 14.44537258148193 8.53199291229248 14.53024673461914 8.528824806213379 C 14.61678409576416 8.525707244873047 14.60821342468262 8.832121849060059 14.56265926361084 8.939071655273438 Z M 14.33447360992432 7.711807250976563 C 14.32268333435059 7.837250709533691 14.39841556549072 7.948824882507324 14.49279689788818 8.007053375244141 C 14.58686637878418 8.065334320068359 14.44241142272949 8.06715202331543 14.40392208099365 8.046374320983887 C 14.36553478240967 8.025649070739746 14.17646312713623 7.830706596374512 14.07792568206787 7.759751796722412 C 14.00930881500244 7.710302352905273 14.24591159820557 7.627971649169922 14.24513244628906 7.577014923095703 C 14.24435138702393 7.526058197021484 14.25177955627441 7.441028118133545 14.15900993347168 7.493229866027832 C 14.06623840332031 7.545329093933105 13.89383888244629 7.511514663696289 13.7874584197998 7.40980863571167 C 13.63869190216064 7.267692565917969 13.66809272766113 6.978732585906982 13.71593189239502 6.861910820007324 C 13.76034355163574 6.753557682037354 13.79706764221191 6.675954341888428 13.92687320709229 6.608635425567627 C 13.96728706359863 6.587598323822021 14.08057498931885 6.573781967163086 14.0848331451416 6.674551963806152 C 14.09314346313477 6.865547657012939 13.9705057144165 6.922321796417236 13.90697765350342 7.046310424804688 C 13.8505163192749 7.156689167022705 13.90760135650635 7.419990062713623 14.0562629699707 7.422327041625977 C 14.20492458343506 7.424664497375488 14.15713596343994 7.319479942321777 14.24180316925049 7.313766002655029 C 14.35836410522461 7.305974960327148 14.35015773773193 7.544757843017578 14.33446979522705 7.711806774139404 Z M 16.00803375244141 6.381540775299072 C 15.98003578186035 6.417277336120605 15.75605583190918 6.624998569488525 15.682297706604 6.632894039154053 C 15.62199020385742 6.639334678649902 15.78156089782715 6.760466575622559 15.65741729736328 6.762543678283691 C 15.58500671386719 6.763738632202148 15.50215816497803 6.695900917053223 15.44128036499023 6.591909885406494 C 15.3823766708374 6.491452217102051 15.31625175476074 6.333076953887939 15.21439075469971 6.337180614471436 C 15.00630664825439 6.345647811889648 14.97358226776123 6.322220325469971 14.88138198852539 6.270225524902344 C 14.84034633636475 6.247110843658447 14.78019714355469 6.221554756164551 14.74627780914307 6.124992370605469 C 14.73111057281494 6.081464290618896 14.76326179504395 6.040064811706543 14.86953735351563 5.945268630981445 C 14.87753677368164 5.93815279006958 14.96334743499756 5.852134227752686 14.99305820465088 5.782425880432129 C 15.01123905181885 5.739625453948975 15.11133289337158 5.512165069580078 15.17574310302734 5.427497386932373 C 15.22332191467285 5.365113735198975 15.30367946624756 5.271512508392334 15.3324556350708 5.249176502227783 C 15.36684036254883 5.22258186340332 15.4126558303833 5.25099515914917 15.35645294189453 5.305794715881348 C 15.30108070373535 5.359919548034668 15.11907196044922 5.734586238861084 15.09933376312256 5.772920608520508 C 15.05201244354248 5.864808559417725 14.93238830566406 6.041882991790771 14.93524646759033 6.090294361114502 C 14.94064807891846 6.184778690338135 15.04006671905518 6.16571569442749 15.09091854095459 6.152262210845947 C 15.14166736602783 6.138861179351807 15.15823745727539 5.949735641479492 15.218337059021 5.959760189056396 C 15.3196268081665 5.976746559143066 15.30497741699219 6.064426422119141 15.29240798950195 6.1239013671875 C 15.25500869750977 6.299469470977783 15.40528011322021 6.075801849365234 15.45613384246826 6.109824657440186 C 15.51186847686768 6.147016048431396 15.34887027740479 6.43244457244873 15.55794143676758 6.246903419494629 C 15.62816715240479 6.184727191925049 15.65704822540283 5.988069534301758 15.75750827789307 6.048999309539795 C 15.80955600738525 6.080633163452148 15.8519401550293 6.135329246520996 15.826904296875 6.165559768676758 C 15.7637414932251 6.242331981658936 15.60926151275635 6.319416046142578 15.57082462310791 6.366684913635254 C 15.53238582611084 6.413848876953125 15.55118942260742 6.502152919769287 15.59310626983643 6.516385078430176 C 15.68135929107666 6.546408176422119 15.76493644714355 6.348348617553711 15.89204025268555 6.291003227233887 C 15.96096897125244 6.259785652160645 16.04293441772461 6.336973190307617 16.00802993774414 6.381540775299072 Z M 15.51389789581299 5.719056606292725 C 15.58126831054688 5.771363258361816 15.66271495819092 5.909377098083496 15.61456203460693 5.925790786743164 C 15.57706069946289 5.938569068908691 15.49883365631104 5.82174825668335 15.46605587005615 5.792296409606934 C 15.41619205474854 5.747417449951172 15.34694957733154 5.755105018615723 15.33240699768066 5.741703510284424 C 15.306227684021 5.717757701873779 15.32305717468262 5.665502548217773 15.35640430450439 5.659633159637451 C 15.38923168182373 5.653867721557617 15.46522521972656 5.681553363800049 15.51389789581299 5.719056606292725 Z M 16.90436744689941 5.222582817077637 C 16.88842010498047 5.302107334136963 16.79305267333984 5.493830680847168 16.70163154602051 5.452950477600098 C 16.5413875579834 5.381424903869629 16.64324760437012 5.180612087249756 16.41012573242188 5.098697662353516 C 16.17716217041016 5.016782760620117 16.10979080200195 5.074284076690674 16.05852127075195 5.052260398864746 C 16.0073070526123 5.030288219451904 16.03452491760254 4.944997310638428 16.02231788635254 4.877211093902588 C 16.01016235351563 4.809425354003906 15.96808910369873 4.769999980926514 15.93167686462402 4.75924825668335 C 15.85900974273682 4.737795829772949 15.82841300964355 4.638324737548828 15.87189102172852 4.624351501464844 C 15.94518375396729 4.600717067718506 16.09036445617676 4.871237754821777 16.17482376098633 4.767663478851318 C 16.21720886230469 4.715564250946045 16.08802604675293 4.683826923370361 16.1197624206543 4.537242889404297 C 16.13846206665039 4.451952457427979 16.20162582397461 4.375231742858887 16.26587867736816 4.339287757873535 C 16.26006126403809 4.332690715789795 16.25429534912109 4.326302051544189 16.24837493896484 4.31752347946167 C 16.21798706054688 4.27316427230835 16.24032402038574 4.031783580780029 16.21331214904785 3.945402145385742 C 16.206298828125 3.922806978225708 16.1522274017334 3.838190793991089 16.12459373474121 3.811232328414917 C 16.05519676208496 3.74360203742981 15.99042320251465 3.732070922851563 15.91385841369629 3.780014753341675 C 15.81708908081055 3.840684413909912 15.5946159362793 4.210935592651367 15.46080875396729 4.380374431610107 C 15.33536624908447 4.539476871490479 15.29256343841553 4.518803596496582 15.6519603729248 4.700708866119385 C 15.88908195495605 4.820801734924316 15.80218029022217 4.996057987213135 15.78607749938965 5.064207553863525 C 15.76997566223145 5.132357597351074 15.74317359924316 5.192196369171143 15.89609432220459 5.190171241760254 C 15.97832107543945 5.189079761505127 16.11898231506348 5.187158107757568 16.20214462280273 5.220245838165283 C 16.33672904968262 5.273695468902588 16.46503067016602 5.346415996551514 16.5968074798584 5.525152683258057 C 16.6877613067627 5.64846658706665 16.65093421936035 5.764455795288086 16.5776424407959 5.727991104125977 C 16.49302673339844 5.685761451721191 16.3071231842041 5.469729423522949 16.27096939086914 5.440173625946045 C 16.20541572570801 5.386775970458984 16.11981391906738 5.31478214263916 16.04911994934082 5.353324890136719 C 15.99618911743164 5.382101535797119 16.07171440124512 5.460327625274658 16.13383865356445 5.516271114349365 C 16.21544456481934 5.589511394500732 16.45843315124512 5.824190616607666 16.3596363067627 5.897690773010254 C 16.27642440795898 5.959555149078369 16.15191650390625 5.755989551544189 16.09986877441406 5.680203914642334 C 16.05587196350098 5.615898132324219 15.99260425567627 5.50525951385498 15.91100311279297 5.472535133361816 C 15.92315864562988 5.486559867858887 15.98673629760742 5.618079662322998 15.99946212768555 5.641246795654297 C 16.04226493835449 5.719628810882568 16.09015464782715 5.853694915771484 16.10428428649902 5.940699577331543 C 16.12246513366699 6.053728580474854 16.14209938049316 6.164211750030518 16.05540466308594 6.165510177612305 C 15.88882255554199 6.168055534362793 15.97187995910645 6.060117244720459 15.86908340454102 5.994668960571289 C 15.83293056488037 5.97150182723999 15.52038764953613 5.516530990600586 15.51399993896484 5.495389938354492 C 15.49857330322266 5.445316791534424 15.55238723754883 5.409891128540039 15.57783794403076 5.433110237121582 C 15.58625316619873 5.440745830535889 15.81563568115234 5.809647083282471 15.89074420928955 5.884964466094971 C 16.04086112976074 6.035444736480713 15.93941497802734 5.820190906524658 15.91718292236328 5.731264591217041 C 15.91100311279297 5.70638370513916 15.8247241973877 5.472638607025146 15.81563568115234 5.443914890289307 C 15.81548023223877 5.443655014038086 15.81563568115234 5.443447113037109 15.81563568115234 5.443187236785889 C 15.75127601623535 5.401217460632324 15.67019462585449 5.29255199432373 15.56459331512451 5.164719104766846 C 15.41343784332275 4.981930732727051 15.17553806304932 5.135787010192871 15.14577579498291 5.057092666625977 C 15.16494083404541 5.082440853118896 15.08671569824219 5.180198669433594 15.04625225067139 5.246841907501221 C 14.99566078186035 5.330314636230469 14.88138294219971 5.55024242401123 14.86580181121826 5.707475185394287 C 14.83583068847656 6.009109497070313 14.72830772399902 5.879095077514648 14.61476039886475 5.944076538085938 C 14.52120971679688 5.997578144073486 14.46500778198242 6.185976505279541 14.64561367034912 6.359725952148438 C 14.79900169372559 6.507297992706299 15.06297779083252 6.458055019378662 15.19906902313232 6.464807510375977 C 15.33500385284424 6.471508502960205 15.26794528961182 6.548851490020752 15.27210140228271 6.667750358581543 C 15.27610015869141 6.786544322967529 15.35822296142578 6.905131340026855 15.42678833007813 6.996966361999512 C 15.47712135314941 7.064285278320313 15.37515640258789 7.127915382385254 15.24228572845459 7.180586338043213 C 15.07996273040771 7.244996070861816 14.96984386444092 7.138823509216309 14.92818546295166 7.079868316650391 C 14.88652515411377 7.020964622497559 14.91561508178711 6.876198291778564 14.81235027313232 6.773611068725586 C 14.70908737182617 6.671022891998291 14.48178291320801 6.607184410095215 14.37706661224365 6.495298862457275 C 14.3069953918457 6.420448780059814 14.32075881958008 5.870836734771729 14.34673023223877 5.793493270874023 C 14.37265014648438 5.716201782226563 14.26112747192383 5.525673389434814 14.32808208465576 5.444486618041992 C 14.39488220214844 5.363454818725586 14.61579513549805 5.541619777679443 14.72233104705811 5.403607368469238 C 14.75811958312988 5.357065677642822 14.87333106994629 5.263671398162842 14.9154052734375 5.218014240264893 C 15.06822109222412 5.05179500579834 15.12982654571533 5.035900592803955 15.14582633972168 5.057145118713379 C 15.12000846862793 4.988476276397705 14.96241283416748 5.070598602294922 14.83951663970947 5.095582962036133 C 14.74082374572754 5.115633010864258 14.44230556488037 5.177082061767578 14.419189453125 5.109503746032715 C 14.39638710021973 5.041821479797363 14.48058795928955 4.988475799560547 14.46448516845703 4.824387073516846 C 14.44734573364258 4.650429248809814 14.37062358856201 4.633235931396484 14.37779235839844 4.519688129425049 C 14.38480567932129 4.406192302703857 14.43503284454346 4.318979740142822 14.6551685333252 4.303759574890137 C 14.92044258117676 4.285476207733154 15.05954742431641 4.361573219299316 15.15751171112061 4.390765190124512 C 15.24706172943115 4.417411804199219 15.34263706207275 4.428735733032227 15.34201431274414 4.369260311126709 C 15.34107875823975 4.309785842895508 15.12421607971191 4.110894680023193 14.96651649475098 4.068301200866699 C 14.85707092285156 4.038745403289795 14.78606510162354 4.074897766113281 14.72705841064453 4.10964822769165 C 14.66799831390381 4.144346237182617 14.50417137145996 4.116764068603516 14.49456024169922 4.031940937042236 C 14.48494911193848 3.947117567062378 14.43399524688721 3.939222097396851 14.41986465454102 3.833258390426636 C 14.40999698638916 3.759602785110474 14.37353324890137 3.568451404571533 14.58203315734863 3.565750360488892 C 14.72004699707031 3.563932180404663 14.78050899505615 3.283074855804443 14.92787075042725 3.222456932067871 C 14.98500823974609 3.198978662490845 15.11143779754639 3.192849397659302 15.26846408843994 3.27876353263855 C 15.93463611602783 3.642834186553955 16.08173942565918 3.457084894180298 16.20775413513184 3.676701307296753 C 16.23642730712891 3.726722478866577 16.29231643676758 3.809623956680298 16.33652114868164 3.924211025238037 C 16.3936595916748 4.071781635284424 16.35989570617676 4.208807945251465 16.36846733093262 4.323498249053955 C 16.44264221191406 4.354145050048828 16.40892791748047 4.550958156585693 16.52881622314453 4.627210140228271 C 16.70074653625488 4.736499786376953 16.70059204101563 4.77789831161499 16.7866096496582 4.85321569442749 C 16.87236785888672 4.928481578826904 16.92036437988281 5.143111705780029 16.90436553955078 5.22258472442627 Z M 15.70795822143555 4.558331489562988 C 15.59217643737793 4.581083297729492 15.50610733032227 4.490338325500488 15.50610733032227 4.490338325500488 C 15.50610733032227 4.490338325500488 15.75190353393555 4.286200523376465 15.86519145965576 4.114839553833008 C 15.95432567596436 3.979839324951172 16.10340309143066 4.105801582336426 16.07898902893066 4.222518444061279 C 16.05228996276855 4.350194454193115 15.8980188369751 4.520880699157715 15.70795822143555 4.55833101272583 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.96, -5.33)" d="M 7.968152046203613 10.71611404418945 C 7.965606689453125 10.71637344360352 7.963062286376953 10.71621704101563 7.960620880126953 10.71595764160156 C 7.970334053039551 10.71834754943848 7.98139762878418 10.71949005126953 7.995630264282227 10.71730899810791 C 7.987371444702148 10.7156982421875 7.978333473205566 10.71517944335938 7.96815299987793 10.71611404418945 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-3.95, -5.32)" d="M 7.952921867370605 10.71456718444824 C 7.950325012207031 10.71394348144531 7.94736385345459 10.71373748779297 7.945026874542236 10.71285343170166 C 7.947572231292725 10.71368503570557 7.950169086456299 10.71425628662109 7.952921867370605 10.71456718444824 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-6.84, -3.28)" d="M 13.87868881225586 6.725021362304688 C 13.85609340667725 6.717905044555664 13.82809638977051 6.664506912231445 13.76524448394775 6.597552299499512 C 13.76529693603516 6.597552299499512 13.84238052368164 6.718372344970703 13.87868881225586 6.725021362304688 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(-1.85, -26.15)" d="M 8.393173217773438 52.61045074462891 C 8.325126647949219 52.61045074462891 8.291545867919922 52.62434387207031 8.292531967163086 52.65265655517578 C 8.292531967163086 52.66782379150391 8.305986404418945 52.69236755371094 8.331489562988281 52.72732543945313 L 8.37856388092041 52.79387664794922 C 8.448532104492188 52.89022827148438 8.506266593933105 52.93795013427734 8.550625801086426 52.93509674072266 L 8.591206550598145 52.93185424804688 L 8.631787300109863 52.92536163330078 L 8.693470001220703 52.91561889648438 L 8.755151748657227 52.90587615966797 C 8.78257942199707 52.90587615966797 8.81031608581543 52.91373443603516 8.839559555053711 52.92697906494141 C 8.892490386962891 52.95814514160156 8.932992935180664 52.99172973632813 8.961302757263184 53.02761840820313 L 9.160959243774414 53.28246307373047 C 9.200644493103027 53.33352661132813 9.236926078796387 53.35875701904297 9.268093109130859 53.35875701904297 C 9.284194946289063 53.35590362548828 9.292440414428711 53.34564208984375 9.292440414428711 53.32953643798828 C 9.292440414428711 53.29743957519531 9.270299911499023 53.255859375 9.225889205932617 53.20292663574219 L 8.990520477294922 52.92048645019531 C 8.817705154418945 52.71360015869141 8.617931365966797 52.61045074462891 8.393173217773438 52.61045074462891 Z M 15.73826313018799 52.61045074462891 C 15.67021656036377 52.61045074462891 15.63663387298584 52.62434387207031 15.63762283325195 52.65265655517578 C 15.63762283325195 52.66782379150391 15.64945316314697 52.69236755371094 15.67495632171631 52.72732543945313 L 15.72365283966064 52.79387664794922 C 15.79362106323242 52.89022827148438 15.85135555267334 52.93795013427734 15.89571475982666 52.93509674072266 L 15.93629550933838 52.93185424804688 L 15.97525310516357 52.92536163330078 L 16.03855895996094 52.91561889648438 L 16.09861755371094 52.90587615966797 C 16.12604522705078 52.90587615966797 16.1554069519043 52.91373443603516 16.18465042114258 52.92697906494141 C 16.23757934570313 52.95814514160156 16.2780818939209 52.99172973632813 16.30639266967773 53.02761840820313 L 16.50605010986328 53.28246307373047 C 16.54573440551758 53.33352661132813 16.58039283752441 53.35875701904297 16.61155700683594 53.35875701904297 C 16.62766075134277 53.35590362548828 16.63590621948242 53.34564208984375 16.63590621948242 53.32953643798828 C 16.63590621948242 53.29743957519531 16.61376571655273 53.255859375 16.56935501098633 53.20292663574219 L 16.33398818969727 52.92048645019531 C 16.16117095947266 52.71360015869141 15.96302032470703 52.61045074462891 15.73825931549072 52.61045074462891 Z M 3.727992057800293 53.43180084228516 L 3.727992057800293 53.65093994140625 L 4.197104930877686 53.65093994140625 L 4.197104930877686 54.00642395019531 C 4.194299697875977 54.02819061279297 4.18595027923584 54.05480194091797 4.172756195068359 54.08596801757813 C 4.147252082824707 54.13130950927734 4.120203018188477 54.15251922607422 4.089972019195557 54.15251922607422 C 4.068207740783691 54.14493560791016 4.038158416748047 54.13452911376953 4.002317428588867 54.11843109130859 C 3.972034454345703 54.09951782226563 3.939440488815308 54.08749389648438 3.901677370071411 54.08271789550781 C 3.834566831588745 54.08271789550781 3.801037549972534 54.13465881347656 3.801037549972534 54.23854827880859 C 3.801037549972534 54.36892700195313 3.880718469619751 54.53162384033203 4.041275024414063 54.72713470458984 L 4.260410308837891 54.99497222900391 C 4.323677539825439 55.07241821289063 4.410578727722168 55.15965270996094 4.520126819610596 55.2579345703125 C 4.560747146606445 55.29476165771484 4.601937294006348 55.31312561035156 4.643492698669434 55.31312561035156 C 4.671853065490723 55.31312561035156 4.685695648193359 55.30123901367188 4.685695648193359 55.27578735351563 C 4.677177429199219 55.20494079589844 4.62415599822998 55.13085174560547 4.524996757507324 55.05340576171875 L 4.357804298400879 54.92354583740234 C 4.260514259338379 54.83103942871094 4.213336944580078 54.76136779785156 4.213336944580078 54.71414947509766 L 4.221453189849854 54.66545104980469 L 4.25067138671875 54.608642578125 L 4.344818115234375 54.44631958007813 C 4.364660739898682 54.412353515625 4.379581451416016 54.37488555908203 4.391892433166504 54.33432006835938 L 4.463314056396484 54.34568023681641 C 4.484091281890869 54.35419464111328 4.505154609680176 54.36740875244141 4.524996757507324 54.38626098632813 C 4.57979679107666 54.43820190429688 4.616221904754639 54.46932983398438 4.636999130249023 54.47878265380859 C 4.675748825073242 54.49587249755859 4.739080429077148 54.50588226318359 4.826916694641113 54.50962829589844 L 4.938919544219971 54.51449584960938 C 4.992733001708984 54.51636505126953 5.056804656982422 54.50704193115234 5.130460262298584 54.48527526855469 L 5.127213478088379 54.94464874267578 C 5.126227378845215 55.03913116455078 5.150185585021973 55.11385345458984 5.200259208679199 55.16865539550781 C 5.211583137512207 55.18190002441406 5.235100269317627 55.20398712158203 5.270057678222656 55.23520660400391 C 5.309690475463867 55.28050231933594 5.339492797851563 55.30338287353516 5.359335422515869 55.30338287353516 C 5.371593952178955 55.301513671875 5.377191066741943 55.29252624511719 5.377191066741943 55.27741241455078 C 5.38093090057373 55.26322937011719 5.383683681488037 55.24968719482422 5.383683681488037 55.23358154296875 L 5.382063388824463 53.65093231201172 L 5.533023357391357 53.65093231201172 L 5.533023357391357 53.65254974365234 L 6.961463451385498 53.65254974365234 C 6.989824295043945 53.69312286376953 7.003666877746582 53.74894714355469 7.003666877746582 53.81974792480469 C 7.003666877746582 53.91417694091797 6.971851825714111 53.98094940185547 6.909520149230957 54.01778411865234 C 6.864173889160156 54.046142578125 6.789401531219482 54.06111145019531 6.6855149269104 54.06485748291016 L 6.037844181060791 54.063232421875 C 5.940554618835449 54.063232421875 5.851251125335693 54.09510040283203 5.770011901855469 54.15737915039063 C 5.673656940460205 54.23202514648438 5.625544548034668 54.32722473144531 5.625544548034668 54.44144439697266 C 5.625544548034668 54.57842254638672 5.669189929962158 54.70513153076172 5.757026195526123 54.82128143310547 L 5.938827037811279 55.05989837646484 C 5.99077033996582 55.12789154052734 6.062153816223145 55.1937255859375 6.154716968536377 55.25792694091797 C 6.198141098022461 55.28815460205078 6.231034278869629 55.30274200439453 6.253733158111572 55.3017578125 C 6.275445938110352 55.30081939697266 6.286198139190674 55.28874206542969 6.286198139190674 55.26604461669922 C 6.283341407775879 55.24246215820313 6.277107715606689 55.22026824951172 6.266719341278076 55.19949340820313 C 6.25347375869751 55.17305755615234 6.20604944229126 55.12557983398438 6.123875141143799 55.05664825439453 L 6.002133369445801 54.95438385009766 C 5.90863561630249 54.87595367431641 5.860912799835205 54.771728515625 5.860912799835205 54.63948059082031 C 5.860912799835205 54.43549346923828 5.977564334869385 54.31879425048828 6.209906578063965 54.29048156738281 L 6.644931316375732 54.29048156738281 L 6.727715969085693 54.41871643066406 C 6.895804405212402 54.67090606689453 7.082513809204102 54.79692840576172 7.289352893829346 54.79692840576172 C 7.403627395629883 54.79692840576172 7.498138427734375 54.77071380615234 7.571794033050537 54.72064208984375 C 7.58597469329834 54.71123504638672 7.59805154800415 54.70765686035156 7.607505321502686 54.70765686035156 C 7.623607158660889 54.70765686035156 7.631165027618408 54.72086334228516 7.630229949951172 54.74823760986328 L 7.625363826751709 54.85536956787109 L 7.620496273040771 54.96087646484375 L 7.63023567199707 55.04690551757813 C 7.637767314910889 55.06773376464844 7.652740001678467 55.09051513671875 7.677309036254883 55.11508178710938 L 7.826645851135254 55.26766967773438 C 7.859733581542969 55.2950439453125 7.881186962127686 55.30987548828125 7.891575336456299 55.30987548828125 C 7.900042057037354 55.30799865722656 7.904561519622803 55.29724884033203 7.904561519622803 55.27740478515625 L 7.904561519622803 53.65254974365234 L 8.08311653137207 53.65254974365234 L 8.430486679077148 53.65254974365234 L 8.430486679077148 54.28398895263672 L 8.38990592956543 54.29697418212891 L 8.347702026367188 54.30022430419922 L 8.294136047363281 54.30022430419922 C 8.212013244628906 54.30022430419922 8.170770645141602 54.34078216552734 8.170770645141602 54.42196655273438 C 8.170770645141602 54.48715972900391 8.213337898254395 54.55569458007813 8.297382354736328 54.62649536132813 L 8.425617218017578 54.7725830078125 C 8.479430198669434 54.83304595947266 8.532114028930664 54.86348724365234 8.583070755004883 54.86348724365234 C 8.608625411987305 54.86348724365234 8.633909225463867 54.85655975341797 8.659361839294434 54.84238433837891 C 8.688657760620117 54.82633209228516 8.703187942504883 54.80595397949219 8.703187942504883 54.78232574462891 C 8.706928253173828 54.76533508300781 8.709681510925293 54.74810028076172 8.709681510925293 54.73200225830078 L 8.709681510925293 54.69791412353516 L 8.703187942504883 54.62973785400391 C 8.700332641601563 54.59951019287109 8.715551376342773 54.57604217529297 8.748639106750488 54.55994415283203 L 9.320014953613281 54.55994415283203 L 9.320014953613281 55.05989837646484 C 9.327598571777344 55.09397125244141 9.363412857055664 55.14517211914063 9.42714786529541 55.21410369873047 C 9.490882873535156 55.28302764892578 9.53504753112793 55.31553649902344 9.558629035949707 55.30987548828125 C 9.584134101867676 55.31558227539063 9.594834327697754 55.28892517089844 9.591094017028809 55.23033142089844 L 9.591094017028809 53.65255737304688 L 9.790750503540039 53.65255737304688 L 10.79715156555176 53.65255737304688 L 10.79715156555176 54.14601898193359 L 10.57314682006836 54.00804138183594 C 10.5136194229126 53.97121429443359 10.44753456115723 53.95285034179688 10.37673568725586 53.95285034179688 C 10.29170513153076 53.95285034179688 10.22081565856934 53.95908355712891 10.16409301757813 53.97233581542969 C 9.988421440124512 54.01388549804688 9.901130676269531 54.12017822265625 9.901130676269531 54.29210662841797 C 9.901130676269531 54.41110992431641 9.957540512084961 54.53914642333984 10.0699462890625 54.67518615722656 C 10.17196273803711 54.79792785644531 10.29597663879395 54.85861206054688 10.44328784942627 54.85861206054688 C 10.53112316131592 54.85861206054688 10.62249279022217 54.83642578125 10.71599006652832 54.79206085205078 L 10.74845504760742 54.7725830078125 C 10.75411605834961 54.76879119873047 10.764817237854 54.76500701904297 10.78091907501221 54.76122283935547 L 10.80689144134521 54.76934051513672 L 10.80364513397217 54.89919281005859 C 10.8008394241333 55.03710174560547 10.83230304718018 55.14118194580078 10.89941596984863 55.209228515625 C 10.96647453308105 55.27727508544922 11.00967788696289 55.31149291992188 11.02765083312988 55.31149291992188 C 11.04655742645264 55.31149291992188 11.0552453994751 55.28803253173828 11.0552453994751 55.24169158935547 L 11.05362415313721 53.65254974365234 L 11.26951313018799 53.65254974365234 L 11.26951313018799 53.43179321289063 L 9.790750503540039 53.43179321289063 L 8.08311653137207 53.43179321289063 L 5.533023834228516 53.43179321289063 L 3.7279953956604 53.43179321289063 Z M 11.99507617950439 53.43180084228516 L 11.99507617950439 53.65256500244141 L 13.52253437042236 53.65256500244141 L 13.52253437042236 54.08758544921875 L 12.68819522857666 54.06973266601563 L 12.63949871063232 54.0794677734375 C 12.61965656280518 54.08985900878906 12.61028003692627 54.10017395019531 12.61028003692627 54.10868835449219 L 12.61028003692627 54.12005615234375 L 12.62326622009277 54.13304138183594 C 12.80460071563721 54.31437683105469 12.8990592956543 54.44384002685547 12.90570831298828 54.51936340332031 C 12.90570831298828 54.66766357421875 12.83339023590088 54.74174499511719 12.68981838226318 54.74174499511719 C 12.62940883636475 54.74174499511719 12.57358264923096 54.72313690185547 12.52262592315674 54.68817901611328 C 12.49426555633545 54.66838836669922 12.44684219360352 54.62606811523438 12.37978172302246 54.55994415283203 C 12.33630561828613 54.51652526855469 12.29020595550537 54.43860626220703 12.24018383026123 54.32620239257813 L 12.17363262176514 54.17523956298828 C 12.15098476409912 54.12329864501953 12.12255954742432 54.09732818603516 12.08760166168213 54.09732818603516 C 12.05929183959961 54.09732818603516 12.04377460479736 54.11843872070313 12.04377460479736 54.15901184082031 L 12.0486421585083 54.18660736083984 L 12.1281795501709 54.37327575683594 C 12.17253875732422 54.47903442382813 12.22517013549805 54.57015228271484 12.2856330871582 54.64759826660156 C 12.40837574005127 54.80727386474609 12.51584529876709 54.91248321533203 12.61027812957764 54.96250915527344 C 12.6915168762207 55.0059814453125 12.78145790100098 55.02743530273438 12.87973403930664 55.02743530273438 C 13.03743362426758 55.00852966308594 13.11672496795654 54.92098999023438 13.11672496795654 54.76609802246094 C 13.11672496795654 54.68013000488281 13.10086822509766 54.60943603515625 13.06965160369873 54.55182647705078 L 12.98524379730225 54.39437866210938 L 12.97875118255615 54.36354064941406 C 12.98067283630371 54.350341796875 12.9993724822998 54.341552734375 13.03718757629395 54.33594512939453 C 13.07681941986084 54.32555389404297 13.10976505279541 54.31970977783203 13.13620376586914 54.31970977783203 L 13.52253150939941 54.32295227050781 L 13.52253150939941 55.06639099121094 C 13.52253150939941 55.10228729248047 13.54153156280518 55.13321685791016 13.579345703125 55.16053771972656 C 13.70208740234375 55.25969696044922 13.76728916168213 55.30987548828125 13.77575588226318 55.30987548828125 C 13.79087066650391 55.30702209472656 13.79848098754883 55.28355407714844 13.79848098754883 55.24008178710938 L 13.79848098754883 53.65256500244141 L 13.94294834136963 53.65256500244141 L 14.43803310394287 53.65256500244141 C 14.46639347076416 53.69313049316406 14.48185920715332 53.74895477294922 14.48185920715332 53.81975555419922 C 14.48185920715332 53.9141845703125 14.45004463195801 53.98096466064453 14.38771152496338 54.01779174804688 C 14.34236526489258 54.04615020751953 14.26759243011475 54.06111907958984 14.16370677947998 54.06486511230469 L 14.05819606781006 54.06973266601563 C 14.03269290924072 54.075439453125 14.0208625793457 54.09198760986328 14.0208625793457 54.11842346191406 C 14.02460289001465 54.14019012451172 14.05504035949707 54.19252014160156 14.11176300048828 54.27750396728516 L 14.2042875289917 54.41872406005859 C 14.37237548828125 54.67090606689453 14.56070995330811 54.79693603515625 14.76754951477051 54.79693603515625 C 14.8818244934082 54.79693603515625 14.97633647918701 54.77071380615234 15.04999160766602 54.72064208984375 C 15.06417179107666 54.71124267578125 15.07462406158447 54.70765686035156 15.08407878875732 54.70765686035156 C 15.10012912750244 54.70765686035156 15.10773849487305 54.72086334228516 15.10680484771729 54.74823760986328 L 15.10355758666992 54.85536956787109 L 15.09706497192383 54.96088409423828 L 15.10680484771729 55.04691314697266 C 15.11438655853271 55.06774139404297 15.13087940216064 55.09051513671875 15.15550136566162 55.11508941650391 L 15.30646133422852 55.26766967773438 C 15.33954906463623 55.2950439453125 15.36100196838379 55.30987548828125 15.37139129638672 55.30987548828125 C 15.37985706329346 55.30800628662109 15.38437652587891 55.29725646972656 15.38437652587891 55.27741241455078 L 15.38275623321533 53.65255737304688 L 15.56131172180176 53.65255737304688 L 16.68296432495117 53.65255737304688 L 16.68296432495117 54.06647491455078 L 16.24956321716309 54.063232421875 L 16.09048843383789 54.06485748291016 C 15.9913272857666 54.0667724609375 15.89995956420898 54.10060119628906 15.81778430938721 54.16387176513672 C 15.72049522399902 54.23944854736328 15.67331790924072 54.33429718017578 15.67331790924072 54.44956207275391 C 15.67331790924072 54.58933258056641 15.7175989151001 54.71713256835938 15.80642127990723 54.83425903320313 L 15.98984718322754 55.07774353027344 C 16.04272651672363 55.14765930175781 16.11543273925781 55.21319580078125 16.20898246765137 55.27740478515625 C 16.25240707397461 55.30763244628906 16.28598976135254 55.32221984863281 16.30962371826172 55.32122802734375 C 16.33133316040039 55.32029724121094 16.34208679199219 55.30984497070313 16.34208679199219 55.28713989257813 C 16.33922958374023 55.26351165771484 16.3329963684082 55.24067687988281 16.32260704040527 55.21896362304688 C 16.31035041809082 55.19345855712891 16.26218605041504 55.14530181884766 16.17814254760742 55.07450103759766 L 16.05477523803711 54.97061157226563 C 15.95935535430908 54.89035797119141 15.91193199157715 54.78396606445313 15.91193199157715 54.65084075927734 C 15.91193199157715 54.44400024414063 16.0296630859375 54.32533264160156 16.26579475402832 54.29697418212891 L 16.68945693969727 54.29697418212891 L 16.68621063232422 55.05178070068359 C 16.68621063232422 55.08766937255859 16.69867706298828 55.11918640136719 16.72516822814941 55.14754486083984 L 16.81444549560547 55.22059631347656 C 16.8938159942627 55.28578186035156 16.93608283996582 55.31961059570313 16.94268035888672 55.31961059570313 C 16.95400238037109 55.31768798828125 16.96053695678711 55.28391265869141 16.96053695678711 55.22059631347656 L 16.96053695678711 53.65255737304688 L 17.13584518432617 53.65255737304688 L 17.13584518432617 53.43180084228516 L 15.56131458282471 53.43180084228516 L 13.94295501708984 53.43180084228516 L 11.99508285522461 53.43180084228516 Z M 4.434057235717773 53.65093994140625 L 5.130424022674561 53.65093994140625 L 5.130424022674561 54.20283508300781 C 5.040666103363037 54.25862121582031 4.917093276977539 54.28390502929688 4.76032829284668 54.27912902832031 L 4.560671806335449 54.27426147460938 C 4.497352600097656 54.2723388671875 4.455771923065186 54.26031494140625 4.434059619903564 54.23854827880859 L 4.434059619903564 53.65093994140625 Z M 7.096149921417236 53.65255737304688 L 7.64155387878418 53.65255737304688 L 7.64155387878418 54.18173217773438 C 7.640567302703857 54.29226684570313 7.583520412445068 54.38471221923828 7.471114635467529 54.45930480957031 C 7.370084762573242 54.52641296386719 7.259913921356201 54.55994415283203 7.139976978302002 54.55994415283203 C 7.080502033233643 54.55994415283203 7.016429424285889 54.54226684570313 6.948436260223389 54.50637817382813 C 6.869066715240479 54.46482086181641 6.83057689666748 54.41670989990234 6.831563949584961 54.36190795898438 C 6.831563949584961 54.33547210693359 6.845458984375 54.31882476806641 6.873767375946045 54.31320953369141 L 6.992262840270996 54.28723907470703 C 7.111265182495117 54.23529815673828 7.170818328857422 54.17221069335938 7.170818328857422 54.095703125 L 7.151339054107666 53.97396087646484 L 7.117251396179199 53.81488037109375 C 7.103070735931396 53.74969482421875 7.096149921417236 53.69499969482422 7.096149921417236 53.65255737304688 Z M 8.691783905029297 53.65255737304688 L 9.328088760375977 53.65255737304688 L 9.328088760375977 54.30834197998047 L 8.691783905029297 54.30834197998047 L 8.691783905029297 53.65255737304688 Z M 14.5727481842041 53.65255737304688 L 15.11815166473389 53.65255737304688 L 15.11815166473389 54.18173217773438 C 15.11727046966553 54.29226684570313 15.06169033050537 54.38471221923828 14.94933795928955 54.45930480957031 C 14.84825611114502 54.52641296386719 14.73656463623047 54.55994415283203 14.61657619476318 54.55994415283203 C 14.55704784393311 54.55994415283203 14.49470329284668 54.54226684570313 14.42665767669678 54.50637817382813 C 14.34728813171387 54.46482086181641 14.3071756362915 54.41670989990234 14.3081636428833 54.36190795898438 C 14.3081636428833 54.33547210693359 14.32200527191162 54.31882476806641 14.35036754608154 54.31320953369141 L 14.47048568725586 54.28723907470703 C 14.58948707580566 54.23529815673828 14.64904022216797 54.17221069335938 14.64904022216797 54.095703125 L 14.62793827056885 53.97396087646484 L 14.59385013580322 53.81488800048828 C 14.57967090606689 53.74969482421875 14.5727481842041 53.69499969482422 14.5727481842041 53.65256500244141 Z M 10.46760368347168 54.16387939453125 C 10.48251342773438 54.16304779052734 10.49885749816895 54.16387939453125 10.51467800140381 54.16387939453125 C 10.61290264129639 54.16387939453125 10.70780277252197 54.17810821533203 10.80036640167236 54.20932769775391 L 10.80036640167236 54.43495941162109 C 10.72572326660156 54.49256134033203 10.66062545776367 54.53369903564453 10.60395526885986 54.55831909179688 C 10.55388164520264 54.58008575439453 10.48333072662354 54.59971618652344 10.39455986022949 54.61676025390625 C 10.34542083740234 54.62615966796875 10.31012439727783 54.63137054443359 10.28742694854736 54.63137054443359 C 10.16556644439697 54.63137054443359 10.10562515258789 54.58193206787109 10.10562515258789 54.48365020751953 C 10.12422657012939 54.28355407714844 10.24397087097168 54.17638397216797 10.46760368347168 54.16387939453125 Z" fill="#1e1e1e" stroke="none" stroke-width="0.10327135026454926" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_511b493a0156482fb2acda34c5e3ed48 =
    '<svg viewBox="264.5 182.5 220.0 716.0" ><path transform="translate(264.5, 182.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(267.5, 412.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(269.5, 755.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(264.5, 299.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(266.5, 642.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(267.5, 529.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(269.5, 872.5)" d="M 0 0 L 215 0" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(371.5, 186.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(374.5, 416.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(376.5, 759.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(371.5, 303.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(373.5, 646.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(374.5, 533.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(376.5, 876.5)" d="M 0 0 L 0 22" fill="none" stroke="#e1e1e1" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_298da0ee66424685800a647fdc639a63 =
    '<svg viewBox="592.5 533.5 485.0 1.0" ><path transform="translate(592.5, 533.5)" d="M 0 0 L 485 0" fill="none" stroke="#d8d5d5" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _shapeSVG_2a380d272e1b4698ad9d156d36996992 =
    '<svg viewBox="1352.2 1036.5 36.5 28.8" ><g transform="translate(1352.37, 1030.35)"><g transform="translate(-0.13, 6.15)"><path transform="translate(5.82, 2.6)" d="M 28.09069633483887 5.032690048217773 L 27.09175300598145 5.032690048217773 L 27.09175300598145 16.01278114318848 C 27.09175300598145 17.72237777709961 26.09636306762695 19.26824760437012 24.10084533691406 19.26824760437012 L 4.550239086151123 19.26824760437012 L 4.550239086151123 19.79026412963867 C 4.550239086151123 21.30173492431641 6.269328594207764 22.82743453979492 8.034682273864746 22.82743453979492 L 22.98207473754883 22.82743453979492 L 28.70050239562988 26.1896800994873 L 27.87121391296387 22.82743453979492 L 28.09069633483887 22.82743453979492 C 29.85486221313477 22.82743453979492 30.65093612670898 21.3052921295166 30.65093612670898 19.79026794433594 L 30.65093612670898 7.639201164245605 C 30.65093612670898 6.127734661102295 29.85486602783203 5.032690048217773 28.09069633483887 5.032690048217773 Z" fill="#ffffff" stroke="none" stroke-width="0.5204436779022217" stroke-miterlimit="4" stroke-linecap="butt" /><path transform="translate(0.0, -1.69)" d="M 27.00473022460938 1.686237573623657 L 4.297123908996582 1.686237573623657 C 2.299233913421631 1.686237573623657 0 3.461085319519043 0 5.171866893768311 L 0 18.93405532836914 C 0 20.50959014892578 1.948060989379883 21.64734268188477 3.816633701324463 21.82292938232422 L 2.600578546524048 26.43919563293457 L 10.392822265625 21.85496139526367 L 27.00473022460938 21.85496139526367 C 29.00261878967285 21.85496139526367 30.84627914428711 20.64365196228027 30.84627914428711 18.93405532836914 L 30.84627914428711 7.799733638763428 L 30.84627914428711 5.171866893768311 C 30.84627914428711 3.461085319519043 29.00143241882324 1.686237573623657 27.00473022460938 1.686237573623657 Z M 7.761398315429688 13.30342102050781 C 6.628390312194824 13.30342102050781 5.710119724273682 12.38515186309814 5.710119724273682 11.2521448135376 C 5.710119724273682 10.11913681030273 6.628390312194824 9.20086669921875 7.761398315429688 9.20086669921875 C 8.893218994140625 9.20086669921875 9.812675476074219 10.11913681030273 9.812675476074219 11.2521448135376 C 9.812675476074219 12.38515186309814 8.893218994140625 13.30342102050781 7.761398315429688 13.30342102050781 Z M 15.42313957214355 13.30342102050781 C 14.29013061523438 13.30342102050781 13.37186145782471 12.38515186309814 13.37186145782471 11.2521448135376 C 13.37186145782471 10.11913681030273 14.29013061523438 9.200867652893066 15.42313957214355 9.200867652893066 C 16.5561466217041 9.200867652893066 17.47441673278809 10.11913776397705 17.47441673278809 11.25214576721191 C 17.47441673278809 12.38515281677246 16.5561466217041 13.30342102050781 15.42313957214355 13.30342102050781 Z M 23.0860652923584 13.30342102050781 C 21.95306015014648 13.30342102050781 21.03360366821289 12.38515186309814 21.03360366821289 11.2521448135376 C 21.03360366821289 10.11913681030273 21.95306015014648 9.20086669921875 23.0860652923584 9.20086669921875 C 24.21669960021973 9.20086669921875 25.13734436035156 10.11913681030273 25.13734436035156 11.2521448135376 C 25.13734436035156 12.38515186309814 24.21670150756836 13.30342102050781 23.0860652923584 13.30342102050781 Z" fill="#ffffff" stroke="none" stroke-width="0.5204436779022217" stroke-miterlimit="4" stroke-linecap="butt" /></g></g></svg>';
const String _shapeSVG_26d44933b5c045d4a766aa7c633f1915 =
    '<svg viewBox="1721.0 1046.0 14.0 12.0" ><path transform="translate(1721.0, 1046.0)" d="M 5.272441864013672 2.961527824401855 C 6.044198036193848 1.638516902923584 7.955801010131836 1.638516902923584 8.727558135986328 2.961527824401855 L 12.2454833984375 8.992258071899414 C 13.02325057983398 10.32557106018066 12.06150817871094 12 10.51792621612549 12 L 3.482073783874512 12 C 1.938492059707642 12 0.9767500162124634 10.32557106018066 1.754516005516052 8.992258071899414 Z" fill="#ffffff" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
